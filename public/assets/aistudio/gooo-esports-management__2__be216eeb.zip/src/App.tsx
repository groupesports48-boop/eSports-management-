/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TournamentProvider, useTournament } from './context/TournamentContext';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { AddMatchModal } from './components/AddMatchModal';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { SchedulePage } from './pages/SchedulePage';
import { LobbiesPage } from './pages/LobbiesPage';
import { TournamentDetailPage } from './pages/TournamentDetailPage';
import { TournamentsPage } from './pages/TournamentsPage';
import { AnalyzePage } from './pages/AnalyzePage';
import { HistoryPage } from './pages/HistoryPage';
import { ProfitLossPage } from './pages/ProfitLossPage';
import { ProfilePage } from './pages/ProfilePage';
import { NotificationsPage } from './pages/NotificationsPage';
import { ErrorBoundary } from './components/ErrorBoundary';

function getInitialPage(): string {
  if (typeof window === 'undefined') return 'index';

  const fullPath = (window.location.pathname + window.location.hash).toLowerCase();
  if (fullPath.includes('login')) return 'login';
  if (fullPath.includes('schedule')) return 'schedule';
  if (fullPath.includes('tournament-detail')) return 'tournament-detail';
  if (fullPath.includes('lobbies')) return 'lobbies';
  if (fullPath.includes('dashboard')) return 'dashboard';
  if (fullPath.includes('analyze')) return 'analyze';
  if (fullPath.includes('tournaments')) return 'tournaments';
  if (fullPath.includes('history')) return 'history';
  if (fullPath.includes('profit-loss')) return 'profit-loss';
  if (fullPath.includes('profile')) return 'profile';
  if (fullPath.includes('notifications')) return 'notifications';

  const globalPage = (window as unknown as { ACTIVE_PAGE?: string }).ACTIVE_PAGE;
  if (globalPage && globalPage !== 'index') return globalPage;

  return 'index';
}

function MainApp() {
  const [activePage, setActivePage] = useState<string>(getInitialPage);
  const { setSelectedTournamentId, isAddMatchModalOpen, closeAddMatchModal } = useTournament();

  // Sync with browser navigation
  useEffect(() => {
    const handlePopState = () => {
      setActivePage(getInitialPage());
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handleNavigate = (page: string, tournamentId?: string) => {
    if (tournamentId) {
      setSelectedTournamentId(tournamentId);
    }
    setActivePage(page);
    const targetFile = page === 'index' ? 'index.html' : `${page}.html`;
    window.history.pushState({}, '', targetFile);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Keep browser title strictly synchronized with official website branding
  useEffect(() => {
    document.title = 'Destroyed eSports Management';
  }, [activePage]);

  const pageMeta: Record<string, { title: string; subtitle: string }> = {
    index: {
      title: 'Destroyed eSports Management',
      subtitle: 'Personal Free Fire India competitive hub for tracking MY tournaments, MY lobbies & MY team',
    },
    login: {
      title: 'Authentication - Destroyed eSports',
      subtitle: 'Sign up or sign in to manage your team matches and record results',
    },
    dashboard: {
      title: 'Destroyed eSports Dashboard',
      subtitle: 'Real-time overview of MY tournaments, MY active lobbies, MY team roster, and upcoming countdowns',
    },
    schedule: {
      title: 'My Match Schedule (IST)',
      subtitle: 'Upcoming Free Fire BR Solo, Duo, and Squad matches with live ticking countdowns',
    },
    lobbies: {
      title: 'Team Lobbies & Match Control',
      subtitle: 'Roster validation, scheduled countdowns, and WhatsApp group coordinator',
    },
    'tournament-detail': {
      title: 'Match Details & Coordinator',
      subtitle: 'Guidelines, prize allocations, and dedicated WhatsApp group access',
    },
    tournaments: {
      title: 'Match Planner & Scrims',
      subtitle: 'Manage your competitive Free Fire matches, entry fees, and prize pool records',
    },
    analyze: {
      title: 'Team Destroyed Analytics',
      subtitle: 'Deep dive into your K/D ratio, headshot percentages, and seasonal rank stats calculated from actual records',
    },
    history: {
      title: 'Match History & Results Ledger',
      subtitle: 'Audit-ready ledger of all completed matches, kills, and scoreboard OCR extraction',
    },
    'profit-loss': {
      title: 'Profit & Loss (Rupees)',
      subtitle: 'Track your tournament winnings, entry expenses, and net returns in Rupees (₹)',
    },
    profile: {
      title: 'Team & Player Profile',
      subtitle: 'Upload team banner, profile photo, and customize competitive player identity',
    },
    notifications: {
      title: 'Match Reminders & Feeds',
      subtitle: 'Automated match alerts and authorized squad WhatsApp dispatch',
    },
  };

  const currentMeta = pageMeta[activePage] || pageMeta.index;

  return (
    <div className="min-h-screen bg-[#050505] text-[#f3f4f6] flex">
      {/* Persistent Sidebar */}
      <Sidebar activePage={activePage} onNavigate={handleNavigate} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 lg:ml-72 pt-14 lg:pt-0">
        {/* Header (No wallet deposit / withdraw buttons) */}
        <Header
          title={currentMeta.title}
          subtitle={currentMeta.subtitle}
          onNavigate={handleNavigate}
        />

        {/* Dynamic Page View */}
        <main className="flex-1 px-4 lg:px-8 py-6 max-w-7xl w-full mx-auto">
          {activePage === 'index' && <LandingPage onNavigate={handleNavigate} />}
          {activePage === 'login' && <LoginPage onNavigate={handleNavigate} />}
          {activePage === 'dashboard' && (
            <DashboardPage onNavigate={handleNavigate} />
          )}
          {activePage === 'schedule' && <SchedulePage onNavigate={handleNavigate} />}
          {activePage === 'lobbies' && <LobbiesPage />}
          {activePage === 'tournament-detail' && (
            <TournamentDetailPage onNavigate={handleNavigate} />
          )}
          {activePage === 'tournaments' && <TournamentsPage />}
          {activePage === 'analyze' && <AnalyzePage />}
          {activePage === 'history' && <HistoryPage />}
          {activePage === 'profit-loss' && (
            <ProfitLossPage />
          )}
          {activePage === 'profile' && <ProfilePage />}
          {activePage === 'notifications' && <NotificationsPage onNavigate={handleNavigate} />}
        </main>
      </div>

      {/* Global Add Match Planner Modal */}
      <AddMatchModal
        isOpen={isAddMatchModalOpen}
        onClose={closeAddMatchModal}
        onMatchAdded={() => {
          handleNavigate('dashboard');
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <TournamentProvider>
        <MainApp />
      </TournamentProvider>
    </ErrorBoundary>
  );
}
