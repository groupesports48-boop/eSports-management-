import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Tournament,
  MatchHistoryItem,
  Transaction,
  AppNotification,
  UserProfile,
  PerformanceStats,
  RegisteredPlayer,
  ScoringRules,
  TournamentFormat,
  SeriesFormat,
  GameMode,
  GameMap,
  ClientCompatibility,
  LobbyStatus,
} from '../types';
import {
  calculateNetProfit,
  calculateROI,
  calculateWinRate,
  calculateKD,
  formatCurrencyINR,
} from '../utils/esportsMath';

export const DEFAULT_SCORING_RULES: ScoringRules = {
  pointsPerKill: 1,
  placementPoints: {
    1: 12,
    2: 9,
    3: 8,
    4: 7,
    5: 6,
    6: 5,
    7: 4,
    8: 3,
    9: 2,
    10: 1,
  },
};

const DEFAULT_USER: UserProfile = {
  id: 'usr_default',
  name: 'Destroyed Captain',
  email: 'groupesports48@gmail.com',
  freeFireUid: '99482103',
  ign: 'DESTROYER_VIPER',
  avatarUrl: '/assets/aistudio/photo__1__f37c447f.jpg',
  bannerUrl: '',
  teamName: 'Team Destroyed',
  teamTag: 'DST',
  teamBio: 'Official Free Fire India competitive roster for scrims and tournaments.',
  whatsappNumber: '+91 98765 43210',
  rankedScore: 4250,
  level: 78,
  guild: 'DESTROYED ESPORTS INDIA',
  phone: '+91 98765 43210',
  isLoggedIn: true,
  preferredWeapon: 'AWM / MP40',
  serverRegion: 'India (IND)',
  isAdmin: true,
};

const DEFAULT_WA_TEMPLATE = `🏆 *DESTROYED ESPORTS MATCH REMINDER* 🏆\n\n⚔️ *Match:* {matchName}\n🕒 *Kickoff:* {time}\n🎮 *Format:* {format} | {map}\n💬 *WhatsApp Group:* {groupLink}\n\n⚡ Squad be ready 10 minutes prior to match time! Booyah! 🔥`;

interface WhatsappReminderConfig {
  phoneNumber: string;
  customTemplate: string;
}

interface TournamentContextType {
  user: UserProfile;
  tournaments: Tournament[];
  history: MatchHistoryItem[];
  notifications: AppNotification[];
  stats: PerformanceStats;
  unreadCount: number;
  selectedTournamentId: string | null;
  setSelectedTournamentId: (id: string | null) => void;
  // Computed dynamic data fields connected to real saved state
  totalTournamentsCount: number;
  liveLobbiesCount: number;
  grossWinningsSum: number;
  totalExpensesSum: number;
  netProfitSum: number;
  login: (email: string, ffUid: string, ign: string) => void;
  signup: (name: string, email: string, ffUid: string, ign: string, extra?: Partial<UserProfile>) => void;
  logout: () => void;
  resetPassword: (email: string) => boolean;
  updateUserProfile: (updates: Partial<UserProfile>) => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  addTournament: (newTournament: Omit<Tournament, 'id' | 'currentPlayers' | 'isJoined' | 'players'>) => Tournament;
  updateTournamentConfig: (
    tournamentId: string,
    updates: Partial<Omit<Tournament, 'id' | 'players'>>
  ) => void;
  deleteTournament: (tournamentId: string) => void;
  addMatchHistoryItem: (item: Omit<MatchHistoryItem, 'id'>) => MatchHistoryItem;
  updateMatchHistoryItem: (id: string, updates: Partial<MatchHistoryItem>) => void;
  deleteMatchHistoryItem: (id: string) => void;
  searchFilter: string;
  setSearchFilter: (query: string) => void;
  // Personal Match Planner
  isAddMatchModalOpen: boolean;
  openAddMatchModal: () => void;
  closeAddMatchModal: () => void;
  nextUpcomingMatch: Tournament | null;
  recordMatchResult: (
    tournamentId: string,
    kills: number,
    placement: number,
    prizeWon: number,
    points?: number
  ) => boolean;
  // WhatsApp reminders config
  whatsappReminderConfig: WhatsappReminderConfig;
  updateWhatsappReminderConfig: (config: Partial<WhatsappReminderConfig>) => void;
}

const TournamentContext = createContext<TournamentContextType | undefined>(undefined);

export const TournamentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // User profile persistence (starts logged in with preserved or default captain profile)
  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('destroyed_user');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          return { ...DEFAULT_USER, ...parsed };
        }
      }
    } catch (e) {
      console.warn('Could not read user profile from localStorage:', e);
    }
    return DEFAULT_USER;
  });

  // Tournaments state: New users start with clean empty state [] (Requirement 2 & 15)
  const [tournaments, setTournaments] = useState<Tournament[]>(() => {
    try {
      const saved = localStorage.getItem('destroyed_tournaments');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn('Could not read tournaments from localStorage:', e);
    }
    return [];
  });

  const [selectedTournamentId, setSelectedTournamentId] = useState<string | null>(null);

  // Match History state: New users start with clean zero records [] (Requirement 9 & 15)
  const [history, setHistory] = useState<MatchHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('destroyed_history');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn('Could not read history from localStorage:', e);
    }
    return [];
  });

  // Notifications state
  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    const defaultNotifs: AppNotification[] = [
      {
        id: 'notif_welcome',
        title: 'Welcome to Destroyed eSports Management',
        message: 'Your personal competitive Free Fire match planner is active. Click "+ Add Match" to schedule your squad scrims and track match results.',
        timestamp: 'Just now',
        type: 'system',
        isRead: false,
      },
    ];
    try {
      const saved = localStorage.getItem('destroyed_notifications');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn('Could not read notifications from localStorage:', e);
    }
    return defaultNotifs;
  });

  // WhatsApp reminder config
  const [whatsappReminderConfig, setWhatsappReminderConfig] = useState<WhatsappReminderConfig>(() => {
    try {
      const saved = localStorage.getItem('destroyed_wa_config');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          return {
            phoneNumber: parsed.phoneNumber || DEFAULT_USER.phone || '+91 98765 43210',
            customTemplate: parsed.customTemplate || DEFAULT_WA_TEMPLATE,
          };
        }
      }
    } catch (e) {
      console.warn('Could not read wa_config from localStorage:', e);
    }
    return {
      phoneNumber: DEFAULT_USER.phone || '+91 98765 43210',
      customTemplate: DEFAULT_WA_TEMPLATE,
    };
  });

  const [searchFilter, setSearchFilter] = useState('');
  const [isAddMatchModalOpen, setIsAddMatchModalOpen] = useState(false);
  const openAddMatchModal = () => setIsAddMatchModalOpen(true);
  const closeAddMatchModal = () => setIsAddMatchModalOpen(false);

  // Compute Next Upcoming Match (LIVE or soonest upcoming)
  const nonCompletedMatches = Array.isArray(tournaments) ? tournaments.filter(t => t.status !== 'COMPLETED') : [];
  const nextUpcomingMatch: Tournament | null =
    [...nonCompletedMatches].sort((a, b) => {
      if (a.status === 'LIVE' && b.status !== 'LIVE') return -1;
      if (b.status === 'LIVE' && a.status !== 'LIVE') return 1;
      return a.targetTimestampMs - b.targetTimestampMs;
    })[0] || null;

  // Local storage persistence with safe exception handling
  useEffect(() => {
    try {
      localStorage.setItem('destroyed_user', JSON.stringify(user));
    } catch {}
  }, [user]);

  useEffect(() => {
    try {
      localStorage.setItem('destroyed_tournaments', JSON.stringify(tournaments));
    } catch {}
  }, [tournaments]);

  useEffect(() => {
    try {
      localStorage.setItem('destroyed_history', JSON.stringify(history));
    } catch {}
  }, [history]);

  useEffect(() => {
    try {
      localStorage.setItem('destroyed_notifications', JSON.stringify(notifications));
    } catch {}
  }, [notifications]);

  useEffect(() => {
    try {
      localStorage.setItem('destroyed_wa_config', JSON.stringify(whatsappReminderConfig));
    } catch {}
  }, [whatsappReminderConfig]);

  // Performance calculations: Start strictly at 0 if no match history exists (Requirement 11)
  const totalMatches = history.length;
  const wins = history.filter(h => h.rankStatus === 'WIN').length;
  const losses = history.filter(h => h.rankStatus === 'LOSS').length;
  const kills = history.reduce((sum, h) => sum + h.kills, 0);
  const deaths = Math.max(0, totalMatches - wins);
  const kdRatio = calculateKD(kills, deaths);
  const winRate = calculateWinRate(wins, totalMatches);
  const headshots = Math.round(kills * 0.42);
  const headshotRate = kills > 0 ? 42.5 : 0;
  const totalDamage = kills * 210 + totalMatches * 260;
  const avgDamagePerMatch = totalMatches > 0 ? Math.round(totalDamage / totalMatches) : 0;
  const mvpCount = wins;

  const stats: PerformanceStats = {
    totalMatches,
    wins,
    losses,
    kills,
    deaths,
    headshots,
    headshotRate,
    totalDamage,
    avgDamagePerMatch,
    mvpCount,
    winRate,
    kdRatio,
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  // Fully dynamic metrics calculated strictly from actual records (Requirement 11 & 12)
  const totalTournamentsCount = tournaments.length;
  const liveLobbiesCount = tournaments.filter(t => t.status === 'LIVE').length;
  const grossWinningsSum = history.reduce((sum, h) => sum + (h.prizeWon || 0), 0);
  const totalExpensesSum = history.reduce((sum, h) => sum + (h.entryFee || 0), 0);
  const netProfitSum = calculateNetProfit(grossWinningsSum, totalExpensesSum);

  const login = (email: string, ffUid: string, ign: string) => {
    setUser(prev => ({
      ...prev,
      email: email || prev.email,
      freeFireUid: ffUid.replace(/^FF-?/i, '') || prev.freeFireUid,
      ign: ign || prev.ign,
      isLoggedIn: true,
    }));
  };

  const signup = (name: string, email: string, ffUid: string, ign: string, extra?: Partial<UserProfile>) => {
    setUser(prev => ({
      ...prev,
      name,
      email,
      freeFireUid: ffUid.replace(/^FF-?/i, ''),
      ign,
      isLoggedIn: true,
      ...extra,
    }));
  };

  const logout = () => {
    setUser(prev => ({ ...prev, isLoggedIn: false }));
  };

  const resetPassword = (email: string): boolean => {
    const newNotif: AppNotification = {
      id: `notif_${Date.now()}`,
      title: 'Password Reset Dispatched',
      message: `A security recovery code and instructions sent to ${email} for Destroyed eSports account.`,
      timestamp: 'Just now',
      type: 'system',
      isRead: false,
    };
    setNotifications(prev => [newNotif, ...prev]);
    return true;
  };

  const updateUserProfile = (updates: Partial<UserProfile>) => {
    setUser(prev => ({ ...prev, ...updates }));
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => (n.id === id ? { ...n, isRead: true } : n)));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const addTournament = (newT: Omit<Tournament, 'id' | 'currentPlayers' | 'isJoined' | 'players'>): Tournament => {
    const teamPlayer: RegisteredPlayer = {
      id: `reg_${Date.now()}_1`,
      uid: user.freeFireUid,
      email: user.email,
      ign: user.ign,
      squadName: user.teamName || 'Team Destroyed',
      slotNumber: 1,
      registeredAtIST: 'Just now (IST)',
      verified: true,
    };

    const created: Tournament = {
      ...newT,
      id: `tour_${Date.now()}`,
      currentPlayers: 1,
      isJoined: true,
      isRoomUnlocked: true,
      players: [teamPlayer],
    };

    setTournaments(prev => [created, ...prev]);

    // Build automated reminder notification
    const waText = encodeURIComponent(
      `🏆 *TEAM DESTROYED MATCH REMINDER* 🏆\nMatch: ${created.title}\nFormat: ${created.format} (${created.map})\nKickoff: ${created.startTimeIST}\n${
        created.whatsAppGroupUrl ? `WhatsApp Group: ${created.whatsAppGroupUrl}\n` : ''
      }Be ready 10 mins before start!`
    );

    const reminderNotif: AppNotification = {
      id: `notif_${Date.now()}`,
      title: `Match Scheduled: ${created.title}`,
      message: `Match scheduled for ${created.startTimeIST} (${created.map} • ${created.format}). Team Destroyed squad has been notified.`,
      timestamp: 'Just now',
      type: 'room',
      isRead: false,
      waLink: created.whatsAppGroupUrl || `https://wa.me/?text=${waText}`,
      actionText: 'View Dashboard',
      actionUrl: 'dashboard.html',
    };

    setNotifications(prev => [reminderNotif, ...prev]);
    return created;
  };

  const updateTournamentConfig = (
    tournamentId: string,
    updates: Partial<Omit<Tournament, 'id' | 'players'>>
  ) => {
    setTournaments(prev =>
      prev.map(t => (t.id === tournamentId ? { ...t, ...updates } : t))
    );
  };

  const deleteTournament = (tournamentId: string) => {
    setTournaments(prev => prev.filter(t => t.id !== tournamentId));
  };

  const addMatchHistoryItem = (item: Omit<MatchHistoryItem, 'id'>): MatchHistoryItem => {
    const newItem: MatchHistoryItem = {
      ...item,
      id: `hist_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    };
    setHistory(prev => [newItem, ...prev]);

    const isWin = newItem.rankStatus === 'WIN';
    const notif: AppNotification = {
      id: `notif_${Date.now()}`,
      title: isWin ? '🏆 BOOYAH! Victory Recorded!' : 'Match Result Recorded',
      message: `${newItem.tournamentName} recorded with Rank #${newItem.placement} and ${newItem.kills} kills. Net: ${
        newItem.netAmount >= 0 ? '+' : ''
      }Rs. ${newItem.netAmount} added to your ledger.`,
      timestamp: 'Just now',
      type: 'match',
      isRead: false,
      actionText: 'View History',
      actionUrl: 'history.html',
    };
    setNotifications(prev => [notif, ...prev]);

    return newItem;
  };

  const updateMatchHistoryItem = (id: string, updates: Partial<MatchHistoryItem>) => {
    setHistory(prev =>
      prev.map(h => (h.id === id ? { ...h, ...updates, netAmount: (updates.prizeWon ?? h.prizeWon) - (updates.entryFee ?? h.entryFee) } : h))
    );
  };

  const deleteMatchHistoryItem = (id: string) => {
    setHistory(prev => prev.filter(h => h.id !== id));
  };

  const recordMatchResult = (
    tournamentId: string,
    kills: number,
    placement: number,
    prizeWon: number,
    points?: number
  ): boolean => {
    const target = tournaments.find(t => t.id === tournamentId);
    if (!target) return false;

    const isWin = placement === 1;
    const isPodium = placement <= 3 && placement > 1;
    const rankStatus: 'WIN' | 'PODIUM' | 'LOSS' = isWin ? 'WIN' : isPodium ? 'PODIUM' : 'LOSS';
    const netAmount = prizeWon - target.entryFee;

    const newHistItem: MatchHistoryItem = {
      id: `hist_${Date.now()}`,
      matchId: `FF-M${Math.floor(100 + Math.random() * 900)}`,
      tournamentName: target.title,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16) + ' IST',
      gameMode: target.gameMode,
      map: target.map,
      kills,
      placement,
      points: points ?? (placement === 1 ? 12 + kills : placement <= 3 ? 8 + kills : kills),
      rankStatus,
      entryFee: target.entryFee,
      prizeWon,
      netAmount,
    };

    setHistory(prev => [newHistItem, ...prev]);

    // Mark tournament as completed
    setTournaments(prev =>
      prev.map(t =>
        t.id === tournamentId
          ? { ...t, status: 'COMPLETED', lobbyStatus: 'COMPLETED' }
          : t
      )
    );

    const completionNotif: AppNotification = {
      id: `notif_${Date.now()}`,
      title: isWin ? '🏆 BOOYAH! Match Won & Recorded!' : 'Match Result Recorded',
      message: `${target.title} completed with Rank #${placement} and ${kills} kills. Net: ${
        netAmount >= 0 ? '+' : ''
      }Rs. ${netAmount} added to your ledger.`,
      timestamp: 'Just now',
      type: 'match',
      isRead: false,
      actionText: 'View History',
      actionUrl: 'history.html',
    };
    setNotifications(prev => [completionNotif, ...prev]);

    return true;
  };

  const updateWhatsappReminderConfig = (config: Partial<WhatsappReminderConfig>) => {
    setWhatsappReminderConfig(prev => ({ ...prev, ...config }));
  };

  return (
    <TournamentContext.Provider
      value={{
        user,
        tournaments,
        history,
        notifications,
        stats,
        unreadCount,
        selectedTournamentId,
        setSelectedTournamentId,
        totalTournamentsCount,
        liveLobbiesCount,
        grossWinningsSum,
        totalExpensesSum,
        netProfitSum,
        login,
        signup,
        logout,
        resetPassword,
        updateUserProfile,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        addTournament,
        updateTournamentConfig,
        deleteTournament,
        addMatchHistoryItem,
        updateMatchHistoryItem,
        deleteMatchHistoryItem,
        searchFilter,
        setSearchFilter,
        isAddMatchModalOpen,
        openAddMatchModal,
        closeAddMatchModal,
        nextUpcomingMatch,
        recordMatchResult,
        whatsappReminderConfig,
        updateWhatsappReminderConfig,
      }}
    >
      {children}
    </TournamentContext.Provider>
  );
};

export const useTournament = () => {
  const context = useContext(TournamentContext);
  if (!context) {
    throw new Error('useTournament must be used within a TournamentProvider');
  }
  return context;
};
