import React, { useState } from 'react';
import {
  BarChart3,
  Flame,
  Target,
  Trophy,
  Crosshair,
  ShieldAlert,
  Zap,
  TrendingUp,
  Percent,
  Award,
  Swords,
  Activity,
  PlusCircle,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';
import { getRankBadge } from '../utils/esportsMath';

import { TeamPerformanceGraph } from '../components/TeamPerformanceGraph';
import { AddMatchHistoryModal } from '../components/AddMatchHistoryModal';

export const AnalyzePage: React.FC = () => {
  const { stats, history, user, openAddMatchModal } = useTournament();
  const [isAddResultOpen, setIsAddResultOpen] = useState(false);

  const rank = getRankBadge(user.rankedScore);

  // Dynamically compute map breakdown from actual saved match history (Requirement 11)
  const mapBreakdown = ['Bermuda', 'Purgatory', 'Kalahari', 'Nexterra', 'Alpine'].map(mapName => {
    const matchesOnMap = history.filter(h => h.map === mapName);
    const count = matchesOnMap.length;
    const wins = matchesOnMap.filter(h => h.rankStatus === 'WIN').length;
    const kills = matchesOnMap.reduce((s, h) => s + h.kills, 0);
    const winRate = count > 0 ? Math.round((wins / count) * 100) : 0;
    const colors: Record<string, string> = {
      Bermuda: '#ffd700',
      Purgatory: '#00f0ff',
      Kalahari: '#ff4655',
      Nexterra: '#00ff88',
      Alpine: '#a855f7',
    };
    return {
      name: mapName,
      matches: count,
      wins,
      kills,
      winRate,
      color: colors[mapName] || '#ffd700',
    };
  }).filter(m => history.length === 0 || m.matches > 0);

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner: Rank Status */}
      <div className="rounded-2xl bg-gradient-to-r from-[#141419] via-[#121218] to-[#0c0c10] border border-[rgba(212,175,55,0.3)] p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-[0_15px_35px_rgba(0,0,0,0.7)]">
        <div className="flex items-center gap-5">
          <div
            className="w-18 h-18 sm:w-20 sm:h-20 rounded-2xl flex items-center justify-center border-2 shadow-lg"
            style={{
              backgroundColor: `${rank.badgeColor}18`,
              borderColor: rank.badgeColor,
              boxShadow: `0 0 25px ${rank.glowColor}`,
            }}
          >
            <Trophy size={40} style={{ color: rank.badgeColor }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                Team Free Fire Rank Status
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-[#ffd700]/20 text-[#ffd700] border border-[#ffd700]/40">
                Verified Records
              </span>
            </div>
            <h2 className="text-2xl font-black text-white mt-1 flex items-center gap-2">
              <span>{rank.title}</span>
              <span className="text-sm font-semibold text-zinc-400">({user.rankedScore} RP)</span>
            </h2>
            <div className="text-xs text-zinc-300 mt-1 flex items-center gap-3">
              <span>Squad: <strong className="text-[#ffd700]">{user.teamName || 'Team Destroyed'}</strong></span>
              <span>•</span>
              <span>Region: <strong className="text-white">{user.serverRegion}</strong></span>
            </div>
          </div>
        </div>

        {/* Dynamic calculation indicator & Quick Action */}
        <div className="flex flex-col sm:flex-row md:flex-col items-start md:items-end justify-between gap-2.5">
          <div className="text-left md:text-right">
            <div className="text-xs text-zinc-400">Calculated From</div>
            <div className="text-sm font-black text-[#ffd700]">{history.length} Saved Match Records</div>
            <div className="text-[10px] text-zinc-500">
              {history.length === 0 ? 'Starts at zero baseline for new accounts' : 'Live recalculated from actual records'}
            </div>
          </div>
          <button
            onClick={() => setIsAddResultOpen(true)}
            className="px-3.5 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-[rgba(212,175,55,0.3)] text-zinc-200 hover:text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <PlusCircle size={14} className="text-[#ffd700]" />
            <span>+ Record Result</span>
          </button>
        </div>
      </div>

      {/* 4 Core Performance Pillars (Strictly from actual data, 0 for new accounts) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Win Rate */}
        <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] hover:border-[#ffd700]/50 transition-all space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-zinc-400">Booyah Win Rate</span>
            <div className="w-10 h-10 rounded-xl bg-[#00ff88]/10 border border-[#00ff88]/25 flex items-center justify-center text-[#00ff88]">
              <Percent size={18} />
            </div>
          </div>
          <div className="text-3xl font-black text-[#00ff88]">{stats.winRate}%</div>
          <div className="text-xs text-zinc-400 flex items-center justify-between">
            <span>{stats.wins} Wins</span>
            <span className="text-zinc-500">{stats.losses} Losses</span>
          </div>
        </div>

        {/* K/D Ratio */}
        <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] hover:border-[#ffd700]/50 transition-all space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-zinc-400">Kill/Death (K/D) Ratio</span>
            <div className="w-10 h-10 rounded-xl bg-[#ffd700]/10 border border-[#ffd700]/25 flex items-center justify-center text-[#ffd700]">
              <Crosshair size={18} />
            </div>
          </div>
          <div className="text-3xl font-black text-[#ffd700]">{stats.kdRatio}</div>
          <div className="text-xs text-zinc-400 flex items-center justify-between">
            <span>{stats.kills} Total Kills</span>
            <span className="text-zinc-500">{stats.deaths} Deaths</span>
          </div>
        </div>

        {/* Headshot Rate */}
        <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] hover:border-[#ffd700]/50 transition-all space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-zinc-400">Headshot Accuracy</span>
            <div className="w-10 h-10 rounded-xl bg-[#ff4655]/10 border border-[#ff4655]/25 flex items-center justify-center text-[#ff4655]">
              <Target size={18} />
            </div>
          </div>
          <div className="text-3xl font-black text-[#ff4655]">{stats.headshotRate}%</div>
          <div className="text-xs text-zinc-400 flex items-center justify-between">
            <span>{stats.headshots} Headshots</span>
            <span className="text-zinc-500">Active</span>
          </div>
        </div>

        {/* Average Damage */}
        <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] hover:border-[#ffd700]/50 transition-all space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-zinc-400">Avg Damage / Match</span>
            <div className="w-10 h-10 rounded-xl bg-[#00f0ff]/10 border border-[#00f0ff]/25 flex items-center justify-center text-[#00f0ff]">
              <Activity size={18} />
            </div>
          </div>
          <div className="text-3xl font-black text-white">{stats.avgDamagePerMatch} <span className="text-sm font-normal text-zinc-400">HP</span></div>
          <div className="text-xs text-zinc-400 flex items-center justify-between">
            <span>{stats.totalDamage} Total DMG</span>
            <span className="text-[#ffd700] font-semibold">{stats.mvpCount} MVPs</span>
          </div>
        </div>
      </div>

      {/* NEW: Premium Interactive Team Performance Progress Graph */}
      <TeamPerformanceGraph
        history={history}
        onAddMatchClick={() => setIsAddResultOpen(true)}
      />

      {/* Deep Analytics or Empty State */}
      {history.length === 0 ? (
        <div className="p-10 rounded-3xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-[#ffd700]/10 border border-[#ffd700]/30 flex items-center justify-center text-[#ffd700] mx-auto">
            <BarChart3 size={28} />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-black text-white">Team Analytics Start at Zero</h3>
            <p className="text-xs text-zinc-400 max-w-md mx-auto">
              No fake data or demo stats are loaded. As you save actual match records and OCR points tables, your squad K/D, win rate, and map dominance will calculate here in real time.
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
            <button
              onClick={() => setIsAddResultOpen(true)}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(255,215,0,0.3)] hover:scale-105 transition-all inline-flex items-center gap-2 cursor-pointer"
            >
              <PlusCircle size={16} />
              <span>+ Record Match Result</span>
            </button>
            <button
              onClick={openAddMatchModal}
              className="px-5 py-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 hover:text-white text-xs font-bold transition-all inline-flex items-center gap-2 cursor-pointer"
            >
              <span>+ Plan New Match</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Map Performance Breakdown */}
          <div className="p-6 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-white text-base flex items-center gap-2">
                  <BarChart3 size={18} className="text-[#ffd700]" />
                  <span>Map Dominance & Win Rates</span>
                </h3>
                <p className="text-xs text-zinc-400">Calculated strictly from your saved match results</p>
              </div>
              <span className="text-xs font-bold text-[#00ff88]">Real Ledger Data</span>
            </div>

            <div className="space-y-4 pt-2">
              {mapBreakdown.map(m => (
                <div key={m.name} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-white">{m.name}</span>
                    <div className="flex items-center gap-3 text-zinc-400">
                      <span>{m.matches} matches</span>
                      <span>{m.kills} kills</span>
                      <span className="font-extrabold text-[#ffd700]">{m.winRate}% Win</span>
                    </div>
                  </div>
                  <div className="w-full h-2.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${m.winRate || 10}%`,
                        backgroundColor: m.color,
                        boxShadow: `0 0 10px ${m.color}60`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Loadout & Squad Insights */}
          <div className="p-6 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] space-y-5">
            <div>
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Swords size={18} className="text-[#ffd700]" />
                <span>Squad Insights & Loadout</span>
              </h3>
              <p className="text-xs text-zinc-400">Team Destroyed competitive configuration</p>
            </div>

            <div className="divide-y divide-zinc-800/80">
              <div className="py-3 first:pt-0 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white text-xs sm:text-sm">Team Name</div>
                  <div className="text-[11px] text-zinc-400">Competitive Free Fire Roster</div>
                </div>
                <div className="text-xs font-extrabold text-[#ffd700]">{user.teamName || 'Team Destroyed'}</div>
              </div>

              <div className="py-3 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white text-xs sm:text-sm">Primary Loadout</div>
                  <div className="text-[11px] text-zinc-400">Preferred in-game weapon combination</div>
                </div>
                <div className="text-xs font-bold text-[#00ff88]">{user.preferredWeapon}</div>
              </div>

              <div className="py-3 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white text-xs sm:text-sm">Total Squad Kills Recorded</div>
                  <div className="text-[11px] text-zinc-400">Accumulated across verified matches</div>
                </div>
                <div className="text-xs font-bold text-white">{stats.kills} Kills</div>
              </div>

              <div className="py-3 last:pb-0 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white text-xs sm:text-sm">Booyah Conversion</div>
                  <div className="text-[11px] text-zinc-400">Percentage of tournament #1 finishes</div>
                </div>
                <div className="text-xs font-bold text-[#00f0ff]">{stats.winRate}%</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Record Match Result Modal (can be triggered directly from Analyze page) */}
      <AddMatchHistoryModal
        isOpen={isAddResultOpen}
        onClose={() => setIsAddResultOpen(false)}
      />
    </div>
  );
};

