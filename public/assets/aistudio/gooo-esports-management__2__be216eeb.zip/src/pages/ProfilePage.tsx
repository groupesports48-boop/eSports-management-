import React, { useState, useRef } from 'react';
import {
  User,
  ShieldCheck,
  Trophy,
  Copy,
  Check,
  Edit3,
  Flame,
  Award,
  Save,
  Crosshair,
  MapPin,
  CheckCircle2,
  Camera,
  Image as ImageIcon,
  Users,
  Phone,
  FileText,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';
import { getRankBadge } from '../utils/esportsMath';

export const ProfilePage: React.FC = () => {
  const { user, history, stats, updateUserProfile } = useTournament();

  const [copiedUid, setCopiedUid] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  // Form states for profile editing (Requirement 13)
  const [teamName, setTeamName] = useState(user.teamName || 'Team Destroyed');
  const [teamTag, setTeamTag] = useState(user.teamTag || 'DST');
  const [teamBio, setTeamBio] = useState(user.teamBio || 'Official Free Fire India competitive roster for scrims and tournaments.');
  const [editIgn, setEditIgn] = useState(user.ign);
  const [editName, setEditName] = useState(user.name);
  const [editPhone, setEditPhone] = useState(user.phone || '+91 98765 43210');
  const [editGuild, setEditGuild] = useState(user.guild);
  const [editWeapon, setEditWeapon] = useState(user.preferredWeapon);
  const [editServer, setEditServer] = useState(user.serverRegion);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const avatarInputRef = useRef<HTMLInputElement>(null);
  const bannerInputRef = useRef<HTMLInputElement>(null);

  const rank = getRankBadge(user.rankedScore);

  const copyUid = () => {
    navigator.clipboard.writeText(user.freeFireUid);
    setCopiedUid(true);
    setTimeout(() => setCopiedUid(false), 2000);
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      updateUserProfile({ avatarUrl: result });
    };
    reader.readAsDataURL(file);
  };

  const handleBannerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      updateUserProfile({ bannerUrl: result });
    };
    reader.readAsDataURL(file);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({
      teamName: teamName.trim(),
      teamTag: teamTag.trim(),
      teamBio: teamBio.trim(),
      ign: editIgn.trim(),
      name: editName.trim(),
      phone: editPhone.trim(),
      guild: editGuild.trim(),
      preferredWeapon: editWeapon.trim(),
      serverRegion: editServer.trim(),
    });
    setIsEditing(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Team Banner Upload Section (Requirement 13) */}
      <div className="relative rounded-3xl overflow-hidden border border-[rgba(212,175,55,0.3)] bg-gradient-to-r from-[#141419] to-[#0c0c10] shadow-xl">
        {/* Banner Graphic or Uploaded Image */}
        <div className="h-44 sm:h-56 w-full relative bg-[#09090c] overflow-hidden">
          {user.bannerUrl ? (
            <img
              src={user.bannerUrl}
              alt="Team Destroyed Banner"
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-r from-[#1a1505] via-[#0f0f13] to-[#120a15] flex items-center justify-center relative">
              <div className="absolute inset-0 bg-[radial-gradient(#ffd700_1px,transparent_1px)] [background-size:20px_20px] opacity-15" />
              <div className="text-center z-10 space-y-1">
                <span className="text-2xl sm:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-[#ffd700] via-[#ffe359] to-[#d4af37] tracking-widest">
                  {user.teamName || 'DESTROYED eSPORTS'}
                </span>
                <p className="text-xs text-zinc-400 font-mono tracking-wider">
                  [{user.teamTag || 'DST'}] COMPETITIVE ROSTER
                </p>
              </div>
            </div>
          )}

          {/* Banner Upload Trigger */}
          <input
            type="file"
            ref={bannerInputRef}
            onChange={handleBannerUpload}
            accept="image/*"
            className="hidden"
          />
          <button
            onClick={() => bannerInputRef.current?.click()}
            className="absolute top-4 right-4 px-3 py-1.5 rounded-xl bg-black/75 hover:bg-black text-white text-xs font-bold border border-[rgba(212,175,55,0.4)] backdrop-blur-md transition-all flex items-center gap-1.5 shadow-lg cursor-pointer"
          >
            <Camera size={13} className="text-[#ffd700]" />
            <span>Upload Team Banner</span>
          </button>
        </div>

        {/* Profile Card & Avatar Row */}
        <div className="p-6 lg:p-8 pt-0 relative -mt-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-center sm:items-end gap-5 text-center sm:text-left">
            {/* Avatar with Upload Trigger (Requirement 13) */}
            <div className="relative group shrink-0">
              <img
                src={user.avatarUrl || '/assets/aistudio/photo__1__f37c447f.jpg'}
                alt={user.ign}
                className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover border-4 border-[#ffd700] shadow-[0_0_25px_rgba(255,215,0,0.4)] bg-[#0f0f13]"
              />
              <input
                type="file"
                ref={avatarInputRef}
                onChange={handleAvatarUpload}
                accept="image/*"
                className="hidden"
              />
              <button
                onClick={() => avatarInputRef.current?.click()}
                title="Change Profile Picture"
                className="absolute inset-0 rounded-2xl bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-[10px] font-bold gap-1 cursor-pointer"
              >
                <Camera size={20} className="text-[#ffd700]" />
                <span>Upload</span>
              </button>
              <span className="absolute -bottom-2 -right-2 px-2 py-0.5 rounded-full bg-[#00ff88] text-[9px] font-black text-black shadow">
                LEADER
              </span>
            </div>

            {/* Identity Info */}
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <h1 className="text-2xl lg:text-3xl font-black text-white">{user.ign}</h1>
                <ShieldCheck size={20} className="text-[#00f0ff]" />
                <span
                  className="px-3 py-0.5 rounded-full text-xs font-black border"
                  style={{
                    backgroundColor: `${rank.badgeColor}20`,
                    color: rank.badgeColor,
                    borderColor: `${rank.badgeColor}40`,
                  }}
                >
                  {rank.title}
                </span>
              </div>

              {/* UID */}
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <span className="text-xs text-zinc-400">Player UID:</span>
                <span className="font-mono font-bold text-white text-xs bg-zinc-900 px-2.5 py-1 rounded-lg border border-zinc-800">
                  {user.freeFireUid}
                </span>
                <button
                  onClick={copyUid}
                  className="p-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-[#ffd700] transition-colors cursor-pointer"
                  title="Copy UID"
                >
                  {copiedUid ? <Check size={13} className="text-[#00ff88]" /> : <Copy size={13} />}
                </button>
                {copiedUid && <span className="text-[11px] text-[#00ff88] font-bold">Copied!</span>}
              </div>

              {/* Team and Guild Badges */}
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 text-xs text-zinc-400 pt-0.5">
                <span>Team: <strong className="text-[#ffd700] font-bold">{user.teamName || 'Team Destroyed'}</strong></span>
                <span>•</span>
                <span>Tag: <strong className="text-zinc-200">[{user.teamTag || 'DST'}]</strong></span>
                <span>•</span>
                <span>Guild: <span className="text-zinc-200">{user.guild}</span></span>
                <span>•</span>
                <span>Region: <span className="text-white">{user.serverRegion}</span></span>
              </div>
            </div>
          </div>

          {/* Edit Profile Action */}
          <div className="flex items-center justify-center sm:justify-end gap-3">
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-[rgba(212,175,55,0.3)] text-white text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Edit3 size={15} className="text-[#ffd700]" />
              <span>{isEditing ? 'Cancel Edit' : 'Edit Team & Profile'}</span>
            </button>
          </div>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-3.5 rounded-xl bg-[#00ff88]/15 border border-[#00ff88]/30 text-[#00ff88] text-xs font-bold flex items-center gap-2">
          <CheckCircle2 size={16} />
          <span>Team profile and information updated successfully!</span>
        </div>
      )}

      {/* Edit Form Drawer (Requirement 13) */}
      {isEditing && (
        <form onSubmit={handleSave} className="p-6 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.3)] space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Users size={16} className="text-[#ffd700]" />
              <span>Edit Team & Player Information</span>
            </h3>
            <span className="text-xs text-zinc-400">All changes save persistently</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">Team Name</label>
              <input
                type="text"
                value={teamName}
                onChange={e => setTeamName(e.target.value)}
                placeholder="Team Destroyed"
                className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white text-xs focus:border-[#ffd700] focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">Team Tag</label>
              <input
                type="text"
                value={teamTag}
                onChange={e => setTeamTag(e.target.value)}
                placeholder="DST"
                className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white text-xs focus:border-[#ffd700] focus:outline-none uppercase"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">In-Game Name (IGN)</label>
              <input
                type="text"
                value={editIgn}
                onChange={e => setEditIgn(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white text-xs focus:border-[#ffd700] focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">Leader / Manager Name</label>
              <input
                type="text"
                value={editName}
                onChange={e => setEditName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white text-xs focus:border-[#ffd700] focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">WhatsApp / Phone</label>
              <input
                type="text"
                value={editPhone}
                onChange={e => setEditPhone(e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white text-xs focus:border-[#ffd700] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">Guild / Clan</label>
              <input
                type="text"
                value={editGuild}
                onChange={e => setEditGuild(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white text-xs focus:border-[#ffd700] focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">Primary Weapon Loadout</label>
              <input
                type="text"
                value={editWeapon}
                onChange={e => setEditWeapon(e.target.value)}
                placeholder="AWM / MP40"
                className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white text-xs focus:border-[#ffd700] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">Region / Server</label>
              <input
                type="text"
                value={editServer}
                onChange={e => setEditServer(e.target.value)}
                placeholder="India (IND)"
                className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white text-xs focus:border-[#ffd700] focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1">Team Bio / Overview</label>
            <textarea
              rows={2}
              value={teamBio}
              onChange={e => setTeamBio(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white text-xs focus:border-[#ffd700] focus:outline-none"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 rounded-xl bg-zinc-900 text-zinc-400 text-xs font-bold hover:bg-zinc-800 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#ffd700] hover:bg-[#ffe234] text-black font-extrabold text-xs transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <Save size={14} />
              <span>Save Changes</span>
            </button>
          </div>
        </form>
      )}

      {/* Rank Badges & Progression Showcase */}
      <div className="p-6 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] space-y-4">
        <div>
          <h3 className="font-bold text-white text-base flex items-center gap-2">
            <Award size={18} className="text-[#ffd700]" />
            <span>Competitive Rank Badges</span>
          </h3>
          <p className="text-xs text-zinc-400">Current seasonal tier and achievements</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          {/* Badge 1: Grandmaster */}
          <div className="p-4 rounded-xl bg-[#ff0055]/10 border border-[#ff0055]/30 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-[#ff0055]">{rank.title}</span>
              <span className="text-[10px] font-bold text-white bg-[#ff0055] px-2 py-0.5 rounded-full">ACTIVE</span>
            </div>
            <div className="text-xs text-zinc-300">{user.rankedScore} Rating Points • {user.serverRegion}</div>
          </div>

          {/* Badge 2: Tournament Win Rate */}
          <div className="p-4 rounded-xl bg-[#00ff88]/10 border border-[#00ff88]/30 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-[#00ff88]">Booyah Win Rate</span>
              <span className="text-[10px] font-bold text-[#00ff88]">{stats.winRate}%</span>
            </div>
            <div className="text-xs text-zinc-300">{stats.wins} Wins out of {stats.totalMatches} verified matches</div>
          </div>

          {/* Badge 3: Team Roster */}
          <div className="p-4 rounded-xl bg-[#00f0ff]/10 border border-[#00f0ff]/30 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-[#00f0ff]">{user.teamName || 'Team Destroyed'}</span>
              <span className="text-[10px] font-bold text-[#00f0ff]">[{user.teamTag || 'DST'}]</span>
            </div>
            <div className="text-xs text-zinc-300">{user.teamBio}</div>
          </div>
        </div>
      </div>

      {/* Personal Tournament Record Table */}
      <div className="space-y-4">
        <div>
          <h3 className="font-bold text-white text-base">Personal Tournament Records</h3>
          <p className="text-xs text-zinc-400">Match results tied to your Free Fire UID</p>
        </div>

        {history.length === 0 ? (
          <div className="p-8 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.15)] text-center text-zinc-500 text-xs">
            No match records yet. Recorded matches from History or Dashboard will appear here.
          </div>
        ) : (
          <div className="rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] overflow-hidden">
            <div className="overflow-x-auto">
              <table className="gold-table">
                <thead>
                  <tr>
                    <th>Match ID</th>
                    <th>Tournament</th>
                    <th>Mode / Map</th>
                    <th>Kills</th>
                    <th>Status</th>
                    <th>Prize Earned</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map(m => (
                    <tr key={m.id}>
                      <td className="font-mono text-zinc-300 text-xs font-bold">{m.matchId}</td>
                      <td className="font-semibold text-white text-xs">{m.tournamentName}</td>
                      <td className="text-zinc-400 text-xs">{m.gameMode} • {m.map}</td>
                      <td className="font-bold text-[#ffd700] text-center text-xs">{m.kills}</td>
                      <td>
                        {m.rankStatus === 'WIN' && (
                          <span className="esports-badge esports-badge-green">#1 WIN</span>
                        )}
                        {m.rankStatus === 'PODIUM' && (
                          <span className="esports-badge esports-badge-gold">#{m.placement} PODIUM</span>
                        )}
                        {m.rankStatus === 'LOSS' && (
                          <span className="esports-badge esports-badge-red">LOSS</span>
                        )}
                      </td>
                      <td className="font-mono font-bold text-xs text-[#00ff88]">
                        +₹{m.prizeWon}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
