import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Swords,
  PlusCircle,
  Calendar,
  Clock,
  MessageCircle,
  TrendingUp,
  Sparkles,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';
import { calculateISTCountdown, formatCurrencyINR } from '../utils/esportsMath';

interface LandingPageProps {
  onNavigate: (page: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  const {
    tournaments,
    nextUpcomingMatch,
    openAddMatchModal,
    user,
    stats,
    history,
    netProfitSum,
  } = useTournament();

  const [nowMs, setNowMs] = useState(Date.now());

  // Ticking countdown
  useEffect(() => {
    const timer = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const countdown = nextUpcomingMatch
    ? calculateISTCountdown(nextUpcomingMatch.targetTimestampMs, nowMs)
    : null;

  const upcomingMatches = tournaments.filter(t => t.status !== 'COMPLETED');

  return (
    <div className="space-y-10 pb-16">
      {/* Hero: Personal Match Planner Header */}
      <section className="relative rounded-3xl overflow-hidden border border-[rgba(212,175,55,0.28)] bg-gradient-to-br from-[#0c0c10] via-[#121217] to-[#07070a] p-6 sm:p-10 lg:p-12 shadow-[0_20px_50px_rgba(0,0,0,0.85)]">
        {/* Ambient glow */}
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-[#ffd700]/10 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-[#ff4655]/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-center gap-8 justify-between">
          <div className="max-w-2xl space-y-5">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#ffd700]/10 border border-[#ffd700]/30 text-[#ffd700] text-xs font-bold uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-[#ffd700] animate-ping" />
              <span>Personal Free Fire eSports Match Planner</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
              DESTROYED <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#ffd700] via-[#ffe359] to-[#d4af37]">
                ESPORTS MANAGEMENT
              </span>
            </h1>

            <p className="text-sm sm:text-base text-zinc-300 max-w-xl leading-relaxed">
              Plan, schedule, and track <strong className="text-white">MY tournaments</strong>, <strong className="text-white">MY lobbies</strong>, <strong className="text-white">MY team ({user.teamName || 'Team Destroyed'})</strong>, and match results with automated reminders.
            </p>

            {/* 4-Step Planner Flow Visualizer */}
            <div className="p-3.5 rounded-2xl bg-[#09090c]/90 border border-[rgba(212,175,55,0.2)] text-xs text-zinc-300 flex flex-wrap items-center gap-2">
              <span className="text-[#ffd700] font-black tracking-wide uppercase text-[11px]">Workflow:</span>
              <span className="px-2 py-0.5 rounded bg-zinc-800 text-white font-semibold">1. Add Match</span>
              <span className="text-zinc-500">→</span>
              <span className="px-2 py-0.5 rounded bg-zinc-800 text-white font-semibold">2. Auto-Saves</span>
              <span className="text-zinc-500">→</span>
              <span className="px-2 py-0.5 rounded bg-zinc-800 text-[#00ff88] font-semibold">3. Dashboard Countdown</span>
              <span className="text-zinc-500">→</span>
              <span className="px-2 py-0.5 rounded bg-zinc-800 text-[#00f0ff] font-semibold">4. WhatsApp Reminds Me</span>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 pt-2">
              <button
                onClick={openAddMatchModal}
                className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-extrabold text-sm uppercase tracking-wider transition-all hover:scale-105 shadow-[0_0_25px_rgba(255,215,0,0.35)] flex items-center gap-2 cursor-pointer"
              >
                <PlusCircle size={18} />
                <span>+ Plan / Add Match</span>
              </button>
              <button
                onClick={() => onNavigate('dashboard')}
                className="px-6 py-3.5 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 border border-[rgba(212,175,55,0.3)] text-white font-bold text-sm tracking-wide transition-all flex items-center gap-2 cursor-pointer"
              >
                <Trophy size={18} className="text-[#ffd700]" />
                <span>My Dashboard HUD</span>
              </button>
              <button
                onClick={() => onNavigate('schedule')}
                className="px-5 py-3.5 rounded-xl bg-zinc-900/70 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 hover:text-white font-bold text-sm transition-all flex items-center gap-2 cursor-pointer"
              >
                <Calendar size={18} className="text-[#00f0ff]" />
                <span>My Schedule</span>
              </button>
            </div>
          </div>

          {/* Official Crest & Captain Card */}
          <div className="relative shrink-0 flex flex-col items-center">
            <div className="relative group">
              <img
                src={user.avatarUrl || '/assets/aistudio/photo__1__f37c447f.jpg'}
                alt="Destroyed eSports Official Crest"
                className="w-44 h-44 sm:w-52 sm:h-52 rounded-3xl object-cover border-4 border-[#ffd700] shadow-[0_0_40px_rgba(255,215,0,0.35)] group-hover:scale-105 transition-transform"
              />
              <span className="absolute -bottom-3 -right-3 px-3 py-1 rounded-full bg-[#00ff88] text-black font-black text-xs uppercase tracking-wider border-2 border-[#0c0c10] shadow-lg">
                LEADER
              </span>
            </div>
            <div className="mt-3.5 text-center">
              <div className="text-sm font-black tracking-wider text-white">{user.ign}</div>
              <div className="text-xs text-[#ffd700] font-mono">UID: {user.freeFireUid} • Squad: {user.teamName || 'Team Destroyed'}</div>
            </div>
          </div>
        </div>

        {/* 4 Fast Metrics for Captain */}
        <div className="relative z-10 grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8 pt-6 border-t border-zinc-800/80">
          <div>
            <div className="text-xs text-zinc-400 font-medium">Planned Matches</div>
            <div className="text-xl sm:text-2xl font-black text-[#ffd700]">{upcomingMatches.length} Upcoming</div>
          </div>
          <div>
            <div className="text-xs text-zinc-400 font-medium">Completed Matches</div>
            <div className="text-xl sm:text-2xl font-black text-white">{history.length} Saved</div>
          </div>
          <div>
            <div className="text-xs text-zinc-400 font-medium">Net Tournament Profit</div>
            <div className={`text-xl sm:text-2xl font-black ${netProfitSum >= 0 ? 'text-[#00ff88]' : 'text-red-400'}`}>
              {netProfitSum >= 0 ? `+${formatCurrencyINR(netProfitSum)}` : formatCurrencyINR(netProfitSum)}
            </div>
          </div>
          <div>
            <div className="text-xs text-zinc-400 font-medium">Squad Win Rate</div>
            <div className="text-xl sm:text-2xl font-black text-[#00f0ff]">{stats.winRate}% ({stats.wins}W / {stats.losses}L)</div>
          </div>
        </div>
      </section>

      {/* Hero Spotlight: NEXT UPCOMING MATCH (Without Room ID / Password) */}
      {nextUpcomingMatch && countdown && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-white flex items-center gap-2">
                <Clock size={20} className="text-[#ffd700]" />
                <span>Next Upcoming Match Spotlight</span>
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#ffd700]/15 text-[#ffd700] border border-[#ffd700]/30 animate-pulse">
                AUTO-SYNCED (IST)
              </span>
            </div>
            <button
              onClick={() => onNavigate('dashboard')}
              className="text-xs font-bold text-[#ffd700] hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>View On Dashboard</span>
              <ChevronRight size={14} />
            </button>
          </div>

          <div className="rounded-3xl bg-gradient-to-br from-[#121217] via-[#0f0f14] to-[#0a0a0d] border-2 border-[#ffd700]/50 p-6 sm:p-8 shadow-[0_15px_40px_rgba(255,215,0,0.15)] relative overflow-hidden">
            <div className="absolute top-0 right-0 w-80 h-80 rounded-full bg-[#ffd700]/10 blur-3xl pointer-events-none" />
            <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              {/* Left Details */}
              <div className="space-y-3 max-w-xl">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-black px-3 py-1 rounded-full bg-[#ffd700] text-black">
                    {nextUpcomingMatch.format}
                  </span>
                  <span className="text-xs font-bold px-3 py-1 rounded-full bg-zinc-800 text-zinc-200 border border-zinc-700">
                    {nextUpcomingMatch.map}
                  </span>
                  <span className="text-xs font-bold px-3 py-1 rounded-full bg-zinc-800 text-zinc-300">
                    {nextUpcomingMatch.seriesFormat}
                  </span>
                  <span
                    className={`text-xs font-extrabold px-3 py-1 rounded-full uppercase tracking-wider ${
                      nextUpcomingMatch.status === 'LIVE'
                        ? 'bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/40'
                        : 'bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40'
                    }`}
                  >
                    {nextUpcomingMatch.status === 'LIVE' ? '● LIVE IN PROGRESS' : 'UPCOMING'}
                  </span>
                </div>

                <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                  {nextUpcomingMatch.title}
                </h3>
                <p className="text-xs sm:text-sm text-zinc-300">
                  Kickoff scheduled: <strong className="text-white">{nextUpcomingMatch.startTimeIST}</strong> • Squad: <strong className="text-[#ffd700]">{user.teamName || 'Team Destroyed'}</strong>
                  {nextUpcomingMatch.opponentSquad && (
                    <span> vs <strong className="text-[#00f0ff]">{nextUpcomingMatch.opponentSquad}</strong></span>
                  )}
                </p>

                {nextUpcomingMatch.strategyNotes && (
                  <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 text-xs text-zinc-300">
                    <span className="font-bold text-[#ffd700]">Squad Strategy: </span>
                    <span>{nextUpcomingMatch.strategyNotes}</span>
                  </div>
                )}
              </div>

              {/* Right: Live Ticking Countdown Box & WhatsApp Action (Requirement 4 & 7) */}
              <div className="shrink-0 flex flex-col items-center lg:items-end space-y-4">
                <div className="p-4 rounded-2xl bg-[#08080a] border border-[rgba(212,175,55,0.3)] text-center min-w-[260px] shadow-lg">
                  <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-widest flex items-center justify-center gap-1.5 mb-2">
                    <Clock size={13} className="text-[#ffd700]" />
                    <span>IST Match Kickoff Timer</span>
                  </div>

                  {countdown.isLive ? (
                    <div className="py-2 text-xl font-black text-[#00ff88] flex items-center justify-center gap-2">
                      <span className="w-3 h-3 rounded-full bg-[#00ff88] animate-ping" />
                      <span>MATCH LIVE NOW!</span>
                    </div>
                  ) : (
                    <div className="grid grid-cols-3 gap-2">
                      <div className="p-2 rounded-xl bg-zinc-900 border border-zinc-800">
                        <div className="text-xl sm:text-2xl font-black text-[#ffd700] font-mono">
                          {countdown.hours.toString().padStart(2, '0')}
                        </div>
                        <div className="text-[9px] text-zinc-400 uppercase">Hours</div>
                      </div>
                      <div className="p-2 rounded-xl bg-zinc-900 border border-zinc-800">
                        <div className="text-xl sm:text-2xl font-black text-[#ffd700] font-mono">
                          {countdown.minutes.toString().padStart(2, '0')}
                        </div>
                        <div className="text-[9px] text-zinc-400 uppercase">Mins</div>
                      </div>
                      <div className="p-2 rounded-xl bg-zinc-900 border border-zinc-800">
                        <div className="text-xl sm:text-2xl font-black text-[#ffd700] font-mono">
                          {countdown.seconds.toString().padStart(2, '0')}
                        </div>
                        <div className="text-[9px] text-zinc-400 uppercase">Secs</div>
                      </div>
                    </div>
                  )}
                </div>

                {/* WhatsApp Group Link or Action Button */}
                {nextUpcomingMatch.whatsAppGroupUrl ? (
                  <a
                    href={nextUpcomingMatch.whatsAppGroupUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 px-4 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-black text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_15px_rgba(37,211,102,0.3)]"
                  >
                    <MessageCircle size={15} />
                    <span>Join Match WhatsApp Group</span>
                    <ExternalLink size={13} />
                  </a>
                ) : (
                  <a
                    href={`https://wa.me/?text=${encodeURIComponent(
                      `🏆 *TEAM DESTROYED MATCH ALERT* 🏆\nMatch: ${nextUpcomingMatch.title}\nTime: ${nextUpcomingMatch.startTimeIST}\nFormat: ${nextUpcomingMatch.format} (${nextUpcomingMatch.map})\nSquad be ready 10 mins before!`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 px-4 rounded-xl bg-[#25D366]/15 hover:bg-[#25D366]/25 border border-[#25D366]/40 text-[#25D366] text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <MessageCircle size={15} />
                    <span>Send Squad WhatsApp Reminder</span>
                  </a>
                )}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* The 4-Step Planner Guide */}
      <section className="space-y-4">
        <div>
          <h2 className="text-lg lg:text-xl font-black text-white flex items-center gap-2">
            <Sparkles size={20} className="text-[#ffd700]" />
            <span>How My Match Planner Works</span>
          </h2>
          <p className="text-xs text-zinc-400">
            A frictionless personal esports planner designed specifically for {user.teamName || 'Team Destroyed'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] space-y-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#ffd700]/15 border border-[#ffd700]/30 flex items-center justify-center text-[#ffd700] font-black text-sm">
              01
            </div>
            <h3 className="font-bold text-white text-sm">I Add My Match</h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Input match title, squad format (Solo, Duo, Squad), map, kickoff time in IST, and WhatsApp group link.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] space-y-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#00f0ff]/15 border border-[#00f0ff]/30 flex items-center justify-center text-[#00f0ff] font-black text-sm">
              02
            </div>
            <h3 className="font-bold text-white text-sm">Website Saves It</h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Instantly persists into private match storage with dedicated WhatsApp coordinator group access.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] space-y-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#00ff88]/15 border border-[#00ff88]/30 flex items-center justify-center text-[#00ff88] font-black text-sm">
              03
            </div>
            <h3 className="font-bold text-white text-sm">Dashboard Shows Countdown</h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Live ticking IST countdown timer, 1-click WhatsApp group join, and strategy notes at your fingertips.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] space-y-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#ff4655]/15 border border-[#ff4655]/30 flex items-center justify-center text-[#ff4655] font-black text-sm">
              04
            </div>
            <h3 className="font-bold text-white text-sm">Notification Reminds Me</h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Automated in-app alert and 1-tap WhatsApp broadcast message sent directly to squad mates before start.
            </p>
          </div>
        </div>
      </section>

      {/* Planned Matches Feed */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg lg:text-xl font-black text-white flex items-center gap-2">
              <Calendar size={20} className="text-[#ffd700]" />
              <span>My Planned Matches & Scrims</span>
            </h2>
            <p className="text-xs text-zinc-400">Real-time schedule for {user.teamName || 'Team Destroyed'}</p>
          </div>

          <button
            onClick={openAddMatchModal}
            className="text-xs font-bold text-black bg-[#ffd700] hover:bg-[#ffe234] px-3.5 py-1.5 rounded-xl transition-all shadow-[0_0_12px_rgba(255,215,0,0.25)] flex items-center gap-1.5 cursor-pointer"
          >
            <PlusCircle size={14} />
            <span>+ Plan Match</span>
          </button>
        </div>

        {upcomingMatches.length === 0 ? (
          <div className="p-8 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.15)] text-center text-zinc-500 text-xs py-8">
            No matches scheduled yet. Click <strong className="text-[#ffd700] cursor-pointer" onClick={openAddMatchModal}>+ Plan Match</strong> to schedule your first game.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {upcomingMatches.slice(0, 6).map(tour => (
              <div
                key={tour.id}
                className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] hover:border-[#ffd700]/50 transition-all space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-[#ffd700]/15 text-[#ffd700] border border-[#ffd700]/30">
                    {tour.format}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                      tour.status === 'LIVE'
                        ? 'bg-[#00ff88]/20 text-[#00ff88]'
                        : 'bg-[#00f0ff]/20 text-[#00f0ff]'
                    }`}
                  >
                    {tour.status}
                  </span>
                </div>

                <div>
                  <h4 className="font-bold text-white text-sm line-clamp-1">{tour.title}</h4>
                  <div className="text-xs text-zinc-400 mt-0.5">{tour.map} • {tour.startTimeIST}</div>
                </div>

                {tour.whatsAppGroupUrl ? (
                  <a
                    href={tour.whatsAppGroupUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-3 rounded-xl bg-[#25D366]/15 hover:bg-[#25D366]/25 border border-[#25D366]/30 text-[#25D366] font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <MessageCircle size={14} />
                    <span>Join WhatsApp Group</span>
                    <ExternalLink size={12} />
                  </a>
                ) : (
                  <button
                    onClick={() => onNavigate('dashboard')}
                    className="w-full py-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <span>View in Dashboard HUD</span>
                    <ChevronRight size={13} />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
