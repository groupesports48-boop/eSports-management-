import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  Mail,
  User,
  Hash,
  ArrowRight,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  Sparkles,
  Phone,
  MapPin,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';
import { validateFreeFireUID } from '../utils/esportsMath';

interface LoginPageProps {
  onNavigate: (page: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onNavigate }) => {
  const { login, signup, resetPassword } = useTournament();

  // Sign Up is the default screen (Requirement 1)
  const [authMode, setAuthMode] = useState<'signup' | 'login' | 'forgot'>('signup');

  // Input states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [ffUid, setFfUid] = useState('');
  const [ign, setIgn] = useState('');
  const [phone, setPhone] = useState('');
  const [regionState, setRegionState] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Validation & status states
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Validation checks
  const isUidValid = validateFreeFireUID(ffUid);
  const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const isPasswordStrong = password.length >= 6;

  // Demo autofill for quick testing
  const handleQuickDemoFill = () => {
    setEmail('groupesports48@gmail.com');
    setPassword('Destroyed#2026');
    setFfUid('99482103');
    setIgn('DESTROYER_VIPER');
    setFullName('Aman "Destroyer" Sharma');
    setPhone('+91 98765 43210');
    setRegionState('India (IND)');
    setErrorMsg(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (authMode === 'forgot') {
      if (!isEmailValid) {
        setErrorMsg('Please enter a valid registered email address.');
        return;
      }
      setIsSubmitting(true);
      setTimeout(() => {
        resetPassword(email);
        setIsSubmitting(false);
        setSuccessMsg(`A password reset link with verification OTP has been dispatched to ${email}.`);
      }, 600);
      return;
    }

    if (!isEmailValid) {
      setErrorMsg('Please enter a valid registered email address.');
      return;
    }

    if (!isPasswordStrong) {
      setErrorMsg('Password must be at least 6 characters.');
      return;
    }

    if (authMode === 'signup') {
      if (!fullName.trim()) {
        setErrorMsg('Please enter your full name or manager name.');
        return;
      }
      if (!isUidValid) {
        setErrorMsg('Free Fire Player UID must be 8 to 12 numeric digits (e.g. 99482103).');
        return;
      }
      if (!ign.trim()) {
        setErrorMsg('Please enter your Free Fire In-Game Name (IGN).');
        return;
      }

      setIsSubmitting(true);
      setTimeout(() => {
        signup(fullName.trim(), email.trim(), ffUid.trim(), ign.trim(), {
          phone: phone.trim() || '+91 98765 43210',
          serverRegion: regionState.trim() || 'India (IND)',
        });
        setIsSubmitting(false);
        setSuccessMsg('Account created successfully! Redirecting to Dashboard...');
        setTimeout(() => {
          onNavigate('dashboard');
        }, 800);
      }, 700);
    } else {
      // Login
      setIsSubmitting(true);
      setTimeout(() => {
        login(email.trim(), ffUid.trim() || '99482103', ign.trim() || 'DESTROYER_VIPER');
        setIsSubmitting(false);
        setSuccessMsg('Welcome back! Verified Free Fire credentials. Redirecting...');
        setTimeout(() => {
          onNavigate('dashboard');
        }, 800);
      }, 600);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-8 px-4">
      <div className="w-full max-w-lg rounded-3xl bg-[#0f0f13] border border-[rgba(212,175,55,0.3)] shadow-[0_25px_60px_rgba(0,0,0,0.9)] p-6 sm:p-10 relative overflow-hidden">
        {/* Glow ambient background */}
        <div className="absolute -top-24 -right-24 w-56 h-56 rounded-full bg-[#ffd700]/10 blur-3xl pointer-events-none" />

        {/* Brand Header & Centered Avatar */}
        <div className="text-center space-y-3 mb-7">
          <div className="relative inline-flex items-center justify-center">
            <div className="relative">
              <img
                src="/assets/aistudio/photo__1__f37c447f.jpg"
                alt="Destroyed eSports Crest"
                className="w-18 h-18 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-[#ffd700] shadow-[0_0_30px_rgba(255,215,0,0.4)] mx-auto"
              />
              <span className="absolute -bottom-1 -right-1 px-2 py-0.5 rounded-full bg-[#00ff88] text-[9px] font-black text-black border border-[#0f0f13]">
                PRO
              </span>
            </div>
          </div>

          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-wider flex items-center justify-center gap-2">
              <span>DESTROYED</span>
              <span className="text-[#ffd700]">ESPORTS</span>
            </h1>
            <p className="text-[11px] text-[#ffd700] font-black tracking-widest uppercase mt-0.5">
              eSports Management
            </p>
          </div>

          <p className="text-xs text-zinc-400 max-w-sm mx-auto">
            {authMode === 'signup' && 'Create your account to manage Team Destroyed matches, rosters, and results.'}
            {authMode === 'login' && 'Sign in to access your personal match planner, countdowns, and ledger.'}
            {authMode === 'forgot' && 'Reset your password and recover your Free Fire management account.'}
          </p>
        </div>

        {/* Tab Switcher: Sign Up default, Login second, Forgot Password third */}
        <div className="flex rounded-xl bg-[#09090c] p-1 mb-6 border border-zinc-800">
          <button
            type="button"
            onClick={() => {
              setAuthMode('signup');
              setErrorMsg(null);
              setSuccessMsg(null);
            }}
            className={`flex-1 py-2.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              authMode === 'signup'
                ? 'bg-[#ffd700] text-black shadow-md font-extrabold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Sign Up
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMode('login');
              setErrorMsg(null);
              setSuccessMsg(null);
            }}
            className={`flex-1 py-2.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              authMode === 'login'
                ? 'bg-[#ffd700] text-black shadow-md font-extrabold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMode('forgot');
              setErrorMsg(null);
              setSuccessMsg(null);
            }}
            className={`flex-1 py-2.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              authMode === 'forgot'
                ? 'bg-[#ffd700] text-black shadow-md font-extrabold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Forgot Password
          </button>
        </div>

        {/* Demo Autofill Helper */}
        <div className="mb-4 flex justify-end">
          <button
            type="button"
            onClick={handleQuickDemoFill}
            className="text-[11px] font-semibold text-[#ffd700] bg-[#ffd700]/10 hover:bg-[#ffd700]/20 border border-[#ffd700]/30 px-3 py-1 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Sparkles size={12} />
            <span>Autofill Sample Details</span>
          </button>
        </div>

        {/* Alert Feedback */}
        {errorMsg && (
          <div className="mb-5 p-3.5 rounded-xl bg-[#ff4655]/15 border border-[#ff4655]/40 text-[#ff4655] text-xs font-semibold flex items-center gap-2">
            <AlertCircle size={16} className="shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-5 p-3.5 rounded-xl bg-[#00ff88]/15 border border-[#00ff88]/40 text-[#00ff88] text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 size={16} className="shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Main Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Full Name (Sign Up only) */}
          {authMode === 'signup' && (
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1">
                Full Name / Team Leader Name <span className="text-[#ffd700]">*</span>
              </label>
              <div className="relative">
                <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400 pointer-events-none" />
                <input
                  type="text"
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  placeholder="e.g. Aman Sharma"
                  className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-[#141419] border border-[rgba(212,175,55,0.25)] focus:border-[#ffd700] text-white text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none transition-colors"
                  required
                />
              </div>
            </div>
          )}

          {/* Email Input */}
          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1">
              Email Address <span className="text-[#ffd700]">*</span>
            </label>
            <div className="relative">
              <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400 pointer-events-none" />
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="groupesports48@gmail.com"
                className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-[#141419] border border-[rgba(212,175,55,0.25)] focus:border-[#ffd700] text-white text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none transition-colors"
                required
              />
            </div>
          </div>

          {/* Sign Up extra fields */}
          {authMode === 'signup' && (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Free Fire UID */}
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1 flex items-center justify-between">
                    <span>Free Fire UID <span className="text-[#ffd700]">*</span></span>
                    <span className={`text-[10px] ${isUidValid ? 'text-[#00ff88]' : 'text-zinc-500'}`}>
                      {isUidValid ? '✓ Valid' : '8-12 digits'}
                    </span>
                  </label>
                  <div className="relative">
                    <Hash size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400 pointer-events-none" />
                    <input
                      type="text"
                      value={ffUid}
                      onChange={e => setFfUid(e.target.value)}
                      placeholder="e.g. 99482103"
                      className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-[#141419] border border-[rgba(212,175,55,0.25)] focus:border-[#ffd700] text-white text-xs sm:text-sm font-mono placeholder:text-zinc-500 focus:outline-none transition-colors"
                      required
                    />
                  </div>
                </div>

                {/* IGN */}
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">
                    In-Game Name (IGN) <span className="text-[#ffd700]">*</span>
                  </label>
                  <div className="relative">
                    <ShieldCheck size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400 pointer-events-none" />
                    <input
                      type="text"
                      value={ign}
                      onChange={e => setIgn(e.target.value)}
                      placeholder="e.g. DESTROYER_VIPER"
                      className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-[#141419] border border-[rgba(212,175,55,0.25)] focus:border-[#ffd700] text-white text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none transition-colors"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Phone / WhatsApp & Region */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">
                    WhatsApp Number
                  </label>
                  <div className="relative">
                    <Phone size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400 pointer-events-none" />
                    <input
                      type="tel"
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      placeholder="+91 98765 43210"
                      className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-[#141419] border border-[rgba(212,175,55,0.25)] focus:border-[#ffd700] text-white text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-zinc-300 mb-1">
                    Region / State
                  </label>
                  <div className="relative">
                    <MapPin size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400 pointer-events-none" />
                    <input
                      type="text"
                      value={regionState}
                      onChange={e => setRegionState(e.target.value)}
                      placeholder="e.g. India (IND)"
                      className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-[#141419] border border-[rgba(212,175,55,0.25)] focus:border-[#ffd700] text-white text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none transition-colors"
                    />
                  </div>
                </div>
              </div>
            </>
          )}

          {/* Password (for signup and login) with Visibility Toggle and identical alignment */}
          {authMode !== 'forgot' && (
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1 flex items-center justify-between">
                <span>Password <span className="text-[#ffd700]">*</span></span>
                {authMode === 'signup' && (
                  <span className={`text-[10px] ${isPasswordStrong ? 'text-[#00ff88]' : 'text-zinc-500'}`}>
                    {isPasswordStrong ? '✓ Strong' : 'Min 6 chars'}
                  </span>
                )}
              </label>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400 pointer-events-none" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-11 pr-11 py-2.5 rounded-xl bg-[#141419] border border-[rgba(212,175,55,0.25)] focus:border-[#ffd700] text-white text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none transition-colors"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label="Toggle password visibility"
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white cursor-pointer"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
          )}

          {/* Action Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full mt-3 py-3.5 rounded-xl bg-gradient-to-r from-[#ffd700] via-[#ffd700] to-[#d4af37] text-black font-black text-xs uppercase tracking-wider transition-all hover:scale-[1.01] shadow-[0_0_20px_rgba(255,215,0,0.3)] flex items-center justify-center gap-2 cursor-pointer"
          >
            {isSubmitting ? (
              <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
            ) : authMode === 'signup' ? (
              <>
                <span>Create Account & Start Management</span>
                <ArrowRight size={16} />
              </>
            ) : authMode === 'login' ? (
              <>
                <span>Sign In to Dashboard</span>
                <ArrowRight size={16} />
              </>
            ) : (
              <>
                <KeyRound size={16} />
                <span>Send Password Reset OTP</span>
              </>
            )}
          </button>
        </form>

        {/* Security badge footer */}
        <div className="mt-8 pt-5 border-t border-zinc-800/80 text-center flex items-center justify-center gap-2 text-xs text-zinc-500">
          <ShieldCheck size={14} className="text-[#00ff88]" />
          <span>Protected with 256-bit Encryption • Private Management Storage</span>
        </div>
      </div>
    </div>
  );
};
