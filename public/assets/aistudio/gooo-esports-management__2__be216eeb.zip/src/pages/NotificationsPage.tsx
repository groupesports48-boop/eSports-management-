import React, { useState } from 'react';
import {
  Bell,
  MessageCircle,
  ExternalLink,
  CheckCircle2,
  Trophy,
  Filter,
  Flame,
  Settings,
  Save,
  Send,
  Info,
  Sparkles,
  Phone,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';

interface NotificationsPageProps {
  onNavigate: (page: string) => void;
}

export const NotificationsPage: React.FC<NotificationsPageProps> = ({ onNavigate }) => {
  const {
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    whatsappReminderConfig,
    updateWhatsappReminderConfig,
    user,
  } = useTournament();

  const [filterType, setFilterType] = useState<string>('ALL');
  const [phoneNumber, setPhoneNumber] = useState(whatsappReminderConfig.phoneNumber || user.phone || '+91 98765 43210');
  const [templateText, setTemplateText] = useState(whatsappReminderConfig.customTemplate);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const filtered = notifications.filter(n => {
    if (filterType !== 'ALL' && n.type !== filterType) return false;
    return true;
  });

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    updateWhatsappReminderConfig({
      phoneNumber: phoneNumber.trim(),
      customTemplate: templateText.trim(),
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const getTestPreviewUrl = () => {
    const formatted = templateText
      .replace('{matchName}', 'Bermuda Masters Squad Scrim')
      .replace('{time}', 'Tonight 08:30 PM IST')
      .replace('{format}', 'BR Squad')
      .replace('{map}', 'Bermuda')
      .replace('{groupLink}', 'https://chat.whatsapp.com/sample-group');

    const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
    return cleanPhone
      ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(formatted)}`
      : `https://wa.me/?text=${encodeURIComponent(formatted)}`;
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl lg:text-2xl font-black text-white flex items-center gap-2">
            <Bell size={22} className="text-[#ffd700]" />
            <span>Match Reminders & Notifications</span>
          </h2>
          <p className="text-xs text-zinc-400">
            Automated squad reminders, Free Fire match alerts, and authorized WhatsApp click-to-chat dispatch
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={markAllNotificationsAsRead}
            className="px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-800 text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <CheckCircle2 size={14} className="text-[#00ff88]" />
            <span>Mark All Read</span>
          </button>
        </div>
      </div>

      {/* Configurable WhatsApp Match Reminder Panel (Requirement 14) */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-[#121217] via-[#0f0f13] to-[#0a0a0d] border border-[rgba(212,175,55,0.3)] space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#25D366]/20 flex items-center justify-center text-[#25D366]">
              <MessageCircle size={17} />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm">Configurable WhatsApp Match Reminders</h3>
              <p className="text-[11px] text-zinc-400">
                Customize target number and pre-filled message template for instant squad dispatch
              </p>
            </div>
          </div>
          <span className="text-[10px] font-bold text-[#25D366] bg-[#25D366]/10 px-2.5 py-0.5 rounded-full border border-[#25D366]/30 self-start sm:self-auto">
            Authorized Click-to-Chat
          </span>
        </div>

        {/* Integration Disclosure */}
        <div className="p-3.5 rounded-xl bg-zinc-900/70 border border-zinc-800 text-xs text-zinc-300 flex items-start gap-2.5">
          <Info size={15} className="text-[#ffd700] shrink-0 mt-0.5" />
          <p className="text-[11px] text-zinc-400 leading-relaxed">
            <strong className="text-zinc-200">Official WhatsApp Dispatch: </strong>
            Uses official authorized WhatsApp click-to-chat (<code className="text-[#25D366]">wa.me</code>) with verified prefilled match alerts. Instant 1-tap dispatch directly to squad mates without storing unauthorized bot tokens or claiming unpermitted background automation.
          </p>
        </div>

        <form onSubmit={handleSaveConfig} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-zinc-300 mb-1 flex items-center gap-1.5">
                <Phone size={13} className="text-[#25D366]" />
                <span>Default Squad Contact / Target Phone Number</span>
              </label>
              <input
                type="text"
                value={phoneNumber}
                onChange={e => setPhoneNumber(e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#141419] border border-zinc-700 text-white font-mono focus:border-[#25D366] focus:outline-none"
              />
              <p className="text-[10px] text-zinc-500 mt-1">Include country code (e.g. +91 for India)</p>
            </div>

            <div>
              <label className="block font-bold text-zinc-300 mb-1">Available Template Variables</label>
              <div className="p-2.5 rounded-xl bg-[#141419] border border-zinc-800 flex flex-wrap gap-1.5 text-[10px] text-zinc-400">
                <span className="px-2 py-0.5 rounded bg-zinc-900 text-[#ffd700] font-mono">{'{matchName}'}</span>
                <span className="px-2 py-0.5 rounded bg-zinc-900 text-[#ffd700] font-mono">{'{time}'}</span>
                <span className="px-2 py-0.5 rounded bg-zinc-900 text-[#ffd700] font-mono">{'{format}'}</span>
                <span className="px-2 py-0.5 rounded bg-zinc-900 text-[#ffd700] font-mono">{'{map}'}</span>
                <span className="px-2 py-0.5 rounded bg-zinc-900 text-[#25D366] font-mono">{'{groupLink}'}</span>
              </div>
            </div>
          </div>

          <div>
            <label className="block font-bold text-zinc-300 mb-1">Custom Message Template</label>
            <textarea
              rows={4}
              value={templateText}
              onChange={e => setTemplateText(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#141419] border border-zinc-700 text-white font-mono text-xs focus:border-[#ffd700] focus:outline-none"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <a
              href={getTestPreviewUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2 rounded-xl bg-[#25D366]/20 hover:bg-[#25D366]/30 text-[#25D366] border border-[#25D366]/40 text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Send size={13} />
              <span>Preview / Test WhatsApp Link</span>
              <ExternalLink size={12} />
            </a>

            <div className="flex items-center gap-2">
              {saveSuccess && (
                <span className="text-xs text-[#00ff88] font-semibold flex items-center gap-1">
                  <CheckCircle2 size={14} /> Saved!
                </span>
              )}
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-[#ffd700] hover:bg-[#ffe234] text-black font-extrabold text-xs transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
              >
                <Save size={14} />
                <span>Save Reminder Settings</span>
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] p-1.5 overflow-x-auto">
        {[
          { id: 'ALL', label: 'All Notifications' },
          { id: 'room', label: 'Match Reminders ⚔️' },
          { id: 'match', label: 'Match Results 🏆' },
          { id: 'system', label: 'Team System ⚙️' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setFilterType(tab.id)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              filterType === tab.id
                ? 'bg-[#ffd700] text-black shadow-sm'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Notifications Feed */}
      <div className="space-y-3">
        {filtered.map(notif => (
          <div
            key={notif.id}
            onClick={() => markNotificationAsRead(notif.id)}
            className={`p-5 rounded-2xl border transition-all cursor-pointer ${
              notif.isRead
                ? 'bg-[#0f0f13] border-zinc-800/80 opacity-80'
                : 'bg-gradient-to-r from-[#141419] to-[#0f0f13] border-[rgba(212,175,55,0.35)] shadow-[0_5px_20px_rgba(255,215,0,0.06)]'
            }`}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    notif.type === 'room'
                      ? 'bg-[#ffd700]/15 text-[#ffd700] border border-[#ffd700]/30'
                      : notif.type === 'match'
                      ? 'bg-[#00ff88]/15 text-[#00ff88] border border-[#00ff88]/30'
                      : 'bg-[#00f0ff]/15 text-[#00f0ff] border border-[#00f0ff]/30'
                  }`}
                >
                  {notif.type === 'room' && <Bell size={18} />}
                  {notif.type === 'match' && <Trophy size={18} />}
                  {notif.type === 'system' && <Sparkles size={18} />}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white text-sm">{notif.title}</h3>
                    {!notif.isRead && (
                      <span className="w-2 h-2 rounded-full bg-[#ff4655] animate-pulse" />
                    )}
                  </div>
                  <p className="text-xs text-zinc-300 leading-relaxed max-w-3xl">
                    {notif.message}
                  </p>
                </div>
              </div>

              <span className="text-[11px] font-mono text-zinc-500 whitespace-nowrap">
                {notif.timestamp}
              </span>
            </div>

            {/* Actions: WA link or details */}
            <div className="flex items-center gap-3 mt-4 pt-3 border-t border-zinc-800/60 pl-13">
              {notif.waLink && (
                <a
                  href={notif.waLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#25D366]/15 hover:bg-[#25D366]/25 border border-[#25D366]/30 text-[#25D366] text-xs font-bold transition-all"
                >
                  <MessageCircle size={14} />
                  <span>Send via WhatsApp</span>
                  <ExternalLink size={12} className="opacity-75" />
                </a>
              )}
              {notif.actionUrl && (
                <a
                  href={notif.actionUrl}
                  onClick={e => {
                    e.preventDefault();
                    const pageId = notif.actionUrl?.replace('.html', '') || 'dashboard';
                    onNavigate(pageId);
                    window.history.pushState({}, '', notif.actionUrl);
                  }}
                  className="text-xs font-semibold text-[#ffd700] hover:underline"
                >
                  {notif.actionText || 'View Details'} →
                </a>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
