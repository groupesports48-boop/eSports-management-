import React, { useState } from 'react';
import {
  Shield,
  Users,
  CheckCircle2,
  MessageCircle,
  Clock,
  Sparkles,
  Trophy,
  Mail,
  PlusCircle,
  ExternalLink,
  MapPin,
  Swords,
  Trash2,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';
import { Tournament } from '../types';

export const LobbiesPage: React.FC = () => {
  const {
    tournaments,
    user,
    openAddMatchModal,
    deleteTournament,
  } = useTournament();

  const [selectedTournamentId, setSelectedTournamentId] = useState<string>(
    tournaments[0]?.id || ''
  );

  const selectedTour =
    tournaments.find(t => t.id === selectedTournamentId) || tournaments[0];

  return (
    <div className="space-y-8 pb-14">
      {/* Page Header (Removed Admin Tournament Configurator & Public Details) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl lg:text-2xl font-black text-white flex items-center gap-2">
              <Shield size={22} className="text-[#ffd700]" />
              <span>Team Lobbies & Match Control</span>
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#ffd700]/15 text-[#ffd700] border border-[#ffd700]/30">
              {user.teamName || 'Team Destroyed'}
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Manage your squad lobbies, coordinator WhatsApp groups, and player roster
          </p>
        </div>

        <button
          onClick={openAddMatchModal}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black text-xs font-extrabold uppercase tracking-wider transition-all shadow-[0_0_15px_rgba(255,215,0,0.3)] flex items-center gap-1.5 cursor-pointer"
        >
          <PlusCircle size={15} />
          <span>+ Plan / Add Match</span>
        </button>
      </div>

      {tournaments.length === 0 ? (
        <div className="p-10 rounded-3xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-[#ffd700]/10 border border-[#ffd700]/30 flex items-center justify-center text-[#ffd700] mx-auto">
            <Shield size={28} />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-black text-white">No Active Lobbies</h3>
            <p className="text-xs text-zinc-400 max-w-md mx-auto">
              Your lobbies list is clean. Schedule your first match to activate a team lobby and WhatsApp group link.
            </p>
          </div>
          <button
            onClick={openAddMatchModal}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(255,215,0,0.3)] hover:scale-105 transition-all inline-flex items-center gap-2 cursor-pointer"
          >
            <PlusCircle size={16} />
            <span>+ Plan / Add Match</span>
          </button>
        </div>
      ) : (
        <>
          {/* Match Lobby Selector */}
          <div className="p-2 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] flex items-center gap-2 overflow-x-auto">
            {tournaments.map(tour => (
              <button
                key={tour.id}
                onClick={() => setSelectedTournamentId(tour.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer ${
                  selectedTour?.id === tour.id
                    ? 'bg-[#ffd700] text-black shadow-md'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
                }`}
              >
                <span>{tour.format}</span>
                <span>•</span>
                <span className="truncate max-w-[140px]">{tour.title}</span>
                <span
                  className={`w-2 h-2 rounded-full ${
                    tour.status === 'LIVE' ? 'bg-[#00ff88]' : 'bg-[#00f0ff]'
                  }`}
                />
              </button>
            ))}
          </div>

          {selectedTour && (
            <div className="rounded-2xl bg-gradient-to-br from-[#121217] via-[#0f0f13] to-[#07070a] border border-[rgba(212,175,55,0.3)] p-6 space-y-6 shadow-xl">
              {/* Header Details */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-zinc-800 pb-5">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black px-2.5 py-0.5 rounded-full bg-[#ffd700]/15 text-[#ffd700] border border-[#ffd700]/30">
                      {selectedTour.format}
                    </span>
                    <span className="text-xs font-semibold text-zinc-300">
                      Map: {selectedTour.map} • {selectedTour.seriesFormat}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                        selectedTour.status === 'LIVE'
                          ? 'bg-[#00ff88]/15 text-[#00ff88] border border-[#00ff88]/30'
                          : 'bg-[#00f0ff]/15 text-[#00f0ff] border border-[#00f0ff]/30'
                      }`}
                    >
                      {selectedTour.status}
                    </span>
                  </div>
                  <h3 className="text-xl font-black text-white mt-2">{selectedTour.title}</h3>
                  <div className="text-xs text-zinc-400 mt-1 flex flex-wrap items-center gap-3">
                    <span>Kickoff: <strong className="text-white">{selectedTour.startTimeIST}</strong></span>
                    <span>•</span>
                    <span>Squad: <strong className="text-[#ffd700]">{user.teamName || 'Team Destroyed'}</strong></span>
                    {selectedTour.opponentSquad && (
                      <>
                        <span>•</span>
                        <span>Opponent: <strong className="text-[#00f0ff]">{selectedTour.opponentSquad}</strong></span>
                      </>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      if (confirm(`Delete lobby "${selectedTour.title}"?`)) {
                        deleteTournament(selectedTour.id);
                      }
                    }}
                    className="px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-red-400 text-xs font-semibold border border-zinc-800 flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Trash2 size={13} />
                    <span>Delete Lobby</span>
                  </button>
                </div>
              </div>

              {/* WhatsApp Coordinator Link Card (Requirement 7) */}
              <div className="p-4 rounded-xl bg-[#25D366]/10 border border-[#25D366]/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#25D366]/20 flex items-center justify-center text-[#25D366] shrink-0">
                    <MessageCircle size={20} />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">Lobby WhatsApp Coordinator Group</div>
                    <div className="text-[11px] text-zinc-400 font-mono truncate max-w-sm">
                      {selectedTour.whatsAppGroupUrl || 'Dedicated link not set (uses team broadcast)'}
                    </div>
                  </div>
                </div>

                {selectedTour.whatsAppGroupUrl ? (
                  <a
                    href={selectedTour.whatsAppGroupUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-black text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 shadow-[0_0_12px_rgba(37,211,102,0.3)] cursor-pointer"
                  >
                    <span>Join WhatsApp Group</span>
                    <ExternalLink size={13} />
                  </a>
                ) : (
                  <a
                    href={`https://wa.me/?text=${encodeURIComponent(
                      `🏆 *TEAM DESTROYED LOBBY: ${selectedTour.title}* 🏆\nTime: ${selectedTour.startTimeIST}\nFormat: ${selectedTour.format} (${selectedTour.map})\nPrepare for kickoff!`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[#25D366] text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <MessageCircle size={14} />
                    <span>Share WhatsApp Alert</span>
                  </a>
                )}
              </div>

              {/* Team Roster for this Match */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-sm flex items-center gap-2">
                    <Users size={16} className="text-[#ffd700]" />
                    <span>Assigned Team Roster</span>
                  </h4>
                  <span className="text-xs font-mono text-zinc-400">
                    Leader: <strong className="text-white">{user.ign}</strong>
                  </span>
                </div>

                <div className="rounded-xl bg-[#09090c] border border-zinc-800 overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-zinc-900 text-zinc-400 text-[10px] uppercase font-bold border-b border-zinc-800">
                      <tr>
                        <th className="py-2.5 px-3">Slot</th>
                        <th className="py-2.5 px-3">Player UID</th>
                        <th className="py-2.5 px-3">In-Game Name</th>
                        <th className="py-2.5 px-3">Squad Tag</th>
                        <th className="py-2.5 px-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-800/60">
                      <tr>
                        <td className="py-2.5 px-3 font-mono font-bold text-[#ffd700]">#1</td>
                        <td className="py-2.5 px-3 font-mono text-white">{user.freeFireUid}</td>
                        <td className="py-2.5 px-3 font-bold text-white">{user.ign}</td>
                        <td className="py-2.5 px-3 text-zinc-400">{user.teamName || 'Team Destroyed'}</td>
                        <td className="py-2.5 px-3 text-[#00ff88] font-semibold">Active Leader</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
