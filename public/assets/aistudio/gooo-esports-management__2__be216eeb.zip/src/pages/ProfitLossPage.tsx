import React, { useState } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Coins,
  Percent,
  CheckCircle2,
  Trophy,
  PlusCircle,
  XCircle,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';
import { calculateNetProfit, calculateROI, formatCurrencyINR } from '../utils/esportsMath';

export const ProfitLossPage: React.FC = () => {
  const { history, openAddMatchModal } = useTournament();

  const [typeFilter, setTypeFilter] = useState<'ALL' | 'WIN' | 'PODIUM' | 'LOSS'>('ALL');

  // Compute metrics strictly from actual saved match history (Requirement 12)
  const grossWinnings = history.reduce((sum, item) => sum + (item.prizeWon || 0), 0);
  const totalEntryExpenses = history.reduce((sum, item) => sum + (item.entryFee || 0), 0);
  const netEarnings = calculateNetProfit(grossWinnings, totalEntryExpenses);
  const roiPercentage = calculateROI(netEarnings, totalEntryExpenses);

  const filteredHistory = history.filter(item => {
    if (typeFilter !== 'ALL' && item.rankStatus !== typeFilter) return false;
    return true;
  });

  return (
    <div className="space-y-8 pb-12">
      {/* Top Banner (Removed Wallet, Add Funds, UPI Payouts) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl lg:text-2xl font-black text-white flex items-center gap-2">
            <TrendingUp size={22} className="text-[#ffd700]" />
            <span>Profit & Loss Financial Tracker</span>
          </h2>
          <p className="text-xs text-zinc-400">
            Audit-grade tournament earnings, entry fee expenses, and net returns in Rupees (₹)
          </p>
        </div>

        <button
          onClick={openAddMatchModal}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-extrabold text-xs uppercase tracking-wider transition-all shadow-[0_0_15px_rgba(255,215,0,0.3)] hover:scale-105 flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
        >
          <PlusCircle size={15} />
          <span>+ Plan Match</span>
        </button>
      </div>

      {/* 4 Core Financial Summary Cards (Start at ₹0 for new accounts, Requirement 12) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Tournament Winnings */}
        <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] hover:border-[#ffd700]/50 transition-all space-y-2">
          <div className="flex items-center justify-between text-zinc-400 text-xs font-semibold">
            <span>Total Tournament Winnings</span>
            <div className="w-8 h-8 rounded-lg bg-[#00ff88]/10 border border-[#00ff88]/20 flex items-center justify-center text-[#00ff88]">
              <TrendingUp size={16} />
            </div>
          </div>
          <div className="text-2xl lg:text-3xl font-black text-[#00ff88]">
            {formatCurrencyINR(grossWinnings)}
          </div>
          <div className="text-[11px] text-zinc-400">Calculated from verified match prize finishes</div>
        </div>

        {/* Total Entry Fees Paid */}
        <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] hover:border-[#ffd700]/50 transition-all space-y-2">
          <div className="flex items-center justify-between text-zinc-400 text-xs font-semibold">
            <span>Total Entry Fees Paid</span>
            <div className="w-8 h-8 rounded-lg bg-[#ff4655]/10 border border-[#ff4655]/20 flex items-center justify-center text-[#ff4655]">
              <TrendingDown size={16} />
            </div>
          </div>
          <div className="text-2xl lg:text-3xl font-black text-[#ff4655]">
            {formatCurrencyINR(totalEntryExpenses)}
          </div>
          <div className="text-[11px] text-zinc-400">Combined entry fees for all entered matches</div>
        </div>

        {/* Net Balance / Profit */}
        <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] hover:border-[#ffd700]/50 transition-all space-y-2">
          <div className="flex items-center justify-between text-zinc-400 text-xs font-semibold">
            <span>Net Balance / Profit</span>
            <div className="w-8 h-8 rounded-lg bg-[#ffd700]/10 border border-[#ffd700]/20 flex items-center justify-center text-[#ffd700]">
              <Coins size={16} />
            </div>
          </div>
          <div className={`text-2xl lg:text-3xl font-black ${netEarnings >= 0 ? 'text-[#00ff88]' : 'text-[#ff4655]'}`}>
            {netEarnings >= 0 ? `+₹${netEarnings}` : `-₹${Math.abs(netEarnings)}`}
          </div>
          <div className="text-[11px] text-[#ffd700] font-semibold">
            {netEarnings >= 0 ? 'Positive net tournament return' : 'Entry expenses exceed winnings'}
          </div>
        </div>

        {/* Return on Investment (ROI) */}
        <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] hover:border-[#ffd700]/50 transition-all space-y-2">
          <div className="flex items-center justify-between text-zinc-400 text-xs font-semibold">
            <span>eSports Return (ROI)</span>
            <div className="w-8 h-8 rounded-lg bg-[#00f0ff]/10 border border-[#00f0ff]/20 flex items-center justify-center text-[#00f0ff]">
              <Percent size={16} />
            </div>
          </div>
          <div className="text-2xl lg:text-3xl font-black text-[#00f0ff]">
            {roiPercentage >= 0 ? `+${roiPercentage}%` : `${roiPercentage}%`}
          </div>
          <div className="text-[11px] text-zinc-400">
            {totalEntryExpenses > 0 ? 'Verified return over tournament fees' : 'Zero fee baseline'}
          </div>
        </div>
      </div>

      {/* Financial Ledger Data Table */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-white text-base">Match Financial Ledger</h3>
            <p className="text-xs text-zinc-400">Audit-ready breakdown of winnings, entry expenses, and net profit per match</p>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1 rounded-xl bg-zinc-900/90 p-1 border border-zinc-800 self-start sm:self-auto">
            {(['ALL', 'WIN', 'PODIUM', 'LOSS'] as const).map(type => (
              <button
                key={type}
                onClick={() => setTypeFilter(type)}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  typeFilter === type
                    ? 'bg-[#ffd700] text-black shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {filteredHistory.length === 0 ? (
          <div className="p-10 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] text-center text-zinc-500 text-xs py-10 space-y-2">
            <Coins size={28} className="mx-auto text-zinc-600 mb-2" />
            <div>No financial match transactions recorded yet.</div>
            <p className="text-zinc-400">Financial records start at ₹0 and calculate strictly from verified match history.</p>
          </div>
        ) : (
          <div className="rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="gold-table">
                <thead>
                  <tr>
                    <th>Match ID</th>
                    <th>Date & Time</th>
                    <th>Tournament</th>
                    <th>Placement Result</th>
                    <th>Entry Expense</th>
                    <th>Winnings (₹)</th>
                    <th className="text-right">Net Profit / Loss</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredHistory.map(item => (
                    <tr key={item.id}>
                      <td className="font-mono text-zinc-300 text-xs">{item.matchId}</td>
                      <td className="text-zinc-400 text-xs font-mono">{item.date}</td>
                      <td className="text-white text-xs font-semibold">{item.tournamentName}</td>
                      <td>
                        <span
                          className={`esports-badge ${
                            item.rankStatus === 'WIN'
                              ? 'esports-badge-green'
                              : item.rankStatus === 'PODIUM'
                              ? 'esports-badge-gold'
                              : 'esports-badge-red'
                          }`}
                        >
                          #{item.placement} {item.rankStatus}
                        </span>
                      </td>
                      <td className="font-mono text-[#ff4655] text-xs font-semibold">-₹{item.entryFee}</td>
                      <td className="font-mono text-[#00ff88] text-xs font-bold">+₹{item.prizeWon}</td>
                      <td
                        className={`font-mono font-black text-xs text-right ${
                          item.netAmount >= 0 ? 'text-[#00ff88]' : 'text-[#ff4655]'
                        }`}
                      >
                        {item.netAmount >= 0 ? `+₹${item.netAmount}` : `-₹${Math.abs(item.netAmount)}`}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
