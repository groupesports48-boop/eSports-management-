import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Users,
  Radio,
  Coins,
  Swords,
  MessageCircle,
  ChevronRight,
  TrendingUp,
  Clock,
  Sparkles,
  PlusCircle,
  CheckCircle2,
  AlertCircle,
  FileText,
  ExternalLink,
  Calendar,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';
import { formatCurrencyINR, getRankBadge, calculateISTCountdown } from '../utils/esportsMath';
import { RecordResultModal } from '../components/RecordResultModal';
import { Tournament } from '../types';

interface DashboardPageProps {
  onNavigate: (page: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const {
    tournaments,
    history,
    user,
    totalTournamentsCount,
    liveLobbiesCount,
    grossWinningsSum,
    netProfitSum,
    nextUpcomingMatch,
    openAddMatchModal,
  } = useTournament();

  const [nowMs, setNowMs] = useState(Date.now());
  const [recordingTournament, setRecordingTournament] = useState<Tournament | null>(null);

  // Live ticking IST countdown
  useEffect(() => {
    const timer = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const rank = getRankBadge(user.rankedScore);
  const upcomingMatches = tournaments.filter(t => t.status !== 'COMPLETED');
  const heroCountdown = nextUpcomingMatch
    ? calculateISTCountdown(nextUpcomingMatch.targetTimestampMs, nowMs)
    : null;

  return (
    <div className="space-y-8 pb-14">
      {/* Top Banner: Captain & Personal Identity (No wallet/UPI sections) */}
      <div className="rounded-2xl bg-gradient-to-r from-[#141419] via-[#101014] to-[#0a0a0d] border border-[rgba(212,175,55,0.25)] p-5 lg:p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-[0_10px_30px_rgba(0,0,0,0.6)]">
        <div className="flex items-center gap-4">
          <div className="relative">
            <img
              src={user.avatarUrl || '/assets/aistudio/photo__1__f37c447f.jpg'}
              alt={user.ign}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-[#ffd700] shadow-[0_0_18px_rgba(255,215,0,0.35)]"
            />
            <span className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded-full bg-[#00ff88] text-[9px] font-black text-black">
              LEADER
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black text-white">{user.ign}</h2>
              <span
                className="text-[10px] font-extrabold px-2 py-0.5 rounded-full border"
                style={{
                  backgroundColor: `${rank.badgeColor}20`,
                  color: rank.badgeColor,
                  borderColor: `${rank.badgeColor}40`,
                }}
              >
                {rank.title}
              </span>
            </div>
            <div className="text-xs text-zinc-400 mt-0.5 flex flex-wrap items-center gap-2">
              <span>Free Fire UID: <span className="font-mono text-white font-semibold">{user.freeFireUid}</span></span>
              <span>•</span>
              <span>Squad: <span className="text-[#ffd700] font-bold">{user.teamName || 'Team Destroyed'}</span></span>
              <span>•</span>
              <span>Region: <span className="text-zinc-200">{user.serverRegion}</span></span>
            </div>
          </div>
        </div>

        {/* Quick Add Match Action */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={openAddMatchModal}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-extrabold text-xs uppercase tracking-wider shadow-[0_0_18px_rgba(255,215,0,0.3)] hover:scale-105 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <PlusCircle size={15} />
            <span>+ Add Match</span>
          </button>
          <button
            onClick={() => onNavigate('schedule')}
            className="px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-[rgba(212,175,55,0.25)] text-zinc-300 hover:text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Calendar size={14} className="text-[#ffd700]" />
            <span>My Schedule</span>
          </button>
        </div>
      </div>

      {/* Hero Card: NEXT UPCOMING MATCH (Without Room ID / Password, With WhatsApp Group Link) */}
      {nextUpcomingMatch && heroCountdown ? (
        <div className="rounded-3xl bg-gradient-to-br from-[#121217] via-[#0e0e13] to-[#07070a] border-2 border-[#ffd700]/50 p-6 sm:p-7 shadow-[0_15px_40px_rgba(255,215,0,0.15)] relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-[#ffd700]/10 blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
            <div className="space-y-3.5 max-w-xl">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-black px-3 py-1 rounded-full bg-[#ffd700] text-black">
                  NEXT UPCOMING MATCH
                </span>
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-zinc-800 text-zinc-300 border border-zinc-700">
                  {nextUpcomingMatch.format}
                </span>
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-zinc-800 text-zinc-300">
                  Map: {nextUpcomingMatch.map}
                </span>
                <span
                  className={`text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider ${
                    nextUpcomingMatch.status === 'LIVE'
                      ? 'bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/40'
                      : 'bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40'
                  }`}
                >
                  {nextUpcomingMatch.status === 'LIVE' ? '● LIVE IN PROGRESS' : 'UPCOMING'}
                </span>
              </div>

              <div>
                <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                  {nextUpcomingMatch.title}
                </h3>
                <div className="text-xs text-zinc-300 mt-1 flex flex-wrap items-center gap-2">
                  <span>Kickoff: <strong className="text-white">{nextUpcomingMatch.startTimeIST}</strong></span>
                  <span>•</span>
                  <span>Squad: <strong className="text-[#ffd700]">{user.teamName || 'Team Destroyed'}</strong></span>
                  {nextUpcomingMatch.opponentSquad && (
                    <>
                      <span>•</span>
                      <span>Opponent: <strong className="text-[#00f0ff]">{nextUpcomingMatch.opponentSquad}</strong></span>
                    </>
                  )}
                </div>
              </div>

              {/* Match WhatsApp Group Pill (Requirement 4 & 7) */}
              {nextUpcomingMatch.whatsAppGroupUrl ? (
                <div className="p-3.5 rounded-2xl bg-[#25D366]/10 border border-[#25D366]/30 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <MessageCircle size={18} className="text-[#25D366]" />
                    <div>
                      <div className="text-[10px] text-zinc-400 uppercase font-bold tracking-wider">
                        Match WhatsApp Group
                      </div>
                      <div className="text-xs font-mono text-zinc-200 truncate max-w-xs">
                        {nextUpcomingMatch.whatsAppGroupUrl}
                      </div>
                    </div>
                  </div>
                  <a
                    href={nextUpcomingMatch.whatsAppGroupUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3.5 py-1.5 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-black font-black text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-[0_0_12px_rgba(37,211,102,0.3)] cursor-pointer"
                  >
                    <span>Join WhatsApp Group</span>
                    <ExternalLink size={12} />
                  </a>
                </div>
              ) : (
                <div className="p-3 rounded-2xl bg-zinc-900/80 border border-zinc-800 flex items-center justify-between gap-3 text-xs text-zinc-400">
                  <span className="flex items-center gap-1.5">
                    <MessageCircle size={15} className="text-zinc-500" />
                    <span>WhatsApp group link not set for this match.</span>
                  </span>
                  <a
                    href={`https://wa.me/?text=${encodeURIComponent(
                      `🏆 *TEAM DESTROYED MATCH ALERT* 🏆\nMatch: ${nextUpcomingMatch.title}\nTime: ${nextUpcomingMatch.startTimeIST}\nFormat: ${nextUpcomingMatch.format} (${nextUpcomingMatch.map})\nSquad be ready 10m before!`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#25D366] font-bold hover:underline flex items-center gap-1"
                  >
                    <span>Share via WhatsApp</span>
                    <ExternalLink size={11} />
                  </a>
                </div>
              )}

              {/* Strategy Note */}
              {nextUpcomingMatch.strategyNotes && (
                <div className="flex items-start gap-2 text-xs text-zinc-300 p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800">
                  <FileText size={15} className="text-[#ffd700] shrink-0 mt-0.5" />
                  <span>
                    <strong className="text-white">Strategy: </strong>
                    {nextUpcomingMatch.strategyNotes}
                  </span>
                </div>
              )}
            </div>

            {/* Countdown HUD & Actions */}
            <div className="shrink-0 flex flex-col items-center lg:items-end space-y-3 w-full lg:w-auto">
              <div className="p-4 rounded-2xl bg-[#08080a] border border-[rgba(212,175,55,0.25)] text-center w-full lg:w-72 shadow-lg">
                <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-widest mb-2 flex items-center justify-center gap-1.5">
                  <Clock size={13} className="text-[#ffd700]" />
                  <span>Ticking IST Kickoff Timer</span>
                </div>

                {heroCountdown.isLive ? (
                  <div className="py-2 text-xl font-black text-[#00ff88] flex items-center justify-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-[#00ff88] animate-ping" />
                    <span>MATCH LIVE NOW!</span>
                  </div>
                ) : (
                  <div className="grid grid-cols-3 gap-2">
                    <div className="p-2 rounded-xl bg-zinc-900 border border-zinc-800">
                      <div className="text-2xl font-black text-[#ffd700] font-mono">
                        {heroCountdown.hours.toString().padStart(2, '0')}
                      </div>
                      <div className="text-[9px] text-zinc-400 uppercase">Hours</div>
                    </div>
                    <div className="p-2 rounded-xl bg-zinc-900 border border-zinc-800">
                      <div className="text-2xl font-black text-[#ffd700] font-mono">
                        {heroCountdown.minutes.toString().padStart(2, '0')}
                      </div>
                      <div className="text-[9px] text-zinc-400 uppercase">Mins</div>
                    </div>
                    <div className="p-2 rounded-xl bg-zinc-900 border border-zinc-800">
                      <div className="text-2xl font-black text-[#ffd700] font-mono">
                        {heroCountdown.seconds.toString().padStart(2, '0')}
                      </div>
                      <div className="text-[9px] text-zinc-400 uppercase">Secs</div>
                    </div>
                  </div>
                )}
              </div>

              {/* Action: Record Result & WhatsApp */}
              <div className="flex flex-col sm:flex-row lg:flex-col gap-2 w-full lg:w-72">
                <button
                  onClick={() => setRecordingTournament(nextUpcomingMatch)}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#00ff88] hover:bg-[#1cf398] text-black font-extrabold text-xs uppercase tracking-wider shadow-[0_0_15px_rgba(0,255,136,0.25)] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 size={15} />
                  <span>Record Result / Booyah</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Clean Empty State when no matches exist (Requirement 2) */
        <div className="p-8 rounded-3xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-[#ffd700]/10 border border-[#ffd700]/30 flex items-center justify-center text-[#ffd700] mx-auto">
            <Swords size={28} />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-black text-white">No Upcoming Matches Planned</h3>
            <p className="text-xs text-zinc-400 max-w-md mx-auto">
              Start fresh by planning your next Free Fire scrim, tournament match, or clash squad battle.
            </p>
          </div>
          <button
            onClick={openAddMatchModal}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(255,215,0,0.3)] hover:scale-105 transition-all inline-flex items-center gap-2 cursor-pointer"
          >
            <PlusCircle size={16} />
            <span>+ Plan / Add Match</span>
          </button>
        </div>
      )}

      {/* 4 Core Personal Metrics (Strictly from actual data, zero for new users) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Planned Matches */}
        <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] hover:border-[#ffd700]/50 transition-all space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-zinc-400">PLANNED MATCHES</span>
            <div className="w-10 h-10 rounded-xl bg-[#ffd700]/10 border border-[#ffd700]/25 flex items-center justify-center text-[#ffd700]">
              <Trophy size={18} />
            </div>
          </div>
          <div className="text-2xl font-black text-white">{upcomingMatches.length} Active</div>
          <div className="text-[11px] text-[#00ff88] flex items-center gap-1 font-semibold">
            <TrendingUp size={13} />
            <span>{history.length} completed records saved</span>
          </div>
        </div>

        {/* Metric 2: Team Destroyed */}
        <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] hover:border-[#ffd700]/50 transition-all space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-zinc-400">TEAM ROSTER</span>
            <div className="w-10 h-10 rounded-xl bg-[#00f0ff]/10 border border-[#00f0ff]/25 flex items-center justify-center text-[#00f0ff]">
              <Users size={18} />
            </div>
          </div>
          <div className="text-2xl font-black text-white">{user.teamName || 'Team Destroyed'}</div>
          <div className="text-[11px] text-zinc-400 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-[#00ff88]" />
            <span>Leader: {user.ign}</span>
          </div>
        </div>

        {/* Metric 3: Live Scrims */}
        <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] hover:border-[#ffd700]/50 transition-all space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-zinc-400">LIVE SCRIMS</span>
            <div className="w-10 h-10 rounded-xl bg-[#00ff88]/10 border border-[#00ff88]/25 flex items-center justify-center text-[#00ff88]">
              <Radio size={18} className={liveLobbiesCount > 0 ? 'animate-pulse' : ''} />
            </div>
          </div>
          <div className="text-2xl font-black text-[#00ff88] flex items-center gap-2">
            <span>{liveLobbiesCount} Live</span>
          </div>
          <div className="text-[11px] text-zinc-400">
            {liveLobbiesCount > 0 ? 'Matches in progress now' : 'No active match right now'}
          </div>
        </div>

        {/* Metric 4: Net Balance (Calculated strictly from actual records) */}
        <div className="p-5 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] hover:border-[#ffd700]/50 transition-all space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-zinc-400">NET BALANCE</span>
            <div className="w-10 h-10 rounded-xl bg-[#ffd700]/10 border border-[#ffd700]/25 flex items-center justify-center text-[#ffd700]">
              <Coins size={18} />
            </div>
          </div>
          <div className={`text-2xl font-black ${netProfitSum >= 0 ? 'text-[#00ff88]' : 'text-red-400'}`}>
            {netProfitSum >= 0 ? `+${formatCurrencyINR(netProfitSum)}` : formatCurrencyINR(netProfitSum)}
          </div>
          <div className="text-[11px] text-zinc-400">
            <span>Winnings: {formatCurrencyINR(grossWinningsSum)}</span>
          </div>
        </div>
      </div>

      {/* Upcoming Matches Grid (No Room ID/Password, With WhatsApp Group Link) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg lg:text-xl font-black text-white flex items-center gap-2">
              <Swords size={20} className="text-[#ffd700]" />
              <span>Upcoming Matches & Scrims</span>
            </h2>
            <p className="text-xs text-zinc-400">Active and scheduled matches for {user.teamName || 'Team Destroyed'}</p>
          </div>
          <button
            onClick={openAddMatchModal}
            className="text-xs font-bold text-black bg-[#ffd700] hover:bg-[#ffe234] px-3.5 py-1.5 rounded-xl transition-all shadow-[0_0_12px_rgba(255,215,0,0.25)] flex items-center gap-1.5 cursor-pointer"
          >
            <PlusCircle size={14} />
            <span>+ Add Match</span>
          </button>
        </div>

        {upcomingMatches.length === 0 ? (
          <div className="p-6 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.15)] text-center text-zinc-500 text-xs py-8">
            No scheduled matches found. Click <strong className="text-[#ffd700] cursor-pointer" onClick={openAddMatchModal}>+ Add Match</strong> to plan your next game.
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {upcomingMatches.map(tour => (
              <div
                key={tour.id}
                className="rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] p-5 space-y-3.5 hover:border-[#ffd700]/50 transition-all"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-[#ffd700]/15 text-[#ffd700] border border-[#ffd700]/30">
                        {tour.format}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300">
                        {tour.map}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                          tour.status === 'LIVE'
                            ? 'bg-[#00ff88]/20 text-[#00ff88]'
                            : 'bg-[#00f0ff]/20 text-[#00f0ff]'
                        }`}
                      >
                        {tour.status}
                      </span>
                    </div>
                    <h3 className="font-bold text-white text-base mt-1.5">{tour.title}</h3>
                    <div className="text-xs text-zinc-400">
                      {tour.seriesFormat} • Kickoff: <strong className="text-zinc-200">{tour.startTimeIST}</strong>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] text-zinc-400">Prize Pool</div>
                    <div className="text-sm font-black text-[#ffd700]">₹{tour.prizePool}</div>
                  </div>
                </div>

                {/* Per-match WhatsApp Group Link (Requirement 4 & 7, No Room ID/Pass) */}
                {tour.whatsAppGroupUrl ? (
                  <a
                    href={tour.whatsAppGroupUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 px-3 rounded-xl bg-[#25D366]/15 hover:bg-[#25D366]/25 border border-[#25D366]/35 text-[#25D366] text-xs font-bold transition-all flex items-center justify-between cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <MessageCircle size={15} />
                      <span>Join WhatsApp Group</span>
                    </div>
                    <ExternalLink size={13} className="opacity-75" />
                  </a>
                ) : (
                  <div className="p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800/80 text-[11px] text-zinc-400 flex items-center justify-between">
                    <span>WhatsApp Group Link: <span className="text-zinc-500">Not configured</span></span>
                    <a
                      href={`https://wa.me/?text=${encodeURIComponent(
                        `🏆 *MATCH ALERT* 🏆\nMatch: ${tour.title}\nTime: ${tour.startTimeIST}\nFormat: ${tour.format} (${tour.map})\nBe ready!`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#25D366] font-semibold hover:underline flex items-center gap-1"
                    >
                      <MessageCircle size={13} />
                      <span>Share Alert</span>
                    </a>
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => setRecordingTournament(tour)}
                    className="flex-1 py-2 rounded-xl bg-[#00ff88]/15 hover:bg-[#00ff88]/25 border border-[#00ff88]/40 text-[#00ff88] text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle2 size={14} />
                    <span>Record Booyah / Result</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Match History Ledger */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg lg:text-xl font-black text-white flex items-center gap-2">
              <Trophy size={20} className="text-[#ffd700]" />
              <span>Recent Match Ledger & Results</span>
            </h2>
            <p className="text-xs text-zinc-400">Saved audit records of completed matches and Booyahs</p>
          </div>
          <button
            onClick={() => onNavigate('history')}
            className="text-xs font-bold text-[#ffd700] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>Full History ({history.length})</span>
            <ChevronRight size={14} />
          </button>
        </div>

        {history.length === 0 ? (
          <div className="p-8 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] text-center text-zinc-500 text-xs py-8 space-y-2">
            <div>No match results recorded yet.</div>
            <button
              onClick={() => onNavigate('history')}
              className="text-xs font-bold text-[#ffd700] hover:underline"
            >
              Go to Match History to record results or upload scoreboard screenshots →
            </button>
          </div>
        ) : (
          <div className="rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-zinc-900/80 text-zinc-400 uppercase text-[10px] font-bold border-b border-zinc-800">
                  <tr>
                    <th className="py-3 px-4">Match ID & Name</th>
                    <th className="py-3 px-4">Format / Map</th>
                    <th className="py-3 px-4">Placement</th>
                    <th className="py-3 px-4">Kills</th>
                    <th className="py-3 px-4">Prize Won</th>
                    <th className="py-3 px-4 text-right">Net Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/60">
                  {history.slice(0, 5).map(item => (
                    <tr key={item.id} className="hover:bg-zinc-900/40 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-bold text-white">{item.tournamentName}</div>
                        <div className="text-[10px] font-mono text-zinc-400">{item.matchId} • {item.date}</div>
                      </td>
                      <td className="py-3 px-4 text-zinc-300">
                        {item.gameMode} ({item.map})
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded font-black text-[10px] ${
                            item.rankStatus === 'WIN'
                              ? 'bg-[#00ff88]/20 text-[#00ff88]'
                              : item.rankStatus === 'PODIUM'
                              ? 'bg-[#ffd700]/20 text-[#ffd700]'
                              : 'bg-red-500/20 text-red-400'
                          }`}
                        >
                          #{item.placement} {item.rankStatus}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-bold text-white">{item.kills}</td>
                      <td className="py-3 px-4 font-bold text-[#ffd700]">₹{item.prizeWon}</td>
                      <td className="py-3 px-4 text-right font-black">
                        <span className={item.netAmount >= 0 ? 'text-[#00ff88]' : 'text-red-400'}>
                          {item.netAmount >= 0 ? `+₹${item.netAmount}` : `-₹${Math.abs(item.netAmount)}`}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Result Recorder Modal */}
      {recordingTournament && (
        <RecordResultModal
          tournament={recordingTournament}
          isOpen={true}
          onClose={() => setRecordingTournament(null)}
        />
      )}
    </div>
  );
};
