import React, { useState } from 'react';
import {
  History,
  Search,
  Trophy,
  Filter,
  Download,
  Calendar,
  Crosshair,
  TrendingUp,
  TrendingDown,
  CheckCircle2,
  XCircle,
  PlusCircle,
  Sparkles,
  Trash2,
  Edit2,
  X,
  Save,
  Image as ImageIcon,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';
import { AddMatchHistoryModal } from '../components/AddMatchHistoryModal';
import { formatCurrencyINR } from '../utils/esportsMath';
import { MatchHistoryItem, GameMap, GameMode } from '../types';

export const HistoryPage: React.FC = () => {
  const { history, deleteMatchHistoryItem, updateMatchHistoryItem } = useTournament();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'WIN' | 'PODIUM' | 'LOSS'>('ALL');
  const [modeFilter, setModeFilter] = useState<string>('ALL');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Edit match state
  const [editingItem, setEditingItem] = useState<MatchHistoryItem | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editPlacement, setEditPlacement] = useState<number>(1);
  const [editStatus, setEditStatus] = useState<'WIN' | 'PODIUM' | 'LOSS'>('WIN');
  const [editKills, setEditKills] = useState<number>(0);
  const [editPoints, setEditPoints] = useState<number>(0);
  const [editEntry, setEditEntry] = useState<number>(0);
  const [editPrize, setEditPrize] = useState<number>(0);
  const [editMap, setEditMap] = useState<GameMap>('Bermuda');
  const [editMode, setEditMode] = useState<GameMode>('Battle Royale Squad');

  const handleOpenEdit = (item: MatchHistoryItem) => {
    setEditingItem(item);
    setEditTitle(item.tournamentName);
    setEditPlacement(item.placement);
    setEditStatus(item.rankStatus);
    setEditKills(item.kills);
    setEditPoints(item.points || 0);
    setEditEntry(item.entryFee);
    setEditPrize(item.prizeWon);
    setEditMap(item.map);
    setEditMode(item.gameMode);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;
    updateMatchHistoryItem(editingItem.id, {
      tournamentName: editTitle.trim(),
      placement: Number(editPlacement),
      rankStatus: editStatus,
      kills: Number(editKills),
      points: Number(editPoints),
      entryFee: Number(editEntry),
      prizeWon: Number(editPrize),
      map: editMap,
      gameMode: editMode,
    });
    setEditingItem(null);
  };

  // Filtered history list
  const filteredMatches = history.filter(item => {
    if (statusFilter !== 'ALL' && item.rankStatus !== statusFilter) return false;
    if (modeFilter !== 'ALL' && item.gameMode !== modeFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const match =
        item.matchId.toLowerCase().includes(q) ||
        item.tournamentName.toLowerCase().includes(q) ||
        item.map.toLowerCase().includes(q) ||
        item.gameMode.toLowerCase().includes(q) ||
        (item.playerName && item.playerName.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  const totalWins = history.filter(h => h.rankStatus === 'WIN').length;
  const totalWinningsSum = history.reduce((acc, h) => acc + (h.prizeWon || 0), 0);
  const totalFeesSum = history.reduce((acc, h) => acc + (h.entryFee || 0), 0);
  const totalNet = totalWinningsSum - totalFeesSum;

  const exportCSV = () => {
    const headers = [
      'Match ID',
      'Tournament',
      'Player Name',
      'Game Mode',
      'Map',
      'Kills',
      'Placement',
      'Points',
      'Status',
      'Entry Fee (Rs)',
      'Prize Won (Rs)',
      'Net Profit (Rs)',
      'Date',
    ];
    const rows = filteredMatches.map(m => [
      m.matchId,
      `"${m.tournamentName}"`,
      m.playerName || 'Team Destroyed',
      m.gameMode,
      m.map,
      m.kills,
      m.placement,
      m.points || 0,
      m.rankStatus,
      m.entryFee,
      m.prizeWon,
      m.netAmount,
      `"${m.date}"`,
    ]);
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `destroyed_match_history_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl lg:text-2xl font-black text-white flex items-center gap-2">
            <History size={22} className="text-[#ffd700]" />
            <span>Match History & Results Ledger</span>
          </h2>
          <p className="text-xs text-zinc-400">
            Audit-grade performance, kills, rankings, and prize money from saved match results
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-extrabold text-xs uppercase tracking-wider transition-all hover:scale-105 shadow-[0_0_15px_rgba(255,215,0,0.3)] flex items-center gap-1.5 cursor-pointer"
          >
            <PlusCircle size={15} />
            <span>+ Add Match Result</span>
          </button>
          {history.length > 0 && (
            <button
              onClick={exportCSV}
              className="px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-[rgba(212,175,55,0.3)] text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Download size={14} className="text-[#ffd700]" />
              <span>Export CSV</span>
            </button>
          )}
        </div>
      </div>

      {/* Summary KPI Badges (Zero for new users, computed from actual records) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)]">
          <div className="text-[11px] text-zinc-400">Total Matches</div>
          <div className="text-xl font-black text-white mt-0.5">{history.length}</div>
        </div>
        <div className="p-4 rounded-xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)]">
          <div className="text-[11px] text-zinc-400">Booyah Victories (#1)</div>
          <div className="text-xl font-black text-[#00ff88] mt-0.5">{totalWins} Wins</div>
        </div>
        <div className="p-4 rounded-xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)]">
          <div className="text-[11px] text-zinc-400">Total Winnings</div>
          <div className="text-xl font-black text-[#ffd700] mt-0.5">₹{totalWinningsSum}</div>
        </div>
        <div className="p-4 rounded-xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)]">
          <div className="text-[11px] text-zinc-400">Net Balance</div>
          <div className={`text-xl font-black mt-0.5 ${totalNet >= 0 ? 'text-[#00ff88]' : 'text-[#ff4655]'}`}>
            {totalNet >= 0 ? `+₹${totalNet}` : `-₹${Math.abs(totalNet)}`}
          </div>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="p-4 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by Match ID, Map, or Tournament..."
            className="gold-input w-full pl-10 text-xs"
          />
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-1 rounded-xl bg-zinc-900/90 p-1 border border-zinc-800">
            {(['ALL', 'WIN', 'PODIUM', 'LOSS'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setStatusFilter(tab)}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  statusFilter === tab
                    ? 'bg-[#ffd700] text-black shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          <select
            value={modeFilter}
            onChange={e => setModeFilter(e.target.value)}
            className="gold-input py-1.5 px-3 text-xs bg-[#141419]"
          >
            <option value="ALL">All Modes</option>
            <option value="Battle Royale Squad">BR Squad</option>
            <option value="Clash Squad 4v4">Clash Squad 4v4</option>
            <option value="Battle Royale Duo">BR Duo</option>
            <option value="Battle Royale Solo">BR Solo</option>
          </select>
        </div>
      </div>

      {/* History Data Table or Clean Empty State */}
      {filteredMatches.length === 0 ? (
        <div className="p-10 rounded-3xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-[#ffd700]/10 border border-[#ffd700]/30 flex items-center justify-center text-[#ffd700] mx-auto">
            <History size={28} />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-black text-white">No Match History Records</h3>
            <p className="text-xs text-zinc-400 max-w-md mx-auto">
              Your match history starts at zero. You can record match results manually or upload a scoreboard screenshot to extract results with Gemini AI.
            </p>
          </div>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(255,215,0,0.3)] hover:scale-105 transition-all inline-flex items-center gap-2 cursor-pointer"
          >
            <PlusCircle size={16} />
            <span>+ Add Match Result / Upload Screenshot</span>
          </button>
        </div>
      ) : (
        <div className="rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] overflow-hidden shadow-lg">
          <div className="overflow-x-auto">
            <table className="gold-table">
              <thead>
                <tr>
                  <th>Match ID</th>
                  <th>Tournament Details</th>
                  <th>Map</th>
                  <th>Kills</th>
                  <th>Points</th>
                  <th>Placement</th>
                  <th>Result</th>
                  <th>Entry Fee</th>
                  <th>Prize Won</th>
                  <th>Net (₹)</th>
                  <th className="text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredMatches.map(item => (
                  <tr key={item.id}>
                    <td className="font-mono font-bold text-white text-xs">
                      <div className="flex items-center gap-1.5">
                        {item.screenshotUrl && (
                          <span title="Screenshot verified">
                            <ImageIcon size={13} className="text-[#ffd700] shrink-0" />
                          </span>
                        )}
                        <span>{item.matchId}</span>
                      </div>
                    </td>
                    <td>
                      <div className="font-semibold text-white text-xs">{item.tournamentName}</div>
                      <div className="text-[11px] text-zinc-400">
                        {item.gameMode} • {item.date} {item.playerName ? `• ${item.playerName}` : ''}
                      </div>
                    </td>
                    <td className="text-zinc-300 text-xs font-medium">{item.map}</td>
                    <td className="font-bold text-[#ffd700] text-center text-xs">
                      {item.kills}
                    </td>
                    <td className="font-bold text-[#00ff88] text-center text-xs">
                      {item.points || '-'}
                    </td>
                    <td className="text-zinc-300 text-xs font-mono">#{item.placement}</td>
                    <td>
                      {item.rankStatus === 'WIN' && (
                        <span className="esports-badge esports-badge-green">
                          <CheckCircle2 size={12} />
                          <span>#1 WIN</span>
                        </span>
                      )}
                      {item.rankStatus === 'PODIUM' && (
                        <span className="esports-badge esports-badge-gold">
                          <Trophy size={12} />
                          <span>#{item.placement} PODIUM</span>
                        </span>
                      )}
                      {item.rankStatus === 'LOSS' && (
                        <span className="esports-badge esports-badge-red">
                          <XCircle size={12} />
                          <span>LOSS</span>
                        </span>
                      )}
                    </td>
                    <td className="font-mono text-zinc-400 text-xs">₹{item.entryFee}</td>
                    <td className="font-mono text-white text-xs font-semibold">₹{item.prizeWon}</td>
                    <td
                      className={`font-mono font-extrabold text-xs ${
                        item.netAmount > 0
                          ? 'text-[#00ff88]'
                          : item.netAmount < 0
                          ? 'text-[#ff4655]'
                          : 'text-zinc-400'
                      }`}
                    >
                      {item.netAmount > 0 ? `+₹${item.netAmount}` : item.netAmount < 0 ? `-₹${Math.abs(item.netAmount)}` : '₹0'}
                    </td>
                    <td className="text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenEdit(item)}
                          title="Edit match result"
                          className="p-1 rounded text-zinc-400 hover:text-[#ffd700] hover:bg-zinc-800 transition-colors cursor-pointer"
                        >
                          <Edit2 size={13} />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Delete match record "${item.tournamentName}"?`)) {
                              deleteMatchHistoryItem(item.id);
                            }
                          }}
                          title="Delete result"
                          className="p-1 rounded text-zinc-500 hover:text-red-400 hover:bg-zinc-800 transition-colors cursor-pointer"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Edit Match History Item Modal */}
      {editingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-3xl bg-[#0f0f13] border border-[rgba(212,175,55,0.4)] shadow-[0_25px_60px_rgba(0,0,0,0.95)] overflow-hidden">
            <div className="p-5 border-b border-zinc-800 flex items-center justify-between bg-[#141419]/60">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#ffd700]/15 border border-[#ffd700]/30 flex items-center justify-center text-[#ffd700]">
                  <Edit2 size={16} />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">Edit Match Record</h3>
                  <p className="text-[11px] font-mono text-zinc-400">{editingItem.matchId}</p>
                </div>
              </div>
              <button
                onClick={() => setEditingItem(null)}
                className="p-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="block text-zinc-300 font-bold mb-1">Tournament / Match Title</label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={e => setEditTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white focus:border-[#ffd700] focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-300 font-bold mb-1">Placement Rank</label>
                  <select
                    value={editPlacement}
                    onChange={e => {
                      const rankNum = Number(e.target.value);
                      setEditPlacement(rankNum);
                      if (rankNum === 1) setEditStatus('WIN');
                      else if (rankNum <= 3) setEditStatus('PODIUM');
                      else setEditStatus('LOSS');
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white focus:border-[#ffd700] focus:outline-none"
                  >
                    <option value={1}>#1 (Booyah)</option>
                    <option value={2}>#2 (Runner Up)</option>
                    <option value={3}>#3 (Podium)</option>
                    <option value={4}>#4</option>
                    <option value={5}>#5</option>
                    <option value={6}>#6</option>
                    <option value={7}>#7</option>
                    <option value={8}>#8</option>
                    <option value={9}>#9</option>
                    <option value={10}>#10</option>
                    <option value={12}>#12</option>
                  </select>
                </div>
                <div>
                  <label className="block text-zinc-300 font-bold mb-1">Result Status</label>
                  <select
                    value={editStatus}
                    onChange={e => setEditStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white focus:border-[#ffd700] focus:outline-none"
                  >
                    <option value="WIN">WIN (+1 Index Point)</option>
                    <option value="PODIUM">PODIUM (0 Index Points)</option>
                    <option value="LOSS">LOSS (-1 Index Point)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-300 font-bold mb-1">Kills</label>
                  <input
                    type="number"
                    min="0"
                    value={editKills}
                    onChange={e => setEditKills(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white font-bold focus:border-[#ffd700] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-zinc-300 font-bold mb-1">Prize Won (₹)</label>
                  <input
                    type="number"
                    min="0"
                    value={editPrize}
                    onChange={e => setEditPrize(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-[#ffd700] font-bold focus:border-[#ffd700] focus:outline-none"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-[11px] text-zinc-400">
                Performance impact: <strong className={editStatus === 'WIN' ? 'text-[#00ff88]' : editStatus === 'LOSS' ? 'text-[#ff4655]' : 'text-[#ffd700]'}>
                  {editStatus === 'WIN' ? '+1 point upward' : editStatus === 'LOSS' ? '-1 point downward' : '0 neutral'}
                </strong>. Saving will immediately recalculate the Team Progress Graph.
              </div>

              <div className="pt-2 flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => setEditingItem(null)}
                  className="flex-1 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#ffd700] hover:bg-[#ffe234] text-black font-black uppercase tracking-wider shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Save size={14} />
                  <span>Save & Recalculate</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Match History / Screenshot OCR Modal */}
      <AddMatchHistoryModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
      />
    </div>
  );
};

