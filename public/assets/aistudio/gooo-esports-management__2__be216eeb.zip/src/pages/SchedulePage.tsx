import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  Swords,
  Users,
  MapPin,
  Trophy,
  Filter,
  Flame,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  Info,
  Sparkles,
  CheckCircle2,
  PlusCircle,
  MessageCircle,
  ExternalLink,
  Edit2,
  Trash2,
  X,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';
import { Tournament, TournamentFormat } from '../types';
import { calculateISTCountdown, formatCurrencyINR } from '../utils/esportsMath';

interface SchedulePageProps {
  onNavigate: (page: string, tournamentId?: string) => void;
}

export const SchedulePage: React.FC<SchedulePageProps> = ({ onNavigate }) => {
  const {
    tournaments,
    setSelectedTournamentId,
    searchFilter,
    openAddMatchModal,
    deleteTournament,
    updateTournamentConfig,
  } = useTournament();

  const [formatFilter, setFormatFilter] = useState<'ALL' | TournamentFormat>('ALL');
  const [nowMs, setNowMs] = useState(Date.now());

  // Editing state for manual inline adjustments
  const [editingTour, setEditingTour] = useState<Tournament | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editFormat, setEditFormat] = useState<TournamentFormat>('BR Squad');
  const [editDate, setEditDate] = useState('');
  const [editTime, setEditTime] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [editWaUrl, setEditWaUrl] = useState('');

  // Real-time ticking interval for IST countdowns (updates every second)
  useEffect(() => {
    const timer = setInterval(() => {
      setNowMs(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleOpenEdit = (t: Tournament, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingTour(t);
    setEditTitle(t.title);
    setEditFormat(t.format);
    setEditDate(t.scheduledDateIST?.split(' ')[0] || '');
    setEditTime(t.scheduledDateIST?.split(' ')[1] || '20:30');
    setEditNotes(t.strategyNotes || '');
    setEditWaUrl(t.whatsAppGroupUrl || '');
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTour) return;

    let targetMs = editingTour.targetTimestampMs;
    try {
      if (editDate && editTime) {
        const [h, m] = editTime.split(':').map(Number);
        const [yr, mo, da] = editDate.split('-').map(Number);
        targetMs = new Date(yr, mo - 1, da, h, m).getTime();
      }
    } catch {
      // Keep existing
    }

    updateTournamentConfig(editingTour.id, {
      title: editTitle.trim(),
      format: editFormat,
      strategyNotes: editNotes.trim() || undefined,
      whatsAppGroupUrl: editWaUrl.trim() || undefined,
      startTimeIST: `${editDate} ${editTime} IST`,
      scheduledDateIST: `${editDate} ${editTime}`,
      targetTimestampMs: targetMs,
      status: targetMs <= Date.now() ? 'LIVE' : 'UPCOMING',
    });

    setEditingTour(null);
  };

  const filteredTournaments = tournaments.filter(t => {
    if (formatFilter !== 'ALL' && t.format !== formatFilter) return false;
    if (searchFilter) {
      const q = searchFilter.toLowerCase();
      const match =
        t.title.toLowerCase().includes(q) ||
        t.format.toLowerCase().includes(q) ||
        t.map.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  return (
    <div className="space-y-8 pb-14">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl lg:text-2xl font-black text-white flex items-center gap-2">
              <Calendar size={22} className="text-[#ffd700]" />
              <span>My Match Schedule (IST)</span>
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-[#ffd700]/15 text-[#ffd700] border border-[#ffd700]/30">
              Indian Standard Time
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Manual match scheduling for Solo, Duo & Squad with live ticking countdowns
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={openAddMatchModal}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-extrabold text-xs uppercase tracking-wider shadow-[0_0_15px_rgba(255,215,0,0.3)] hover:scale-105 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <PlusCircle size={15} />
            <span>+ Plan New Match</span>
          </button>
        </div>
      </div>

      {/* Organizer Guidelines & Notes Banner (Preserved) */}
      <div className="p-4 rounded-2xl bg-[#0f0f13] border border-amber-500/25 flex items-start gap-3 text-xs text-zinc-300">
        <Info size={18} className="text-[#ffd700] shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="font-bold text-white flex items-center gap-2">
            <span>Free Fire eSports Schedule & Guidelines</span>
            <span className="text-[10px] font-bold text-[#00ff88] bg-[#00ff88]/10 px-2 py-0.5 rounded-full">
              Live IST Sync
            </span>
          </div>
          <p className="text-zinc-400 text-[11px] leading-relaxed">
            All schedules follow Indian Standard Time (IST). Each match card displays a synchronized live ticking countdown. You can manually adjust Match Name, Date, Time, and Format (Solo / Duo / Squad) at any time.
          </p>
        </div>
      </div>

      {/* Format Filter Bar (Solo / Duo / Squad) */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-2 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)]">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {[
            { id: 'ALL', label: 'All Formats' },
            { id: 'BR Squad', label: 'Squad' },
            { id: 'BR Duo', label: 'Duo' },
            { id: 'BR Solo', label: 'Solo' },
            { id: 'Clash Squad 4v4', label: 'Clash Squad' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setFormatFilter(tab.id as any)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                formatFilter === tab.id
                  ? 'bg-[#ffd700] text-black shadow-md'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="text-xs text-zinc-400 font-mono pr-2">
          {filteredTournaments.length} scheduled
        </div>
      </div>

      {/* Schedule Countdown Cards Grid */}
      {filteredTournaments.length === 0 ? (
        <div className="p-10 rounded-3xl bg-[#0f0f13] border border-[rgba(212,175,55,0.2)] text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-[#ffd700]/10 border border-[#ffd700]/30 flex items-center justify-center text-[#ffd700] mx-auto">
            <Calendar size={28} />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-black text-white">No Matches Scheduled</h3>
            <p className="text-xs text-zinc-400 max-w-md mx-auto">
              Your match schedule is clean. Add your first Solo, Duo, or Squad match to set up countdowns and guidelines.
            </p>
          </div>
          <button
            onClick={openAddMatchModal}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(255,215,0,0.3)] hover:scale-105 transition-all inline-flex items-center gap-2 cursor-pointer"
          >
            <PlusCircle size={16} />
            <span>+ Plan New Match</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTournaments.map(tour => {
            const countdown = calculateISTCountdown(tour.targetTimestampMs, nowMs);
            return (
              <div
                key={tour.id}
                className="rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.22)] p-5 space-y-4 relative overflow-hidden group hover:border-[#ffd700]/70 hover:shadow-[0_15px_35px_rgba(255,215,0,0.12)] transition-all flex flex-col justify-between"
              >
                {/* Header Info */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-black px-2.5 py-0.5 rounded-full bg-[#ffd700]/15 text-[#ffd700] border border-[#ffd700]/30">
                      {tour.format}
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => handleOpenEdit(tour, e)}
                        title="Edit schedule details"
                        className="p-1 rounded-md bg-zinc-800 text-zinc-400 hover:text-[#ffd700] transition-colors cursor-pointer"
                      >
                        <Edit2 size={13} />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`Delete match "${tour.title}"?`)) {
                            deleteTournament(tour.id);
                          }
                        }}
                        title="Delete match"
                        className="p-1 rounded-md bg-zinc-800 text-zinc-400 hover:text-red-400 transition-colors cursor-pointer"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>

                  <h3 className="font-extrabold text-white text-base group-hover:text-[#ffd700] transition-colors line-clamp-1">
                    {tour.title}
                  </h3>

                  <div className="text-xs text-zinc-400 flex items-center gap-1.5">
                    <Clock size={13} className="text-zinc-500" />
                    <span>Scheduled: <strong className="text-white">{tour.startTimeIST}</strong></span>
                  </div>

                  {tour.strategyNotes && (
                    <div className="p-2 rounded-xl bg-zinc-900/60 border border-zinc-800/80 text-[11px] text-zinc-300">
                      <span className="text-[#ffd700] font-semibold">Notes: </span>
                      <span className="line-clamp-2">{tour.strategyNotes}</span>
                    </div>
                  )}
                </div>

                {/* REAL-TIME IST COUNTDOWN BOX */}
                <div className="p-3.5 rounded-xl bg-gradient-to-br from-[#16161e] to-[#0c0c10] border border-[rgba(212,175,55,0.3)] shadow-inner text-center space-y-1">
                  <div className="text-[10px] font-black uppercase tracking-widest text-zinc-400 flex items-center justify-center gap-1.5">
                    <Sparkles size={12} className="text-[#ffd700]" />
                    <span>IST Match Countdown</span>
                  </div>
                  <div
                    className={`text-xl sm:text-2xl font-mono font-black tracking-wider ${
                      countdown.isLive
                        ? 'text-[#00ff88] animate-pulse'
                        : countdown.isPast
                        ? 'text-zinc-500'
                        : 'text-[#ffd700]'
                    }`}
                  >
                    {countdown.formatted}
                  </div>
                  <div className="text-[10px] text-zinc-400">
                    {countdown.isLive
                      ? 'Match is Live Now'
                      : countdown.isPast
                      ? 'Match Concluded'
                      : 'Kickoff in Indian Standard Time'}
                  </div>
                </div>

                {/* WhatsApp Group Link or Share Button */}
                <div className="pt-1">
                  {tour.whatsAppGroupUrl ? (
                    <a
                      href={tour.whatsAppGroupUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2.5 px-3 rounded-xl bg-[#25D366]/15 hover:bg-[#25D366]/25 border border-[#25D366]/35 text-[#25D366] text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <MessageCircle size={15} />
                      <span>Join WhatsApp Group</span>
                      <ExternalLink size={12} />
                    </a>
                  ) : (
                    <a
                      href={`https://wa.me/?text=${encodeURIComponent(
                        `🏆 *MATCH ALERT: ${tour.title}* 🏆\nTime: ${tour.startTimeIST}\nFormat: ${tour.format} (${tour.map})\nBe ready!`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <MessageCircle size={14} className="text-[#25D366]" />
                      <span>WhatsApp Match Alert</span>
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Manual Edit Match Modal (Requirement 5) */}
      {editingTour && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.4)] p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <Edit2 size={16} className="text-[#ffd700]" />
                <span>Edit Match Schedule</span>
              </h3>
              <button
                onClick={() => setEditingTour(null)}
                className="p-1 rounded-lg text-zinc-400 hover:text-white cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-zinc-300 font-semibold mb-1">Match Name</label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={e => setEditTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white focus:border-[#ffd700] focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-zinc-300 font-semibold mb-1">Format</label>
                <select
                  value={editFormat}
                  onChange={e => setEditFormat(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white focus:border-[#ffd700] focus:outline-none"
                >
                  <option value="BR Squad">Squad</option>
                  <option value="BR Duo">Duo</option>
                  <option value="BR Solo">Solo</option>
                  <option value="Clash Squad 4v4">Clash Squad</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-zinc-300 font-semibold mb-1">Date</label>
                  <input
                    type="date"
                    value={editDate}
                    onChange={e => setEditDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white focus:border-[#ffd700] focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-zinc-300 font-semibold mb-1">Time (IST)</label>
                  <input
                    type="time"
                    value={editTime}
                    onChange={e => setEditTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white focus:border-[#ffd700] focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-zinc-300 font-semibold mb-1">WhatsApp Group Link</label>
                <input
                  type="url"
                  value={editWaUrl}
                  onChange={e => setEditWaUrl(e.target.value)}
                  placeholder="https://chat.whatsapp.com/..."
                  className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white focus:border-[#25D366] focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-zinc-300 font-semibold mb-1">Notes & Guidelines</label>
                <textarea
                  rows={2}
                  value={editNotes}
                  onChange={e => setEditNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white focus:border-[#ffd700] focus:outline-none"
                />
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setEditingTour(null)}
                  className="flex-1 py-2.5 rounded-xl bg-zinc-900 text-zinc-400 font-bold hover:bg-zinc-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[#ffd700] text-black font-extrabold shadow-md hover:bg-[#ffe234]"
                >
                  Save Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
