import React, { useState } from 'react';
import { X, Trophy, Swords, CheckCircle2 } from 'lucide-react';
import { useTournament } from '../context/TournamentContext';
import { Tournament } from '../types';

interface RecordResultModalProps {
  tournament: Tournament | null;
  isOpen: boolean;
  onClose: () => void;
}

export const RecordResultModal: React.FC<RecordResultModalProps> = ({
  tournament,
  isOpen,
  onClose,
}) => {
  const { recordMatchResult } = useTournament();

  const [placement, setPlacement] = useState<number>(1);
  const [kills, setKills] = useState<number>(8);
  const [points, setPoints] = useState<number>(20);
  const [prizeWon, setPrizeWon] = useState<number>(tournament ? tournament.firstPrize : 1000);

  if (!isOpen || !tournament) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    recordMatchResult(tournament.id, Number(kills), Number(placement), Number(prizeWon), Number(points));
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
      <div className="relative w-full max-w-md rounded-3xl bg-[#0f0f13] border border-[rgba(212,175,55,0.3)] shadow-[0_25px_60px_rgba(0,0,0,0.95)] overflow-hidden">
        <div className="p-5 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#00ff88]/15 border border-[#00ff88]/30 flex items-center justify-center text-[#00ff88]">
              <Trophy size={20} />
            </div>
            <div>
              <h2 className="text-base font-black text-white">Record Match Result</h2>
              <p className="text-xs text-zinc-400 line-clamp-1">{tournament.title}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close result modal"
            className="p-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider">
              Final Placement Rank
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { rank: 1, label: '#1 Booyah' },
                { rank: 2, label: '#2 Podium' },
                { rank: 3, label: '#3 Podium' },
                { rank: 4, label: 'Top 10' },
              ].map(opt => (
                <button
                  type="button"
                  key={opt.rank}
                  onClick={() => {
                    setPlacement(opt.rank);
                    if (opt.rank === 1) {
                      setPrizeWon(tournament.firstPrize || 1000);
                      setPoints(12 + kills);
                    } else if (opt.rank <= 3) {
                      setPrizeWon(Math.round((tournament.prizePool || 1000) * 0.3));
                      setPoints(8 + kills);
                    } else {
                      setPrizeWon(0);
                      setPoints(kills);
                    }
                  }}
                  className={`py-2 px-1 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                    placement === opt.rank
                      ? 'bg-[#ffd700] text-black border-[#ffd700]'
                      : 'bg-[#141419] text-zinc-300 border-zinc-700'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2.5">
            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-300">Team Kills</label>
              <input
                type="number"
                min="0"
                value={kills}
                onChange={e => {
                  const k = Number(e.target.value);
                  setKills(k);
                  setPoints((placement === 1 ? 12 : placement <= 3 ? 8 : 4) + k);
                }}
                className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-white text-xs font-bold focus:border-[#ffd700] focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-[#00ff88]">Points</label>
              <input
                type="number"
                min="0"
                value={points}
                onChange={e => setPoints(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-[#00ff88] text-xs font-bold focus:border-[#ffd700] focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-[#ffd700]">Prize (₹)</label>
              <input
                type="number"
                min="0"
                value={prizeWon}
                onChange={e => setPrizeWon(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-[#141419] border border-zinc-700 text-[#ffd700] text-xs font-bold focus:border-[#ffd700] focus:outline-none"
              />
            </div>
          </div>

          {/* Entry fee and net calculation */}
          <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-between text-xs">
            <span className="text-zinc-400">Match Entry Fee:</span>
            <span className="text-white font-mono">₹{tournament.entryFee}</span>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#00ff88] to-[#00c968] text-black font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(0,255,136,0.25)] flex items-center justify-center gap-2 cursor-pointer"
            >
              <CheckCircle2 size={16} />
              <span>Confirm & Save to Match Ledger</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
