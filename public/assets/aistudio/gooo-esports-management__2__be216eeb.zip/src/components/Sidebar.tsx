import React, { useState } from 'react';
import {
  Trophy,
  LayoutDashboard,
  Calendar,
  Shield,
  BarChart3,
  Swords,
  History,
  TrendingUp,
  User,
  Bell,
  LogIn,
  LogOut,
  ShieldCheck,
  Menu,
  X,
  MessageCircle,
  ExternalLink,
  PlusCircle,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';
import { getRankBadge } from '../utils/esportsMath';

interface SidebarProps {
  activePage: string;
  onNavigate?: (page: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activePage, onNavigate }) => {
  const { user, unreadCount, logout, openAddMatchModal } = useTournament();
  const [mobileOpen, setMobileOpen] = useState(false);
  const rank = getRankBadge(user.rankedScore);

  const navItems = [
    { id: 'index', name: 'Overview', href: 'index.html', icon: Trophy, label: 'Portal' },
    { id: 'dashboard', name: 'My Dashboard', href: 'dashboard.html', icon: LayoutDashboard, label: 'Live HUD' },
    { id: 'schedule', name: 'My Match Schedule (IST)', href: 'schedule.html', icon: Calendar, label: 'Countdowns' },
    { id: 'tournaments', name: 'Match Planner & Scrims', href: 'tournaments.html', icon: Swords, label: 'Planner' },
    { id: 'lobbies', name: 'Team Lobbies & Hub', href: 'lobbies.html', icon: Shield, label: 'Rooms & Roster' },
    { id: 'analyze', name: 'Team Analytics', href: 'analyze.html', icon: BarChart3, label: 'Performance' },
    { id: 'history', name: 'Match History', href: 'history.html', icon: History, label: 'Results' },
    { id: 'profit-loss', name: 'Profit & Loss (Rs.)', href: 'profit-loss.html', icon: TrendingUp, label: 'Finance' },
    { id: 'profile', name: 'Team & Player Profile', href: 'profile.html', icon: User, label: 'Profile' },
    {
      id: 'notifications',
      name: 'Match Reminders',
      href: 'notifications.html',
      icon: Bell,
      badge: unreadCount > 0 ? unreadCount : undefined,
      label: 'Alerts',
    },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, id: string, href: string) => {
    if (onNavigate) {
      e.preventDefault();
      onNavigate(id);
      window.history.pushState({}, '', href);
      setMobileOpen(false);
    }
  };

  return (
    <>
      {/* Mobile Top Bar */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-[#0a0a0d]/95 backdrop-blur border-b border-[rgba(212,175,55,0.25)] px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle navigation menu"
            className="p-2 rounded-lg bg-[#141419] border border-[rgba(212,175,55,0.25)] text-[#ffd700] cursor-pointer"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <div className="flex items-center gap-2">
            <img
              src={user.avatarUrl || '/assets/aistudio/photo__1__f37c447f.jpg'}
              alt="Destroyed eSports Crest"
              className="w-8 h-8 rounded-lg object-cover border border-[#ffd700] shadow-[0_0_10px_rgba(255,215,0,0.3)]"
            />
            <div className="flex flex-col">
              <span className="font-black tracking-wider text-sm text-white">
                DESTROYED
              </span>
              <span className="text-[9px] uppercase tracking-widest text-[#ffd700] font-bold -mt-0.5">
                eSports Management
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={openAddMatchModal}
            className="px-2.5 py-1 rounded-full bg-[#ffd700] text-black text-xs font-black flex items-center gap-1 cursor-pointer"
          >
            <PlusCircle size={13} />
            <span>+ Match</span>
          </button>
          <a
            href="https://wa.me/919876543210?text=Hi%20Destroyed%20eSports"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="WhatsApp Support"
            className="p-1.5 rounded-full bg-[#25D366]/15 border border-[#25D366]/30 text-[#25D366]"
          >
            <MessageCircle size={18} />
          </a>
        </div>
      </div>

      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          onClick={() => setMobileOpen(false)}
          className="lg:hidden fixed inset-0 z-40 bg-black/80 backdrop-blur-xs"
        />
      )}

      {/* Persistent Sidebar */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 bg-[#0a0a0d] border-r border-[rgba(212,175,55,0.2)] flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="p-4 border-b border-[rgba(212,175,55,0.18)]">
          <a href="index.html" className="flex items-center gap-3 group">
            <div className="relative">
              <img
                src={user.avatarUrl || '/assets/aistudio/photo__1__f37c447f.jpg'}
                alt="Destroyed eSports Logo"
                className="w-12 h-12 rounded-xl object-cover border-2 border-[#ffd700] shadow-[0_0_18px_rgba(255,215,0,0.35)] group-hover:scale-105 transition-transform"
              />
              <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-[#00ff88] border-2 border-[#0a0a0d]" />
            </div>
            <div>
              <div className="font-black text-xl tracking-wider text-white flex items-center gap-1.5">
                <span>DESTROYED</span>
                <span className="text-[9px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded bg-[#ffd700]/15 text-[#ffd700] border border-[#ffd700]/30">
                  OFFICIAL
                </span>
              </div>
              <div className="text-[11px] text-[#ffd700] font-bold tracking-wide">
                eSports Management
              </div>
            </div>
          </a>
        </div>

        {/* Player & Team Profile Snapshot */}
        <div className="p-3.5 mx-3 my-3 rounded-2xl bg-[#111116] border border-[rgba(212,175,55,0.22)] shadow-inner">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={user.avatarUrl || '/assets/aistudio/photo__1__f37c447f.jpg'}
                alt={user.ign}
                className="w-11 h-11 rounded-xl object-cover border-2 border-[#ffd700] shadow-[0_0_12px_rgba(255,215,0,0.3)]"
              />
              <span className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-[#00ff88] border-2 border-[#0a0a0d]" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="font-bold text-white text-xs truncate flex items-center gap-1">
                <span>{user.ign}</span>
                <ShieldCheck size={13} className="text-[#00f0ff] shrink-0" />
              </div>
              <div className="text-[10px] text-zinc-400 font-mono">UID: {user.freeFireUid}</div>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span
                  className="text-[9px] font-bold px-2 py-0.5 rounded-full border truncate"
                  style={{
                    backgroundColor: `${rank.badgeColor}18`,
                    color: rank.badgeColor,
                    borderColor: `${rank.badgeColor}40`,
                  }}
                >
                  {rank.title}
                </span>
              </div>
            </div>
          </div>

          {/* Team Roster Snapshot */}
          <div className="mt-2.5 pt-2.5 border-t border-zinc-800/80 flex items-center justify-between text-xs">
            <span className="text-zinc-400 flex items-center gap-1 text-[11px]">
              <Shield size={12} className="text-[#ffd700]" /> Team Squad
            </span>
            <span className="font-bold text-[#ffd700] tracking-wide text-[11px]">
              {user.teamName || 'Team Destroyed'}
            </span>
          </div>

          {/* Quick Plan Match Action */}
          <button
            onClick={() => {
              openAddMatchModal();
              setMobileOpen(false);
            }}
            className="w-full mt-3 py-2 px-3 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-black text-xs uppercase tracking-wider shadow-[0_0_15px_rgba(255,215,0,0.3)] hover:brightness-110 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <PlusCircle size={14} />
            <span>+ Plan / Add Match</span>
          </button>
        </div>

        {/* Navigation Links */}
        <div className="flex-1 overflow-y-auto px-3 py-1 space-y-1">
          <div className="px-3 py-1.5 text-[10px] font-bold tracking-widest text-zinc-500 uppercase">
            Destroyed System
          </div>
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            return (
              <a
                key={item.id}
                href={item.href}
                onClick={e => handleLinkClick(e, item.id, item.href)}
                className={`group flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 ${
                  isActive
                    ? 'bg-gradient-to-r from-[#ffd700]/20 to-transparent text-[#ffd700] border-l-4 border-[#ffd700] shadow-[inset_0_0_12px_rgba(255,215,0,0.08)] font-bold'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    size={17}
                    className={`transition-colors shrink-0 ${
                      isActive ? 'text-[#ffd700]' : 'text-zinc-500 group-hover:text-zinc-300'
                    }`}
                  />
                  <span className="truncate">{item.name}</span>
                </div>
                {item.badge !== undefined && (
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-[#ff4655] text-white shadow-[0_0_8px_rgba(255,70,85,0.4)]">
                    {item.badge}
                  </span>
                )}
              </a>
            );
          })}
        </div>

        {/* WhatsApp & Community Quick Access */}
        <div className="p-3 border-t border-[rgba(212,175,55,0.18)] bg-[#07070a] space-y-2">
          <a
            href="https://wa.me/919876543210?text=Hi%20Destroyed%20eSports!%20Team%20Destroyed%20scrims%20hub."
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-[#25D366]/15 hover:bg-[#25D366]/25 border border-[#25D366]/35 text-[#25D366] text-xs font-bold transition-all shadow-[0_0_12px_rgba(37,211,102,0.1)] group"
          >
            <MessageCircle size={15} className="group-hover:scale-110 transition-transform" />
            <span>Destroyed WhatsApp Hub</span>
            <ExternalLink size={12} className="opacity-70" />
          </a>

          {/* Auth Action */}
          {user.isLoggedIn ? (
            <button
              onClick={() => {
                logout();
                if (onNavigate) onNavigate('login');
              }}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-zinc-900/80 hover:bg-zinc-800 text-zinc-400 hover:text-red-400 text-xs font-medium transition-colors border border-zinc-800 cursor-pointer"
            >
              <LogOut size={13} />
              <span>Sign Out ({user.freeFireUid})</span>
            </button>
          ) : (
            <a
              href="login.html"
              onClick={e => handleLinkClick(e, 'login', 'login.html')}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-[#ffd700] hover:bg-[#ffe234] text-black text-xs font-bold transition-colors shadow-[0_0_15px_rgba(255,215,0,0.3)] cursor-pointer"
            >
              <LogIn size={13} />
              <span>Sign Up / Sign In</span>
            </a>
          )}
        </div>
      </aside>
    </>
  );
};
