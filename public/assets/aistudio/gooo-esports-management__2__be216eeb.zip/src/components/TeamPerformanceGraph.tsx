import React, { useState, useMemo, useRef } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Flame,
  Trophy,
  Filter,
  CheckCircle2,
  XCircle,
  HelpCircle,
  PlusCircle,
  Sparkles,
  ChevronRight,
  Crosshair,
} from 'lucide-react';
import {
  calculatePerformanceGraphData,
  ProgressFilter,
  PerformanceDataPoint,
} from '../utils/esportsMath';
import { MatchHistoryItem } from '../types';

interface TeamPerformanceGraphProps {
  history: MatchHistoryItem[];
  onAddMatchClick?: () => void;
}

export const TeamPerformanceGraph: React.FC<TeamPerformanceGraphProps> = ({
  history,
  onAddMatchClick,
}) => {
  const [activeFilter, setActiveFilter] = useState<ProgressFilter>('ALL');
  const [hoveredPointIndex, setHoveredPointIndex] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Recalculate graph data whenever history or activeFilter changes
  const graphData = useMemo(() => {
    return calculatePerformanceGraphData(history, activeFilter);
  }, [history, activeFilter]);

  const {
    points,
    totalMatchesInFilter,
    totalSavedMatches,
    currentScore,
    peakScore,
    lowestScore,
    winsCount,
    lossesCount,
    winRateInFilter,
    winStreak,
    momentum,
  } = graphData;

  // Active point for tooltip (hovered point, or default to the latest match point)
  const activePoint: PerformanceDataPoint | null = useMemo(() => {
    if (hoveredPointIndex !== null && points[hoveredPointIndex]) {
      return points[hoveredPointIndex];
    }
    // Default to the latest recorded match
    if (points.length > 1) {
      return points[points.length - 1];
    }
    return points[0] || null;
  }, [hoveredPointIndex, points]);

  // Handle pointer/touch movement across the SVG canvas to find the closest match point
  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    if (!rect.width) return;
    const clientX = e.clientX;
    const svgX = ((clientX - rect.left) / rect.width) * svgWidth;

    let closestIdx = 0;
    let minDist = Infinity;
    linePoints.forEach((pt, idx) => {
      const dist = Math.abs(pt.x - svgX);
      if (dist < minDist) {
        minDist = dist;
        closestIdx = idx;
      }
    });

    setHoveredPointIndex(closestIdx);
  };

  // When there are no saved matches
  if (!history || history.length === 0) {
    return (
      <div className="rounded-3xl bg-[#0f0f13] border border-[rgba(212,175,55,0.25)] p-8 sm:p-12 text-center space-y-5 shadow-[0_15px_35px_rgba(0,0,0,0.8)] relative overflow-hidden">
        <div className="absolute -top-16 -right-16 w-48 h-48 rounded-full bg-[#ffd700]/5 blur-3xl pointer-events-none" />
        <div className="w-16 h-16 rounded-2xl bg-[#ffd700]/10 border border-[#ffd700]/30 flex items-center justify-center text-[#ffd700] mx-auto shadow-[0_0_20px_rgba(255,215,0,0.2)]">
          <Activity size={32} />
        </div>
        <div className="space-y-2 max-w-lg mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#ffd700]/10 border border-[#ffd700]/30 text-[#ffd700] text-[11px] font-black uppercase tracking-wider">
            Team Performance Analytics
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white tracking-wide">
            No Match Performance Data Yet
          </h3>
          <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
            Your squad performance graph starts strictly at a <strong className="text-white">zero baseline</strong>. Every verified match record moves the trajectory: <span className="text-[#00ff88] font-bold">WIN adds +1</span> and moves upward, while <span className="text-[#ff4655] font-bold">LOSS subtracts -1</span> and moves downward.
          </p>
        </div>
        {onAddMatchClick && (
          <div className="pt-2">
            <button
              onClick={onAddMatchClick}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-extrabold text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(255,215,0,0.3)] hover:scale-105 transition-all inline-flex items-center gap-2 cursor-pointer"
            >
              <PlusCircle size={16} />
              <span>Record First Match Result</span>
            </button>
          </div>
        )}
      </div>
    );
  }

  // SVG Chart Geometry
  const svgWidth = 860;
  const svgHeight = 320;
  const paddingLeft = 55;
  const paddingRight = 45;
  const paddingTop = 35;
  const paddingBottom = 55;
  const plotWidth = svgWidth - paddingLeft - paddingRight;
  const plotHeight = svgHeight - paddingTop - paddingBottom;

  // Determine integer Y range (at least -2 to +2 for clear visual zero baseline)
  const yMin = Math.min(-2, lowestScore - 1);
  const yMax = Math.max(2, peakScore + 1);
  const yRange = yMax - yMin;

  const getY = (val: number) => {
    const ratio = (val - yMin) / yRange;
    return paddingTop + (1 - ratio) * plotHeight;
  };

  const getX = (index: number) => {
    if (points.length <= 1) return paddingLeft + plotWidth / 2;
    return paddingLeft + (index / (points.length - 1)) * plotWidth;
  };

  const zeroY = getY(0);

  // Generate path data
  const linePoints = points.map((p, idx) => ({
    x: getX(idx),
    y: getY(p.performanceIndex),
    data: p,
  }));

  // Build SVG polyline points
  const polylinePath = linePoints.map(p => `${p.x},${p.y}`).join(' ');

  // Build Area Path under line back to baseline
  const firstPt = linePoints[0];
  const lastPt = linePoints[linePoints.length - 1];
  const areaPath = firstPt && lastPt ? [
    `M ${firstPt.x},${zeroY}`,
    ...linePoints.map(p => `L ${p.x},${p.y}`),
    `L ${lastPt.x},${zeroY}`,
    'Z',
  ].join(' ') : '';

  // Y-axis tick values (all integers in range)
  const yTicks: number[] = [];
  for (let val = yMin; val <= yMax; val++) {
    yTicks.push(val);
  }

  return (
    <div className="rounded-3xl bg-[#0f0f13] border border-[rgba(212,175,55,0.25)] p-5 sm:p-7 shadow-[0_20px_45px_rgba(0,0,0,0.85)] space-y-6 relative overflow-hidden">
      {/* Ambient background glow */}
      <div
        className="absolute -top-24 -right-24 w-80 h-80 rounded-full blur-3xl pointer-events-none transition-all duration-700"
        style={{
          backgroundColor:
            currentScore > 0
              ? 'rgba(0, 255, 136, 0.08)'
              : currentScore < 0
              ? 'rgba(255, 70, 85, 0.08)'
              : 'rgba(255, 215, 0, 0.08)',
        }}
      />

      {/* Header & Filter Controls */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 border-b border-zinc-800/80 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-[#ffd700]/15 border border-[#ffd700]/30 flex items-center justify-center text-[#ffd700]">
              <Activity size={18} />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>Team Performance Progress Graph</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#00ff88]/15 text-[#00ff88] border border-[#00ff88]/30">
                  Live Recalculated
                </span>
              </h3>
              <p className="text-xs text-zinc-400 mt-0.5">
                Chronological index: <strong className="text-[#00ff88]">WIN (+1)</strong> upward • <strong className="text-[#ff4655]">LOSS (-1)</strong> downward • Baseline starts at 0
              </p>
            </div>
          </div>
        </div>

        {/* Filter Pills (Last 7, Last 15, Last 30, All Matches) */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-2xl bg-zinc-900/90 border border-zinc-800 shrink-0">
          {[
            { id: '7' as ProgressFilter, label: 'Last 7 Matches' },
            { id: '15' as ProgressFilter, label: 'Last 15 Matches' },
            { id: '30' as ProgressFilter, label: 'Last 30 Matches' },
            { id: 'ALL' as ProgressFilter, label: 'All Matches' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveFilter(tab.id);
                setHoveredPointIndex(null);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                activeFilter === tab.id
                  ? 'bg-[#ffd700] text-black shadow-[0_0_12px_rgba(255,215,0,0.35)] font-black'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Ticker Summary Chips */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Current Score */}
        <div className="p-3.5 rounded-2xl bg-[#141419] border border-zinc-800/80 space-y-1">
          <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
            Current Index
          </div>
          <div
            className={`text-2xl font-black font-mono flex items-center gap-1 ${
              currentScore > 0
                ? 'text-[#00ff88]'
                : currentScore < 0
                ? 'text-[#ff4655]'
                : 'text-[#ffd700]'
            }`}
          >
            <span>{currentScore > 0 ? `+${currentScore}` : currentScore}</span>
            {currentScore > 0 ? (
              <TrendingUp size={18} className="text-[#00ff88]" />
            ) : currentScore < 0 ? (
              <TrendingDown size={18} className="text-[#ff4655]" />
            ) : null}
          </div>
          <div className="text-[10px] text-zinc-500">
            {currentScore > 0
              ? 'Positive performance record'
              : currentScore < 0
              ? 'Below baseline record'
              : 'Even zero baseline'}
          </div>
        </div>

        {/* Peak & Low Rating */}
        <div className="p-3.5 rounded-2xl bg-[#141419] border border-zinc-800/80 space-y-1">
          <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
            Range in Window
          </div>
          <div className="text-xl font-black text-white font-mono flex items-center gap-2">
            <span className="text-[#00ff88]">+{peakScore}</span>
            <span className="text-zinc-600">/</span>
            <span className="text-[#ff4655]">{lowestScore}</span>
          </div>
          <div className="text-[10px] text-zinc-500">
            Peak: +{peakScore} • Lowest: {lowestScore}
          </div>
        </div>

        {/* Win-Loss in Window */}
        <div className="p-3.5 rounded-2xl bg-[#141419] border border-zinc-800/80 space-y-1">
          <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
            Record in Filter
          </div>
          <div className="text-xl font-black text-white font-mono flex items-center gap-1.5">
            <span className="text-[#00ff88]">{winsCount}W</span>
            <span className="text-zinc-500">-</span>
            <span className="text-[#ff4655]">{lossesCount}L</span>
          </div>
          <div className="text-[10px] text-[#ffd700] font-semibold">
            {winRateInFilter}% Win Rate ({totalMatchesInFilter} matches)
          </div>
        </div>

        {/* Momentum / Streak */}
        <div className="p-3.5 rounded-2xl bg-[#141419] border border-zinc-800/80 space-y-1">
          <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
            Squad Momentum
          </div>
          <div className="text-sm font-black text-[#ffd700] flex items-center gap-1 pt-1">
            {winStreak >= 2 ? (
              <>
                <Flame size={16} className="text-[#ff4655] animate-pulse" />
                <span>{winStreak}x Win Streak!</span>
              </>
            ) : momentum === 'DOMINANT' ? (
              <span className="text-[#00ff88]">Dominant Trajectory</span>
            ) : momentum === 'UPWARD' ? (
              <span className="text-[#00ff88]">Upward Trend</span>
            ) : momentum === 'DOWNWARD' ? (
              <span className="text-[#ff4655]">Rebound Required</span>
            ) : (
              <span className="text-zinc-300">Steady Baseline</span>
            )}
          </div>
          <div className="text-[10px] text-zinc-500">
            Calculated across {totalMatchesInFilter} matches
          </div>
        </div>
      </div>

      {/* SVG Canvas Area */}
      <div
        ref={containerRef}
        className="relative rounded-2xl bg-[#09090c] border border-zinc-800/90 p-2 sm:p-4 overflow-x-auto"
      >
        <div className="min-w-[640px] relative">
          <svg
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            className="w-full h-auto overflow-visible select-none cursor-crosshair"
            onPointerMove={handlePointerMove}
            onPointerLeave={() => setHoveredPointIndex(null)}
          >
            <defs>
              {/* Gold Baseline Glow */}
              <linearGradient id="goldBaselineGrad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#ffd700" stopOpacity="0.1" />
                <stop offset="50%" stopColor="#ffd700" stopOpacity="0.7" />
                <stop offset="100%" stopColor="#ffd700" stopOpacity="0.1" />
              </linearGradient>

              {/* Area Gradient above zero (Green) */}
              <linearGradient id="greenAreaGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#00ff88" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#00ff88" stopOpacity="0.0" />
              </linearGradient>

              {/* Area Gradient below zero (Red) */}
              <linearGradient id="redAreaGrad" x1="0" y1="1" x2="0" y2="0">
                <stop offset="0%" stopColor="#ff4655" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#ff4655" stopOpacity="0.0" />
              </linearGradient>

              {/* Line Stroke Gradient */}
              <linearGradient id="performanceLineGrad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#ffd700" />
                <stop offset="40%" stopColor="#00ff88" />
                <stop offset="70%" stopColor="#ffd700" />
                <stop offset="100%" stopColor="#00f0ff" />
              </linearGradient>

              {/* Node glow filters */}
              <filter id="glowGreen" x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur stdDeviation="3.5" result="coloredBlur" />
                <feMerge>
                  <feMergeNode in="coloredBlur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="glowRed" x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur stdDeviation="3.5" result="coloredBlur" />
                <feMerge>
                  <feMergeNode in="coloredBlur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="glowGold" x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                <feMerge>
                  <feMergeNode in="coloredBlur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Grid Lines & Y Axis Ticks */}
            {yTicks.map(val => {
              const yPos = getY(val);
              const isZero = val === 0;
              return (
                <g key={`y-${val}`}>
                  <line
                    x1={paddingLeft}
                    y1={yPos}
                    x2={svgWidth - paddingRight}
                    y2={yPos}
                    stroke={isZero ? '#ffd700' : 'rgba(255, 255, 255, 0.08)'}
                    strokeWidth={isZero ? 1.5 : 1}
                    strokeDasharray={isZero ? '6,4' : '2,4'}
                    strokeOpacity={isZero ? 0.7 : 0.5}
                  />
                  <text
                    x={paddingLeft - 12}
                    y={yPos + 4}
                    textAnchor="end"
                    className={`font-mono text-[11px] font-bold ${
                      isZero
                        ? 'fill-[#ffd700] font-black'
                        : val > 0
                        ? 'fill-[#00ff88]'
                        : 'fill-[#ff4655]'
                    }`}
                  >
                    {val > 0 ? `+${val}` : val}
                  </text>
                  {isZero && (
                    <text
                      x={svgWidth - paddingRight + 6}
                      y={yPos + 4}
                      textAnchor="start"
                      className="fill-[#ffd700] font-mono text-[9px] font-bold uppercase tracking-wider"
                    >
                      Baseline 0
                    </text>
                  )}
                </g>
              );
            })}

            {/* Shaded Area fill under line */}
            <path
              d={areaPath}
              fill="url(#greenAreaGrad)"
              className="pointer-events-none transition-all duration-300"
            />

            {/* Connecting Line Chart */}
            <polyline
              fill="none"
              stroke="#ffd700"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={polylinePath}
              className="transition-all duration-300"
              filter="url(#glowGold)"
            />

            {/* Colored Segment Overlays between points: Green if WIN, Red if LOSS */}
            {linePoints.map((pt, i) => {
              if (i === 0) return null;
              const prev = linePoints[i - 1];
              const isWin = pt.data.isWin;
              const isLoss = pt.data.isLoss;
              const segmentColor = isWin ? '#00ff88' : isLoss ? '#ff4655' : '#ffd700';

              return (
                <line
                  key={`seg-${i}`}
                  x1={prev.x}
                  y1={prev.y}
                  x2={pt.x}
                  y2={pt.y}
                  stroke={segmentColor}
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  className="pointer-events-none transition-all duration-200"
                />
              );
            })}

            {/* Hover Crosshair Guide Line */}
            {activePoint !== null && (
              <g className="pointer-events-none">
                <line
                  x1={getX(activePoint.index)}
                  y1={paddingTop}
                  x2={getX(activePoint.index)}
                  y2={svgHeight - paddingBottom}
                  stroke="#ffd700"
                  strokeWidth="1.5"
                  strokeDasharray="4,3"
                  strokeOpacity="0.8"
                />
                <circle
                  cx={getX(activePoint.index)}
                  cy={getY(activePoint.performanceIndex)}
                  r="9"
                  fill="none"
                  stroke="#ffd700"
                  strokeWidth="2"
                  className="animate-ping"
                />
              </g>
            )}

            {/* Data Nodes & Indicators */}
            {linePoints.map((pt, i) => {
              const isHovered = hoveredPointIndex === i;
              const isStart = pt.data.isStart;
              const isWin = pt.data.isWin;
              const isLoss = pt.data.isLoss;

              const circleFill = isStart
                ? '#ffd700'
                : isWin
                ? '#00ff88'
                : isLoss
                ? '#ff4655'
                : '#ffd700';

              const filterId = isWin
                ? 'url(#glowGreen)'
                : isLoss
                ? 'url(#glowRed)'
                : 'url(#glowGold)';

              return (
                <g
                  key={`node-${i}`}
                  className="cursor-pointer group"
                  onMouseEnter={() => setHoveredPointIndex(i)}
                  onMouseLeave={() => setHoveredPointIndex(null)}
                  onClick={() => setHoveredPointIndex(i)}
                >
                  {/* Invisible larger hit circle for easy mouse/touch targeting */}
                  <circle
                    cx={pt.x}
                    cy={pt.y}
                    r="20"
                    fill="transparent"
                    className="cursor-pointer"
                  />

                  {/* Outer ring */}
                  <circle
                    cx={pt.x}
                    cy={pt.y}
                    r={isHovered ? 8 : 6}
                    fill="#0a0a0d"
                    stroke={circleFill}
                    strokeWidth={isHovered ? 3 : 2}
                    filter={filterId}
                    className="transition-all duration-200"
                  />

                  {/* Inner dot */}
                  <circle
                    cx={pt.x}
                    cy={pt.y}
                    r={isHovered ? 4.5 : 3}
                    fill={circleFill}
                    className="transition-all duration-200"
                  />

                  {/* Step Change Badge Floating Label (▲ +1 or ▼ -1) */}
                  {!isStart && (
                    <text
                      x={pt.x}
                      y={isWin ? pt.y - 12 : pt.y + 18}
                      textAnchor="middle"
                      className={`font-mono text-[10px] font-black ${
                        isWin ? 'fill-[#00ff88]' : isLoss ? 'fill-[#ff4655]' : 'fill-[#ffd700]'
                      }`}
                    >
                      {isWin ? '▲ +1' : isLoss ? '▼ -1' : '• 0'}
                    </text>
                  )}

                  {/* X-Axis Ticks & Labels */}
                  <text
                    x={pt.x}
                    y={svgHeight - paddingBottom + 18}
                    textAnchor="middle"
                    className={`font-mono text-[10px] ${
                      isHovered
                        ? 'fill-[#ffd700] font-black'
                        : isStart
                        ? 'fill-zinc-400 font-semibold'
                        : 'fill-zinc-400'
                    }`}
                  >
                    {isStart ? 'Start' : `M#${pt.data.matchNumber}`}
                  </text>

                  {/* Match Date Subtext on X-Axis */}
                  <text
                    x={pt.x}
                    y={svgHeight - paddingBottom + 32}
                    textAnchor="middle"
                    className="font-mono text-[9px] fill-zinc-600"
                  >
                    {pt.data.date ? pt.data.date.split(' ')[0].substring(5) : ''}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Interactive Tooltip HUD Popup */}
        {activePoint && (
          <div
            className="mt-3 p-4 rounded-2xl bg-[#141419] border-2 shadow-[0_15px_30px_rgba(0,0,0,0.9)] transition-all animate-in fade-in duration-150"
            style={{
              borderColor: activePoint.isStart
                ? '#ffd700'
                : activePoint.isWin
                ? '#00ff88'
                : activePoint.isLoss
                ? '#ff4655'
                : '#ffd700',
            }}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800 pb-2.5">
              <div className="flex items-center gap-2">
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-black uppercase ${
                    activePoint.isStart
                      ? 'bg-[#ffd700]/20 text-[#ffd700]'
                      : activePoint.isWin
                      ? 'bg-[#00ff88]/20 text-[#00ff88]'
                      : activePoint.isLoss
                      ? 'bg-[#ff4655]/20 text-[#ff4655]'
                      : 'bg-[#ffd700]/20 text-[#ffd700]'
                  }`}
                >
                  {activePoint.isStart
                    ? 'Initial Starting Baseline'
                    : activePoint.isWin
                    ? '🏆 VICTORY (BOOYAH #1)'
                    : activePoint.isLoss
                    ? '💀 DEFEAT (LOSS)'
                    : `🥈 PODIUM (#${activePoint.placement})`}
                </span>
                <span className="text-xs font-bold text-white">
                  {activePoint.label}
                </span>
                {activePoint.matchId && (
                  <span className="text-xs font-mono text-zinc-400">
                    ({activePoint.matchId})
                  </span>
                )}
              </div>

              {/* Performance Index readout */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-zinc-400">Cumulative Index:</span>
                <span
                  className={`text-lg font-black font-mono px-2.5 py-0.5 rounded-lg bg-[#09090c] border ${
                    activePoint.performanceIndex > 0
                      ? 'text-[#00ff88] border-[#00ff88]/30'
                      : activePoint.performanceIndex < 0
                      ? 'text-[#ff4655] border-[#ff4655]/30'
                      : 'text-[#ffd700] border-[#ffd700]/30'
                  }`}
                >
                  {activePoint.performanceIndex > 0
                    ? `+${activePoint.performanceIndex}`
                    : activePoint.performanceIndex}
                </span>
              </div>
            </div>

            {!activePoint.isStart && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 text-xs">
                <div>
                  <span className="text-zinc-500 block text-[10px] uppercase font-bold">
                    Tournament
                  </span>
                  <span className="text-white font-semibold line-clamp-1">
                    {activePoint.tournamentName}
                  </span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[10px] uppercase font-bold">
                    Mode & Map
                  </span>
                  <span className="text-zinc-300">
                    {activePoint.gameMode} ({activePoint.map})
                  </span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[10px] uppercase font-bold">
                    Kills / Placement
                  </span>
                  <span className="text-[#ffd700] font-bold">
                    {activePoint.kills} Kills • #{activePoint.placement} Place
                  </span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[10px] uppercase font-bold">
                    Index Impact
                  </span>
                  <span
                    className={`font-black font-mono ${
                      activePoint.delta > 0
                        ? 'text-[#00ff88]'
                        : activePoint.delta < 0
                        ? 'text-[#ff4655]'
                        : 'text-zinc-400'
                    }`}
                  >
                    {activePoint.delta > 0 ? '+1 Point (Upward)' : activePoint.delta < 0 ? '-1 Point (Downward)' : '0 Points (Neutral)'}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Quick Match Point Inspect Buttons */}
        <div className="mt-3 pt-3 border-t border-zinc-800/60 flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-[10px] uppercase font-bold text-zinc-500 shrink-0">
            Select Point:
          </span>
          {points.map((p, idx) => (
            <button
              key={`inspect-${idx}`}
              onClick={() => setHoveredPointIndex(idx)}
              className={`px-2.5 py-1 rounded-lg font-mono text-[11px] font-bold transition-all cursor-pointer whitespace-nowrap border ${
                activePoint?.index === idx
                  ? p.isStart
                    ? 'bg-[#ffd700] text-black border-[#ffd700] font-black'
                    : p.isWin
                    ? 'bg-[#00ff88] text-black border-[#00ff88] font-black shadow-[0_0_8px_rgba(0,255,136,0.4)]'
                    : p.isLoss
                    ? 'bg-[#ff4655] text-white border-[#ff4655] font-black shadow-[0_0_8px_rgba(255,70,85,0.4)]'
                    : 'bg-[#ffd700] text-black border-[#ffd700]'
                  : 'bg-zinc-900/90 text-zinc-400 border-zinc-800 hover:text-white hover:border-zinc-700'
              }`}
            >
              {p.isStart ? 'Start (0)' : `M#${p.matchNumber} (${p.performanceIndex > 0 ? `+${p.performanceIndex}` : p.performanceIndex})`}
            </button>
          ))}
        </div>
      </div>

      {/* Legend & Guide Bar */}
      <div className="p-3 rounded-2xl bg-[#141419]/70 border border-zinc-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-[#00ff88] shadow-[0_0_8px_#00ff88]" />
            <span className="text-zinc-300 font-medium">WIN = <strong className="text-[#00ff88]">+1 Point</strong> (Upward)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-[#ff4655] shadow-[0_0_8px_#ff4655]" />
            <span className="text-zinc-300 font-medium">LOSS = <strong className="text-[#ff4655]">-1 Point</strong> (Downward)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-4 h-0.5 border-t-2 border-dashed border-[#ffd700]" />
            <span className="text-zinc-400 font-medium">Zero Baseline (Start at 0)</span>
          </div>
        </div>

        <div className="text-[11px] font-mono text-zinc-400">
          Showing <strong className="text-[#ffd700]">{totalMatchesInFilter}</strong> of <strong className="text-white">{totalSavedMatches}</strong> saved matches
        </div>
      </div>
    </div>
  );
};
