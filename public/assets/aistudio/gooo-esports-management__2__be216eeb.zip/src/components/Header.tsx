import React, { useState } from 'react';
import {
  Search,
  Bell,
  PlusCircle,
  MessageCircle,
  ExternalLink,
  Flame,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';

interface HeaderProps {
  title: string;
  subtitle?: string;
  onNavigate?: (page: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  subtitle,
  onNavigate,
}) => {
  const {
    user,
    unreadCount,
    notifications,
    markNotificationAsRead,
    searchFilter,
    setSearchFilter,
    openAddMatchModal,
  } = useTournament();

  const [showNotifMenu, setShowNotifMenu] = useState(false);

  return (
    <header className="sticky top-0 z-30 bg-[#050505]/90 backdrop-blur-md border-b border-[rgba(212,175,55,0.15)] px-4 lg:px-8 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
      {/* Title & Page breadcrumb */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-xl lg:text-2xl font-black tracking-tight text-white flex items-center gap-2">
            <span>{title}</span>
            <span className="w-2 h-2 rounded-full bg-[#ffd700] shadow-[0_0_8px_#ffd700]" />
          </h1>
        </div>
        {subtitle && <p className="text-xs lg:text-sm text-zinc-400 mt-0.5">{subtitle}</p>}
      </div>

      {/* Center Search & Actions */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Search */}
        <div className="relative flex-1 sm:w-64">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
          <input
            type="text"
            value={searchFilter}
            onChange={e => setSearchFilter(e.target.value)}
            placeholder="Search match, mode, map..."
            className="gold-input w-full pl-10 pr-3 text-xs lg:text-sm placeholder:text-zinc-500"
          />
        </div>

        {/* Quick Add Match button */}
        <button
          onClick={openAddMatchModal}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black text-xs font-black uppercase tracking-wider shadow-[0_0_14px_rgba(255,215,0,0.3)] hover:scale-105 transition-all cursor-pointer"
        >
          <PlusCircle size={14} />
          <span className="hidden sm:inline">+ Add Match</span>
          <span className="sm:hidden">+ Match</span>
        </button>

        {/* Quick WhatsApp Match Alert Button */}
        <a
          href="https://wa.me/919876543210?text=Hi%20Destroyed%20eSports!%20Send%20Team%20Destroyed%20match%20reminders."
          target="_blank"
          rel="noopener noreferrer"
          className="hidden sm:inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-[#25D366]/15 hover:bg-[#25D366]/25 border border-[#25D366]/35 text-[#25D366] text-xs font-bold transition-all shadow-[0_0_12px_rgba(37,211,102,0.15)]"
          title="Instant WhatsApp Match Alert"
        >
          <MessageCircle size={15} />
          <span>WA Alerts</span>
          <ExternalLink size={11} className="opacity-75" />
        </a>

        {/* Notifications Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowNotifMenu(!showNotifMenu)}
            aria-label="View notifications"
            className="relative p-2.5 rounded-xl bg-[#0f0f13] hover:bg-[#15151c] border border-[rgba(212,175,55,0.2)] text-zinc-300 hover:text-[#ffd700] transition-colors cursor-pointer"
          >
            <Bell size={18} />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#ff4655] text-white text-[10px] font-black flex items-center justify-center shadow-[0_0_8px_rgba(255,70,85,0.5)]">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Dropdown Card */}
          {showNotifMenu && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-[#0f0f13] border border-[rgba(212,175,55,0.3)] shadow-[0_15px_35px_rgba(0,0,0,0.8)] z-50 overflow-hidden">
              <div className="p-3 border-b border-[rgba(212,175,55,0.15)] flex items-center justify-between bg-[#141419]">
                <div className="flex items-center gap-2">
                  <Flame size={16} className="text-[#ffd700]" />
                  <span className="font-bold text-white text-xs">Live System Feed</span>
                </div>
                <button
                  onClick={() => {
                    setShowNotifMenu(false);
                    if (onNavigate) onNavigate('notifications');
                  }}
                  className="text-[11px] text-[#ffd700] hover:underline cursor-pointer"
                >
                  View All
                </button>
              </div>

              <div className="max-h-72 overflow-y-auto divide-y divide-zinc-800/50">
                {notifications.slice(0, 4).map(n => (
                  <div
                    key={n.id}
                    onClick={() => markNotificationAsRead(n.id)}
                    className={`p-3 text-xs transition-colors cursor-pointer hover:bg-zinc-900/60 ${
                      n.isRead ? 'opacity-70' : 'bg-[#ffd700]/5'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="font-semibold text-white">{n.title}</div>
                      <span className="text-[10px] text-zinc-500 whitespace-nowrap">{n.timestamp}</span>
                    </div>
                    <p className="text-zinc-400 text-[11px] mt-1 line-clamp-2">{n.message}</p>
                    {n.waLink && (
                      <a
                        href={n.waLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-[11px] font-bold text-[#25D366] mt-2 hover:underline"
                      >
                        <MessageCircle size={12} /> Send via WhatsApp
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
