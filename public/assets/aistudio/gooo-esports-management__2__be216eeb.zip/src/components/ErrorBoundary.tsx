import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Unhandled React Error in Component Tree:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#050505] text-white flex items-center justify-center p-6 text-center">
          <div className="max-w-md w-full p-8 rounded-3xl bg-[#0f0f13] border border-[rgba(212,175,55,0.35)] space-y-4 shadow-2xl">
            <div className="w-14 h-14 rounded-2xl bg-[#ffd700]/15 border border-[#ffd700]/30 flex items-center justify-center text-[#ffd700] mx-auto text-2xl font-black">
              !
            </div>
            <h2 className="text-xl font-black text-white">Interface Notice</h2>
            <p className="text-xs text-zinc-400 leading-relaxed">
              A temporary display error was caught safely. Click below to refresh your dashboard view.
            </p>
            <button
              onClick={() => {
                try {
                  window.location.href = 'index.html';
                } catch {
                  window.location.reload();
                }
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-extrabold text-xs uppercase tracking-wider transition-all hover:scale-105 cursor-pointer shadow-lg"
            >
              Reload Overview
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
