import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  Sparkles,
  Trophy,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Crosshair,
  Coins,
  Shield,
  RefreshCw,
  Image as ImageIcon,
  Edit,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';
import { GameMode, GameMap } from '../types';

interface AddMatchHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onHistoryAdded?: () => void;
}

export const AddMatchHistoryModal: React.FC<AddMatchHistoryModalProps> = ({
  isOpen,
  onClose,
  onHistoryAdded,
}) => {
  const { addMatchHistoryItem, user } = useTournament();

  const [activeTab, setActiveTab] = useState<'ocr' | 'manual'>('ocr');

  // OCR state
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageMimeType, setImageMimeType] = useState<string>('image/jpeg');
  const [isScanning, setIsScanning] = useState(false);
  const [ocrError, setOcrError] = useState<string | null>(null);
  const [ocrSuccess, setOcrSuccess] = useState(false);
  const [confidence, setConfidence] = useState<string>('MEDIUM');
  const [rawSummary, setRawSummary] = useState<string>('');

  // Editable Form fields (for both OCR review and Manual entry)
  const [matchNumber, setMatchNumber] = useState('Match #1');
  const [tournamentName, setTournamentName] = useState('Destroyed Scrims Championship');
  const [playerName, setPlayerName] = useState(user.ign || 'DESTROYER_VIPER');
  const [placement, setPlacement] = useState<number>(1);
  const [kills, setKills] = useState<number>(8);
  const [points, setPoints] = useState<number>(20);
  const [rankStatus, setRankStatus] = useState<'WIN' | 'PODIUM' | 'LOSS'>('WIN');
  const [entryFee, setEntryFee] = useState<number>(50);
  const [prizeWon, setPrizeWon] = useState<number>(1200);
  const [map, setMap] = useState<GameMap>('Bermuda');
  const [gameMode, setGameMode] = useState<GameMode>('Battle Royale Squad');
  const [matchDate, setMatchDate] = useState(() => {
    return new Date().toISOString().replace('T', ' ').substring(0, 16) + ' IST';
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setOcrError('Please upload an image file (PNG, JPG, or WEBP).');
      return;
    }

    setImageMimeType(file.type);
    setOcrError(null);
    setOcrSuccess(false);

    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleRunOcr = async () => {
    if (!selectedImage) {
      setOcrError('Please select or upload a match screenshot first.');
      return;
    }

    setIsScanning(true);
    setOcrError(null);

    try {
      const response = await fetch('/api/ocr-match-result', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: selectedImage,
          mimeType: imageMimeType,
        }),
      });

      const resData = await response.json();

      if (resData.data) {
        const d = resData.data;
        if (d.matchNumber) setMatchNumber(d.matchNumber);
        if (d.tournamentName) setTournamentName(d.tournamentName);
        if (d.playerName) setPlayerName(d.playerName);
        if (typeof d.kills === 'number') setKills(d.kills);
        if (typeof d.placement === 'number') {
          setPlacement(d.placement);
          if (d.placement === 1) setRankStatus('WIN');
          else if (d.placement <= 3) setRankStatus('PODIUM');
          else setRankStatus('LOSS');
        }
        if (typeof d.points === 'number') setPoints(d.points);
        if (d.rankStatus) {
          const statusUpper = d.rankStatus.toUpperCase();
          if (statusUpper.includes('WIN') || statusUpper === '1') setRankStatus('WIN');
          else if (statusUpper.includes('PODIUM') || statusUpper === '2' || statusUpper === '3') setRankStatus('PODIUM');
          else setRankStatus('LOSS');
        }
        if (typeof d.prizeWon === 'number') setPrizeWon(d.prizeWon);
        if (typeof d.entryFee === 'number') setEntryFee(d.entryFee);
        if (d.map) setMap(d.map as GameMap);
        if (d.gameMode) setGameMode(d.gameMode as GameMode);
        if (d.confidence) setConfidence(d.confidence);
        if (d.rawSummary) setRawSummary(d.rawSummary);

        setOcrSuccess(true);
      } else {
        setOcrError('Could not extract match details automatically. Please fill or edit the fields below.');
      }
    } catch (err: any) {
      console.error('OCR Request Error:', err);
      setOcrError('Network error or server unreachable. You can still review and edit all fields manually.');
    } finally {
      setIsScanning(false);
    }
  };

  const handleConfirmAndSave = (e: React.FormEvent) => {
    e.preventDefault();

    const netAmount = Number(prizeWon) - Number(entryFee);

    addMatchHistoryItem({
      matchId: matchNumber.trim() || `FF-M${Math.floor(100 + Math.random() * 900)}`,
      tournamentName: tournamentName.trim() || 'Team Destroyed Scrims',
      date: matchDate,
      gameMode,
      map,
      kills: Number(kills) || 0,
      placement: Number(placement) || 1,
      points: Number(points) || 0,
      playerName: playerName.trim() || user.ign,
      rankStatus,
      entryFee: Number(entryFee) || 0,
      prizeWon: Number(prizeWon) || 0,
      netAmount,
      screenshotUrl: selectedImage || undefined,
      rawOcrSummary: rawSummary || undefined,
    });

    onClose();
    if (onHistoryAdded) onHistoryAdded();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl my-6 rounded-3xl bg-[#0f0f13] border border-[rgba(212,175,55,0.35)] shadow-[0_25px_60px_rgba(0,0,0,0.95)] overflow-hidden">
        {/* Glow Accent */}
        <div className="absolute -top-16 -right-16 w-48 h-48 rounded-full bg-[#ffd700]/10 blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-zinc-800 flex items-center justify-between bg-[#141419]/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#ffd700]/15 border border-[#ffd700]/30 flex items-center justify-center text-[#ffd700]">
              <Trophy size={20} />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>Add Match Result & History</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#ffd700]/15 text-[#ffd700] border border-[#ffd700]/30">
                  {user.teamName || 'Team Destroyed'}
                </span>
              </h2>
              <p className="text-xs text-zinc-400">
                Upload match screenshot OCR or enter results manually
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close add result modal"
            className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Mode Tabs */}
        <div className="px-6 pt-4 pb-1 flex items-center gap-2 border-b border-zinc-800/80 bg-[#0a0a0d]">
          <button
            type="button"
            onClick={() => setActiveTab('ocr')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'ocr'
                ? 'bg-[#ffd700] text-black shadow-md font-extrabold'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
            }`}
          >
            <Sparkles size={14} />
            <span>Screenshot OCR Scanner</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('manual')}
            className={`py-2 px-4 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'manual'
                ? 'bg-[#ffd700] text-black shadow-md font-extrabold'
                : 'text-zinc-400 hover:text-white hover:bg-zinc-900'
            }`}
          >
            <Edit size={14} />
            <span>Manual Result Entry</span>
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-5 sm:p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {activeTab === 'ocr' && (
            <div className="space-y-4">
              {/* Screenshot Upload Dropzone */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-[rgba(212,175,55,0.3)] hover:border-[#ffd700] rounded-2xl p-5 text-center cursor-pointer transition-all bg-[#141419]/50 hover:bg-[#141419]"
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/png, image/jpeg, image/jpg, image/webp"
                  className="hidden"
                />

                {selectedImage ? (
                  <div className="space-y-3">
                    <img
                      src={selectedImage}
                      alt="Uploaded match screenshot"
                      className="max-h-48 mx-auto rounded-xl object-contain border border-zinc-700 shadow-md"
                    />
                    <div className="flex items-center justify-center gap-2 text-xs text-[#ffd700] font-semibold">
                      <ImageIcon size={14} />
                      <span>Screenshot Loaded • Click to change</span>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2 py-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#ffd700]/10 border border-[#ffd700]/25 flex items-center justify-center text-[#ffd700] mx-auto">
                      <Upload size={22} />
                    </div>
                    <div className="text-sm font-bold text-white">
                      Upload Match Scoreboard / Points Table Screenshot
                    </div>
                    <p className="text-xs text-zinc-400 max-w-md mx-auto">
                      Supports PNG, JPG, or WEBP from Free Fire match results, custom lobbies, or tournament points tables.
                    </p>
                  </div>
                )}
              </div>

              {/* Action: Run OCR Scan */}
              {selectedImage && (
                <div className="flex items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={handleRunOcr}
                    disabled={isScanning}
                    className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] text-black font-black text-xs uppercase tracking-wider transition-all hover:brightness-110 shadow-[0_0_15px_rgba(255,215,0,0.3)] flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isScanning ? (
                      <>
                        <RefreshCw size={15} className="animate-spin" />
                        <span>Scanning Scoreboard with Gemini AI...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles size={15} />
                        <span>Analyze Screenshot with Gemini AI</span>
                      </>
                    )}
                  </button>
                </div>
              )}

              {/* Status & Feedback */}
              {ocrError && (
                <div className="p-3.5 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2">
                  <AlertTriangle size={15} className="shrink-0" />
                  <span>{ocrError}</span>
                </div>
              )}

              {ocrSuccess && (
                <div className="p-3.5 rounded-xl bg-[#00ff88]/15 border border-[#00ff88]/30 text-[#00ff88] text-xs font-semibold flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 size={16} />
                    <span>OCR Extracted Successfully! Review & edit all fields below before confirming.</span>
                  </div>
                  <span className="text-[10px] uppercase font-bold bg-[#00ff88]/20 px-2 py-0.5 rounded-full">
                    {confidence} Confidence
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Verification Notice: Requirement 10 Never auto-save uncertain data */}
          <div className="p-3.5 rounded-xl bg-[#141419] border border-zinc-800 text-xs text-zinc-300 flex items-start gap-2.5">
            <Shield size={16} className="text-[#ffd700] shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong className="text-white">Review Before Saving: </strong>
              Free Fire OCR extracts match values into the editable form below. You have complete control to verify, modify, or correct any field. The data is only saved once you click <strong className="text-[#ffd700]">"Confirm & Save to Ledger"</strong>.
            </div>
          </div>

          {/* Editable Match Form (Populated by OCR or filled manually) */}
          <form onSubmit={handleConfirmAndSave} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300">Match Number / ID</label>
                <input
                  type="text"
                  value={matchNumber}
                  onChange={e => setMatchNumber(e.target.value)}
                  placeholder="e.g. Match #1 / Game 2"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm font-mono focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300">Tournament / Match Title</label>
                <input
                  type="text"
                  value={tournamentName}
                  onChange={e => setTournamentName(e.target.value)}
                  placeholder="e.g. Bermuda Booyah Masters"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm focus:outline-none"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300">Player / Squad Name</label>
                <input
                  type="text"
                  value={playerName}
                  onChange={e => setPlayerName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300">Placement Rank</label>
                <select
                  value={placement}
                  onChange={e => {
                    const rankNum = Number(e.target.value);
                    setPlacement(rankNum);
                    if (rankNum === 1) setRankStatus('WIN');
                    else if (rankNum <= 3) setRankStatus('PODIUM');
                    else setRankStatus('LOSS');
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm focus:outline-none"
                >
                  <option value={1}>#1 (Booyah / Winner)</option>
                  <option value={2}>#2 (Runner Up)</option>
                  <option value={3}>#3 (Podium)</option>
                  <option value={4}>#4</option>
                  <option value={5}>#5</option>
                  <option value={6}>#6</option>
                  <option value={7}>#7</option>
                  <option value={8}>#8</option>
                  <option value={9}>#9</option>
                  <option value={10}>#10</option>
                  <option value={11}>#11</option>
                  <option value={12}>#12</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300">Result Status</label>
                <select
                  value={rankStatus}
                  onChange={e => setRankStatus(e.target.value as any)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm focus:outline-none"
                >
                  <option value="WIN">WIN (#1 Booyah)</option>
                  <option value="PODIUM">PODIUM (#2 or #3)</option>
                  <option value="LOSS">LOSS (Rank #4+)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300 flex items-center gap-1">
                  <Crosshair size={13} className="text-[#ffd700]" />
                  <span>Kills</span>
                </label>
                <input
                  type="number"
                  min="0"
                  value={kills}
                  onChange={e => setKills(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm font-bold focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300 flex items-center gap-1">
                  <Trophy size={13} className="text-[#00ff88]" />
                  <span>Points</span>
                </label>
                <input
                  type="number"
                  min="0"
                  value={points}
                  onChange={e => setPoints(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-[#00ff88] text-xs sm:text-sm font-bold focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300">Entry Fee (₹)</label>
                <input
                  type="number"
                  min="0"
                  value={entryFee}
                  onChange={e => setEntryFee(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm font-mono focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-[#ffd700]">Prize Won (₹)</label>
                <input
                  type="number"
                  min="0"
                  value={prizeWon}
                  onChange={e => setPrizeWon(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-[#ffd700] text-xs sm:text-sm font-mono font-bold focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300">Map</label>
                <select
                  value={map}
                  onChange={e => setMap(e.target.value as GameMap)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs focus:outline-none"
                >
                  <option value="Bermuda">Bermuda</option>
                  <option value="Purgatory">Purgatory</option>
                  <option value="Kalahari">Kalahari</option>
                  <option value="Nexterra">Nexterra</option>
                  <option value="Alpine">Alpine</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-zinc-300">Game Mode</label>
                <select
                  value={gameMode}
                  onChange={e => setGameMode(e.target.value as GameMode)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs focus:outline-none"
                >
                  <option value="Battle Royale Squad">Battle Royale Squad</option>
                  <option value="Battle Royale Duo">Battle Royale Duo</option>
                  <option value="Battle Royale Solo">Battle Royale Solo</option>
                  <option value="Clash Squad 4v4">Clash Squad 4v4</option>
                </select>
              </div>
            </div>

            {/* Net Amount Calculated Preview */}
            <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-between text-xs">
              <span className="text-zinc-400">Net Ledger Calculation (Prize - Entry):</span>
              <span
                className={`font-black font-mono text-sm ${
                  Number(prizeWon) - Number(entryFee) >= 0 ? 'text-[#00ff88]' : 'text-[#ff4655]'
                }`}
              >
                {Number(prizeWon) - Number(entryFee) >= 0 ? '+' : ''}
                ₹{Number(prizeWon) - Number(entryFee)}
              </span>
            </div>

            {/* Submit / Confirm Button */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#00ff88] to-[#00c968] hover:brightness-110 text-black font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(0,255,136,0.3)] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <CheckCircle2 size={17} />
                <span>Confirm & Save Match Result to Ledger</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
