import React, { useState } from 'react';
import {
  X,
  Swords,
  Calendar,
  Clock,
  MessageCircle,
  FileText,
  CheckCircle2,
  Sparkles,
  Trophy,
} from 'lucide-react';
import { useTournament } from '../context/TournamentContext';
import { TournamentFormat, GameMode, GameMap, SeriesFormat } from '../types';

interface AddMatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onMatchAdded?: (matchTitle: string) => void;
}

export const AddMatchModal: React.FC<AddMatchModalProps> = ({ isOpen, onClose, onMatchAdded }) => {
  const { addTournament, user } = useTournament();

  const [title, setTitle] = useState('');
  const [format, setFormat] = useState<TournamentFormat>('BR Squad');
  const [seriesFormat, setSeriesFormat] = useState<SeriesFormat>('Best of 3 (Bo3)');
  const [map, setMap] = useState<GameMap>('Bermuda');

  // Manual Date & Time controls
  const [matchDate, setMatchDate] = useState<string>(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [matchTime, setMatchTime] = useState<string>('20:30');
  const [opponentSquad, setOpponentSquad] = useState('');
  const [whatsAppGroupUrl, setWhatsAppGroupUrl] = useState('');

  // Finances
  const [entryFee, setEntryFee] = useState<number>(0);
  const [prizePool, setPrizePool] = useState<number>(1000);
  const [firstPrize, setFirstPrize] = useState<number>(500);

  // Strategy
  const [strategyNotes, setStrategyNotes] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Please provide a match name.');
      return;
    }

    // Construct timestamp from date and time
    let targetMs = Date.now() + 45 * 60 * 1000;
    let formattedTimeStr = 'Tonight, 08:30 PM IST';
    try {
      if (matchDate && matchTime) {
        const [hours, minutes] = matchTime.split(':').map(Number);
        const [year, month, day] = matchDate.split('-').map(Number);
        const dateObj = new Date(year, month - 1, day, hours, minutes);
        targetMs = dateObj.getTime();
        formattedTimeStr = `${matchDate} ${matchTime} IST`;
      }
    } catch {
      targetMs = Date.now() + 45 * 60 * 1000;
    }

    const gameModeMap: Record<TournamentFormat, GameMode> = {
      'BR Squad': 'Battle Royale Squad',
      'BR Duo': 'Battle Royale Duo',
      'BR Solo': 'Battle Royale Solo',
      'Clash Squad 4v4': 'Clash Squad 4v4',
    };

    const maxPlayersMap: Record<TournamentFormat, number> = {
      'BR Squad': 48,
      'BR Duo': 48,
      'BR Solo': 48,
      'Clash Squad 4v4': 8,
    };

    addTournament({
      title: title.trim(),
      gameMode: gameModeMap[format],
      format,
      seriesFormat,
      map,
      entryFee: Number(entryFee) || 0,
      prizePool: Number(prizePool) || 0,
      firstPrize: Number(firstPrize) || Math.round((Number(prizePool) || 0) * 0.5),
      maxPlayers: maxPlayersMap[format],
      startTimeIST: formattedTimeStr,
      scheduledDateIST: `${matchDate} ${matchTime}`,
      targetTimestampMs: targetMs,
      status: targetMs <= Date.now() ? 'LIVE' : 'UPCOMING',
      lobbyStatus: 'WAITING_FOR_PLAYERS',
      clientCompatibility: 'FF_INDIA_ONLY',
      organizerVerifiedClient: true,
      whatsAppGroupUrl: whatsAppGroupUrl.trim() || undefined,
      opponentSquad: opponentSquad.trim() || undefined,
      strategyNotes: strategyNotes.trim() || undefined,
      scoringRules: {
        pointsPerKill: 2,
        placementPoints: { 1: 12, 2: 9, 3: 8, 4: 7, 5: 6, 6: 5, 7: 4, 8: 3, 9: 2, 10: 1 },
      },
      rulesDescription: `Free Fire competitive match. Squad: ${user.teamName || 'Team Destroyed'}.${
        opponentSquad ? ` Opponent: ${opponentSquad}.` : ''
      }`,
    });

    onClose();
    if (onMatchAdded) onMatchAdded(title);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-xl my-6 rounded-3xl bg-[#0f0f13] border border-[rgba(212,175,55,0.35)] shadow-[0_25px_60px_rgba(0,0,0,0.95)] overflow-hidden">
        {/* Glow Accent */}
        <div className="absolute -top-16 -right-16 w-48 h-48 rounded-full bg-[#ffd700]/10 blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-zinc-800 flex items-center justify-between bg-[#141419]/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#ffd700]/15 border border-[#ffd700]/30 flex items-center justify-center text-[#ffd700]">
              <Swords size={20} />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <span>Plan / Add Match</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#ffd700]/15 text-[#ffd700] border border-[#ffd700]/30">
                  {user.teamName || 'Team Destroyed'}
                </span>
              </h2>
              <p className="text-xs text-zinc-400">
                Manual schedule with countdown and custom WhatsApp group link
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close match planner modal"
            className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 max-h-[78vh] overflow-y-auto">
          {error && (
            <div className="p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs font-semibold">
              {error}
            </div>
          )}

          {/* Match Name */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-zinc-300 flex items-center justify-between">
              <span>Match / Tournament Name <span className="text-[#ffd700]">*</span></span>
            </label>
            <input
              type="text"
              value={title}
              onChange={e => {
                setTitle(e.target.value);
                setError(null);
              }}
              placeholder="e.g. Scrim vs GodLike / Bermuda Masters 2026"
              className="w-full px-4 py-2.5 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none transition-colors"
              required
            />
          </div>

          {/* Format (Solo / Duo / Squad) & Map */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-300">Format</label>
              <select
                value={format}
                onChange={e => setFormat(e.target.value as TournamentFormat)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm focus:outline-none transition-colors"
              >
                <option value="BR Squad">Squad (Battle Royale)</option>
                <option value="BR Duo">Duo (Battle Royale)</option>
                <option value="BR Solo">Solo (Battle Royale)</option>
                <option value="Clash Squad 4v4">Clash Squad (4v4)</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-300">Map</label>
              <select
                value={map}
                onChange={e => setMap(e.target.value as GameMap)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm focus:outline-none transition-colors"
              >
                <option value="Bermuda">Bermuda</option>
                <option value="Purgatory">Purgatory</option>
                <option value="Kalahari">Kalahari</option>
                <option value="Nexterra">Nexterra</option>
                <option value="Alpine">Alpine</option>
              </select>
            </div>
          </div>

          {/* Manual Date & Time (Requirement 5) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                <Calendar size={13} className="text-[#ffd700]" />
                <span>Match Date</span>
              </label>
              <input
                type="date"
                value={matchDate}
                onChange={e => setMatchDate(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm focus:outline-none transition-colors"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                <Clock size={13} className="text-[#ffd700]" />
                <span>Kickoff Time (IST)</span>
              </label>
              <input
                type="time"
                value={matchTime}
                onChange={e => setMatchTime(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm focus:outline-none transition-colors"
                required
              />
            </div>
          </div>

          {/* Series Type & Opponent */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-300">Series Type</label>
              <select
                value={seriesFormat}
                onChange={e => setSeriesFormat(e.target.value as SeriesFormat)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm focus:outline-none transition-colors"
              >
                <option value="Single Match">Single Match</option>
                <option value="Best of 3 (Bo3)">Best of 3 (Bo3)</option>
                <option value="Best of 5 (Bo5)">Best of 5 (Bo5)</option>
                <option value="Round Robin">Round Robin</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-zinc-300">Opponent Squad (Optional)</label>
              <input
                type="text"
                value={opponentSquad}
                onChange={e => setOpponentSquad(e.target.value)}
                placeholder="e.g. GodLike / Soul / Scrim Group"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none transition-colors"
              />
            </div>
          </div>

          {/* Finances: Entry Fee, Prize Pool, First Prize (Requirement 6) */}
          <div className="grid grid-cols-3 gap-2.5 p-3.5 rounded-2xl bg-[#141419] border border-[rgba(212,175,55,0.2)]">
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-zinc-300 block">Entry Fee (₹)</label>
              <input
                type="number"
                min="0"
                value={entryFee}
                onChange={e => setEntryFee(Number(e.target.value))}
                className="w-full px-2.5 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs font-bold focus:border-[#ffd700] focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-[#ffd700] block">Prize Pool (₹)</label>
              <input
                type="number"
                min="0"
                value={prizePool}
                onChange={e => {
                  const val = Number(e.target.value);
                  setPrizePool(val);
                  setFirstPrize(Math.round(val * 0.5));
                }}
                className="w-full px-2.5 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-[#ffd700] text-xs font-bold focus:border-[#ffd700] focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-bold text-[#00ff88] block">1st Prize (₹)</label>
              <input
                type="number"
                min="0"
                value={firstPrize}
                onChange={e => setFirstPrize(Number(e.target.value))}
                className="w-full px-2.5 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-[#00ff88] text-xs font-bold focus:border-[#ffd700] focus:outline-none"
              />
            </div>
          </div>

          {/* Dedicated Per-Match WhatsApp Group URL (Requirement 4 & 7) */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-zinc-300 flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[#25D366]">
                <MessageCircle size={14} />
                <span>Match WhatsApp Group Link</span>
              </span>
              <span className="text-[10px] text-zinc-500">Opens exact group on click</span>
            </label>
            <input
              type="url"
              value={whatsAppGroupUrl}
              onChange={e => setWhatsAppGroupUrl(e.target.value)}
              placeholder="https://chat.whatsapp.com/your-scrim-group-code"
              className="w-full px-4 py-2.5 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#25D366] text-white text-xs sm:text-sm font-mono placeholder:text-zinc-500 focus:outline-none transition-colors"
            />
            <p className="text-[10px] text-zinc-500">
              Each match stores its own group link. Clicking "Join WhatsApp Group" opens this exact link directly without any prompt.
            </p>
          </div>

          {/* Strategy Notes & Guidelines */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
              <FileText size={13} className="text-[#ffd700]" />
              <span>Strategy Notes & Guidelines</span>
            </label>
            <textarea
              rows={2}
              value={strategyNotes}
              onChange={e => setStrategyNotes(e.target.value)}
              placeholder="e.g. Drop Pochinok, Viper on IGL, Rohit on Sniper, safe rotation to zone 3"
              className="w-full px-3.5 py-2 rounded-xl bg-[#141419] border border-zinc-700/80 focus:border-[#ffd700] text-white text-xs placeholder:text-zinc-500 focus:outline-none transition-colors"
            />
          </div>

          {/* Submit */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#d4af37] hover:brightness-110 text-black font-black text-xs uppercase tracking-wider shadow-[0_0_20px_rgba(255,215,0,0.3)] transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <CheckCircle2 size={16} />
              <span>Save Match & Start Countdown</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
