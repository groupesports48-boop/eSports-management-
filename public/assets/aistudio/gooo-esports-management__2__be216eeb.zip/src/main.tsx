import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

function initApp() {
  const container = document.getElementById('root');
  if (!container) {
    console.error('Target container #root not found.');
    return;
  }
  createRoot(container).render(<App />);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}
